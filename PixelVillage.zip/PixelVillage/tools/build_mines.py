#!/usr/bin/env python3
"""
Elige las minas a cielo abierto del juego entre las canteras (landuse=quarry) de OpenStreetMap
y escribe app/src/main/assets/mines.json:

  hierro : 3 minas en la zona de Moa
  cobre  : 2 minas muy lejos de Moa (zona de Mayarí / Sagua)
  oro    : UNA sola mina en todo el mapa (la más lejana)

Cada mina lleva su contorno (en px del juego) y las posiciones de sus hornos de fusión
(5 por mina de hierro/cobre, 1 en la de oro). El juego pone los minerales dentro del contorno.

Uso:  python3 tools/build_mines.py  ruta/al/archivo.gpkg
"""
import json, math, os, sqlite3, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_tiles as bt

OUT = os.path.join(os.path.dirname(HERE), "app", "src", "main", "assets", "mines.json")

# (metal, nombre por defecto, lon, lat aproximados del centro de la cantera de OSM)
CHOSEN = [
    ("iron", "Mina de Pedro Soto Alba", -74.973, 20.604),
    ("iron", "Mina de Ernesto «Che» Guevara", -74.893, 20.625),
    ("iron", "Mina de hierro", -74.915, 20.616),
    ("copper", "Mina de cobre", -75.705, 20.541),
    ("copper", "Mina de cobre", -75.526, 20.604),
    ("gold", "Mina de oro", -76.690, 20.892),
]
FURN_SPACING = 30.0     # px entre hornos de una fila (12 m)


def dp(pts, tol):
    """Douglas-Peucker sobre una lista de puntos (np.array Nx2)."""
    if len(pts) < 3:
        return pts
    a, b = pts[0], pts[-1]
    ab = b - a
    n = np.hypot(*ab)
    if n == 0:
        d = np.hypot(pts[:, 0] - a[0], pts[:, 1] - a[1])
    else:
        d = np.abs(ab[0] * (pts[:, 1] - a[1]) - ab[1] * (pts[:, 0] - a[0])) / n
    i = int(np.argmax(d))
    if d[i] > tol:
        l = dp(pts[:i + 1], tol); r = dp(pts[i:], tol)
        return np.vstack([l[:-1], r])
    return np.vstack([a, b])


def inside(poly, x, y):
    c = False
    j = len(poly) - 1
    for i in range(len(poly)):
        if (poly[i][1] > y) != (poly[j][1] > y) and x < (poly[j][0] - poly[i][0]) * (y - poly[i][1]) / (poly[j][1] - poly[i][1]) + poly[i][0]:
            c = not c
        j = i
    return c


def furnace_spots(poly, count):
    """Posiciones dentro del contorno, en fila, lo más cerca posible del centro."""
    cx, cy = poly.mean(axis=0)
    best = None
    for r in np.arange(0, 4000, 25.0):
        for a in np.arange(0, 2 * math.pi, 0.4):
            x = cx + r * math.cos(a); y = cy + r * math.sin(a)
            ok = all(inside(poly, x + (i - (count - 1) / 2) * FURN_SPACING, y) and
                     inside(poly, x + (i - (count - 1) / 2) * FURN_SPACING, y + 40) for i in range(count))
            if ok:
                best = (x, y); break
        if best:
            break
    if best is None:
        best = (cx, cy)
    x, y = best
    return [(x + (i - (count - 1) / 2) * FURN_SPACING, y) for i in range(count)]


def main(path):
    db = sqlite3.connect("file:%s?mode=ro" % path, uri=True)
    quarries = []
    for name, blob in db.execute("select name, geom from multipolygons where landuse='quarry'"):
        g = bt.parse_gpkg(blob)
        if not g:
            continue
        ring = g[0][0]
        quarries.append((name, ring))
    mines = []
    used = set()
    for mi, (metal, default, lon, lat) in enumerate(CHOSEN):
        best, bd = None, 1e9
        for qi, (name, ring) in enumerate(quarries):
            if qi in used:
                continue
            d = math.hypot(ring[:, 0].mean() - lon, ring[:, 1].mean() - lat)
            if d < bd:
                bd, best = d, qi
        assert best is not None and bd < 0.02, (metal, lon, lat, bd)
        used.add(best)
        name, ring = quarries[best]
        x, y = bt.to_px(ring)
        poly = np.column_stack([x, y])
        simp = dp(poly, 4.0)
        if len(simp) > 400:
            simp = dp(poly, 12.0)
        furn = furnace_spots(simp, 1 if metal == "gold" else 5)
        mines.append({
            "id": 9000000000 + mi,
            "type": metal,
            "name": name or default,
            "lon": round(float(ring[:, 0].mean()), 5), "lat": round(float(ring[:, 1].mean()), 5),
            "pts": [round(float(v), 1) for p in simp for v in p],
            "furn": [round(float(v), 1) for f in furn for v in f],
        })
        print(metal, mines[-1]["name"], "puntos:", len(simp), "hornos:", len(furn))
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"mines": mines}, f, ensure_ascii=False, separators=(",", ":"))
    print("escrito", OUT, os.path.getsize(OUT), "bytes")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
