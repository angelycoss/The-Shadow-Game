#!/usr/bin/env python3
"""
Extrae las zonas y edificios militares de OpenStreetMap (landuse=military, building=military/barracks/bunker,
o cualquier etiqueta military) y escribe app/src/main/assets/military.json.
El juego pone en ellos 'vaults' (cajas fuertes) con armas.

Uso:  python3 tools/build_military.py  ruta/al/archivo.gpkg
"""
import json, os, sqlite3, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_tiles as bt
from build_mines import dp

OUT = os.path.join(os.path.dirname(HERE), "app", "src", "main", "assets", "military.json")


def main(path):
    db = sqlite3.connect("file:%s?mode=ro" % path, uri=True)
    q = ("select id, geom, name, building, landuse, other_tags from multipolygons where landuse='military' "
         "or building in ('military','barracks','bunker') or other_tags like '%\"military\"%' or other_tags like '%military%'")
    zones = []
    for fid, blob, name, building, landuse, other in db.execute(q):
        ot = bt.hstore(other)
        is_zone = landuse == 'military'
        if not is_zone and not (building in ('military', 'barracks', 'bunker') or 'military' in ot):
            if 'military' not in (ot.get('operator:type') or ''):
                continue
        g = bt.parse_gpkg(blob)
        if not g:
            continue
        ring = g[0][0]
        x, y = bt.to_px(ring)
        poly = np.column_stack([x, y])
        simp = dp(poly, 4.0)
        if len(simp) > 300:
            simp = dp(poly, 12.0)
        area = abs(0.5 * float(np.sum(x * np.roll(y, -1) - np.roll(x, -1) * y)))
        zones.append({
            "id": 8000000000 + int(fid),
            "zone": 1 if is_zone else 0,
            "name": name or "",
            "area": int(area),
            "pts": [round(float(v), 1) for p in simp for v in p],
        })
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"zones": zones}, f, ensure_ascii=False, separators=(",", ":"))
    print(len(zones), "zonas/edificios militares;", sum(z["zone"] for z in zones), "zonas")
    print("escrito", OUT, os.path.getsize(OUT), "bytes")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
