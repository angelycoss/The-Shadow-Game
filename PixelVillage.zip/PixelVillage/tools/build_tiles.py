#!/usr/bin/env python3
"""
Convierte un extracto de OpenStreetMap en GeoPackage (BBBike) en "teselas" JSON que el juego
trae dentro del APK:  app/src/main/assets/base/t_X_Y.json

Uso:   python3 tools/build_tiles.py  ruta/al/archivo.gpkg
(Solo hace falta repetirlo si cambias el mapa. Necesita Python 3 y numpy.)

OJO: las constantes de abajo deben coincidir con Region.kt y World.kt.
"""
import json, math, os, shutil, sqlite3, struct, sys
import numpy as np

LAT0 = 20.89098              # Parque Los Pinos = origen (0,0) del mundo
LON0 = -75.81833
M_LAT = 110540.0
M_LON = 111320.0 * math.cos(math.radians(LAT0))
PPM = 2.5                    # px del juego por metro
TILE_PX = 2048               # tamaño de una tesela en px (≈ 819 m)
CLIP_M = 48.0                # margen al recortar lo que cruza varias teselas (px)

# Zona que cubre el extracto (BBBike: lng_min, lat_min, lng_max, lat_max). Dentro de ella, una tesela
# sin archivo es mar o terreno vacío (no hace falta descargarla); fuera, el juego la descarga.
BBOX = (-75.843, 20.870, -75.807, 20.909)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(HERE), "app", "src", "main", "assets", "base")

# Lo mismo que entiende el motor (World.kt -> areaKind / Osm.query)
NATURAL = {"water", "wood", "scrub", "heath", "grassland", "sand", "beach", "wetland", "mud"}
LANDUSE = {"forest", "grass", "meadow", "farmland", "farmyard", "orchard", "vineyard", "industrial",
           "commercial", "retail", "cemetery", "recreation_ground", "village_green", "reservoir", "basin", "landfill"}
LEISURE = {"park", "garden", "playground", "pitch", "golf_course", "nature_reserve"}
WATERWAY = {"river", "stream", "canal"}
BARRIER = {"fence": "fence", "hedge": "hedge", "wall": "wall", "retaining_wall": "wall", "city_wall": "wall"}
RAIL = {"rail", "abandoned", "disused"}
CHURCH_B = {"church", "chapel", "cathedral", "yes;church"}
NON_CHRISTIAN = {"muslim", "jewish", "buddhist", "hindu", "shinto", "sikh", "taoist"}


# ---------------------------------------------------------------- lectura de GeoPackage
def parse_gpkg(blob):
    flags = blob[3]
    if flags & 0x10:
        return None
    env = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}[(flags >> 1) & 7]
    return parse_wkb(blob, 8 + env)[0]


def parse_wkb(b, o):
    e = "<" if b[o] == 1 else ">"
    typ = struct.unpack_from(e + "I", b, o + 1)[0]
    o += 5
    base, z = typ % 1000, typ // 1000
    dim = 2 + (1 if z in (1, 3) else 0) + (1 if z in (2, 3) else 0)
    if base == 1:
        x, y = struct.unpack_from(e + "dd", b, o)
        return (x, y), o + 8 * dim
    if base == 2:
        n = struct.unpack_from(e + "I", b, o)[0]; o += 4
        a = np.frombuffer(b, dtype=e + "f8", count=n * dim, offset=o).reshape(n, dim)[:, :2]
        return a, o + 8 * n * dim
    if base == 3:
        nr = struct.unpack_from(e + "I", b, o)[0]; o += 4
        rings = []
        for _ in range(nr):
            n = struct.unpack_from(e + "I", b, o)[0]; o += 4
            a = np.frombuffer(b, dtype=e + "f8", count=n * dim, offset=o).reshape(n, dim)[:, :2]
            o += 8 * n * dim
            rings.append(a)
        return rings, o
    if base in (4, 5, 6, 7):
        n = struct.unpack_from(e + "I", b, o)[0]; o += 4
        parts = []
        for _ in range(n):
            g, o = parse_wkb(b, o)
            parts.append(g)
        return parts, o
    raise ValueError("geometría no soportada: %d" % typ)


def hstore(s):
    """other_tags de GDAL: "clave"=>"valor","clave2"=>"valor2" """
    d = {}
    if not s:
        return d
    i, n = 0, len(s)
    def rd(i):
        assert s[i] == '"'
        j, out = i + 1, []
        while s[j] != '"':
            if s[j] == "\\":
                j += 1
            out.append(s[j]); j += 1
        return "".join(out), j + 1
    while i < n:
        k, i = rd(i)
        i += 2                      # =>
        v, i = rd(i)
        d[k] = v
        if i < n and s[i] == ",":
            i += 1
    return d


# ---------------------------------------------------------------- geometría
def to_px(lonlat):
    return (lonlat[:, 0] - LON0) * M_LON * PPM, -(lonlat[:, 1] - LAT0) * M_LAT * PPM


def tile_range(v0, v1):
    return (math.floor((v0 + TILE_PX / 2) / TILE_PX), math.floor((v1 + TILE_PX / 2) / TILE_PX))


def clip_poly(pts, x0, y0, x1, y1):
    """Sutherland-Hodgman contra un rectángulo. pts: lista de (x, y) sin repetir el primero."""
    def run(pts, inside, inter):
        out = []
        if not pts:
            return out
        p = pts[-1]
        for q in pts:
            if inside(q):
                if not inside(p):
                    out.append(inter(p, q))
                out.append(q)
            elif inside(p):
                out.append(inter(p, q))
            p = q
        return out
    def ix(xc):
        return lambda p, q: (xc, p[1] + (q[1] - p[1]) * (xc - p[0]) / (q[0] - p[0]))
    def iy(yc):
        return lambda p, q: (p[0] + (q[0] - p[0]) * (yc - p[1]) / (q[1] - p[1]), yc)
    pts = run(pts, lambda p: p[0] >= x0, ix(x0))
    pts = run(pts, lambda p: p[0] <= x1, ix(x1))
    pts = run(pts, lambda p: p[1] >= y0, iy(y0))
    pts = run(pts, lambda p: p[1] <= y1, iy(y1))
    return pts


def clip_seg(p, q, x0, y0, x1, y1):
    """Liang-Barsky. Devuelve (a, b) recortados o None."""
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pp, qq in ((-dx, p[0] - x0), (dx, x1 - p[0]), (-dy, p[1] - y0), (dy, y1 - p[1])):
        if pp == 0:
            if qq < 0:
                return None
        else:
            r = qq / pp
            if pp < 0:
                if r > t1: return None
                if r > t0: t0 = r
            else:
                if r < t0: return None
                if r < t1: t1 = r
    a = p if t0 == 0.0 else (p[0] + t0 * dx, p[1] + t0 * dy)      # exacto si no se recorta
    b = q if t1 == 1.0 else (p[0] + t1 * dx, p[1] + t1 * dy)
    return (a, b)


def clip_line(pts, x0, y0, x1, y1):
    runs, cur = [], []
    for i in range(len(pts) - 1):
        c = clip_seg(pts[i], pts[i + 1], x0, y0, x1, y1)
        if c is None:
            if len(cur) >= 2: runs.append(cur)
            cur = []
            continue
        a, b = c
        if not cur:
            cur = [a]
        cur.append(b)
        if b != pts[i + 1]:              # la línea sale del rectángulo
            if len(cur) >= 2: runs.append(cur)
            cur = []
    if len(cur) >= 2: runs.append(cur)
    return runs


def lonlat(x, y):
    return LON0 + x / (PPM * M_LON), LAT0 - y / (PPM * M_LAT)


def flat(pts_px):
    out = []
    for x, y in pts_px:
        lo, la = lonlat(x, y)
        out.append("%.6f,%.6f" % (lo, la))
    return ",".join(out)


def flat_ll(arr):
    return ",".join("%.6f,%.6f" % (a, b) for a, b in arr.tolist())


# ---------------------------------------------------------------- proceso
LAST_ISLANDS = []
tiles = {}      # (tx, ty) -> [json de cada elemento]
stats = {"building": 0, "area": 0, "road": 0, "water": 0, "tree": 0, "clipped": 0, "fence": 0, "rail": 0, "church": 0, "sea_tiles": 0, "island": 0}


def put(t, s):
    tiles.setdefault(t, []).append(s)


def tags_json(d):
    return json.dumps(d, separators=(",", ":"), ensure_ascii=False)


def add_poly(ring_ll, ident, tags, clip, kind):
    """ring_ll: (n,2) lon/lat, cerrado. clip=False para edificios."""
    xs, ys = to_px(ring_ll)
    tx0, tx1 = tile_range(xs.min(), xs.max())
    ty0, ty1 = tile_range(ys.min(), ys.max())
    stats[kind] += 1
    if not clip or (tx0 == tx1 and ty0 == ty1):
        s = '{"type":"way","id":%d,"tags":%s,"pts":"%s"}' % (ident, tags_json(tags), flat_ll(ring_ll))
        for ty in range(ty0, ty1 + 1):
            for tx in range(tx0, tx1 + 1):
                put((tx, ty), s)
        return
    pts = list(zip(xs.tolist(), ys.tolist()))[:-1]
    for ty in range(ty0, ty1 + 1):
        for tx in range(tx0, tx1 + 1):
            x0 = tx * TILE_PX - TILE_PX / 2 - CLIP_M; x1 = x0 + TILE_PX + 2 * CLIP_M
            y0 = ty * TILE_PX - TILE_PX / 2 - CLIP_M; y1 = y0 + TILE_PX + 2 * CLIP_M
            c = clip_poly(pts, x0, y0, x1, y1)
            if len(c) < 3:
                continue
            stats["clipped"] += 1
            c.append(c[0])
            put((tx, ty), '{"type":"way","tags":%s,"clip":true,"pts":"%s"}' % (tags_json(tags), flat(c)))


def add_line(line_ll, ident, tags, kind):
    xs, ys = to_px(line_ll)
    tx0, tx1 = tile_range(xs.min(), xs.max())
    ty0, ty1 = tile_range(ys.min(), ys.max())
    stats[kind] += 1
    if tx0 == tx1 and ty0 == ty1:
        put((tx0, ty0), '{"type":"way","id":%d,"tags":%s,"pts":"%s"}' % (ident, tags_json(tags), flat_ll(line_ll)))
        return
    pts = list(zip(xs.tolist(), ys.tolist()))
    for ty in range(ty0, ty1 + 1):
        for tx in range(tx0, tx1 + 1):
            x0 = tx * TILE_PX - TILE_PX / 2 - CLIP_M; x1 = x0 + TILE_PX + 2 * CLIP_M
            y0 = ty * TILE_PX - TILE_PX / 2 - CLIP_M; y1 = y0 + TILE_PX + 2 * CLIP_M
            for run in clip_line(pts, x0, y0, x1, y1):
                stats["clipped"] += 1
                put((tx, ty), '{"type":"way","tags":%s,"pts":"%s"}' % (tags_json(tags), flat(run)))


def add_whole_line(line_ll, tags, kind):
    """Línea entera en cada tesela que toca (las cercas se trocean en el juego, sin recortar)."""
    xs, ys = to_px(line_ll)
    tx0, tx1 = tile_range(xs.min(), xs.max())
    ty0, ty1 = tile_range(ys.min(), ys.max())
    stats[kind] += 1
    s = '{"type":"way","tags":%s,"pts":"%s"}' % (tags_json(tags), flat_ll(line_ll))
    for ty in range(ty0, ty1 + 1):
        for tx in range(tx0, tx1 + 1):
            put((tx, ty), s)


# ---------------------------------------------------------------- mar a partir de la línea de costa
# En OpenStreetMap la tierra queda a la IZQUIERDA de la línea de costa y el mar a la derecha.
# Trabajamos en px (y hacia abajo, como en pantalla): el mar queda a la derecha según el sentido de la línea.

def perim(p, r, eps=1e-3):
    x0, y0, x1, y1 = r
    W, H = x1 - x0, y1 - y0
    x, y = p
    if abs(y - y0) < eps: return min(max(x - x0, 0.0), W)
    if abs(x - x1) < eps: return W + min(max(y - y0, 0.0), H)
    if abs(y - y1) < eps: return W + H + min(max(x1 - x, 0.0), W)
    if abs(x - x0) < eps: return 2 * W + H + min(max(y1 - y, 0.0), H)
    return None


def assemble(runs, r):
    """Une trozos de costa (entran y salen por el borde de r) en polígonos de mar, cerrando por el borde
    en el sentido de las agujas del reloj. Devuelve (polígonos, trozos_con_extremo_suelto)."""
    x0, y0, x1, y1 = r
    W, H = x1 - x0, y1 - y0
    P = 2 * (W + H)
    corners = [(0.0, (x0, y0)), (W, (x1, y0)), (W + H, (x1, y1)), (2 * W + H, (x0, y1))]
    info = []
    loose = 0
    for k, run in enumerate(runs):
        se, sx = perim(run[0], r), perim(run[-1], r)
        if se is None or sx is None:
            loose += 1
            continue
        info.append((k, se, sx))
    entries = sorted(info, key=lambda t: t[1])
    used = set()
    polys = []
    for k0, se0, sx0 in entries:
        if k0 in used:
            continue
        poly = list(runs[k0]); used.add(k0)
        cur_exit = sx0
        ok = False
        for _ in range(len(entries) + 2):
            best = None
            for k, se, sx in entries:
                d = (se - cur_exit) % P
                if k != k0 and k in used:
                    continue
                if best is None or d < best[0]:
                    best = (d, k, se, sx)
            if best is None:
                break
            d, k, se, sx = best
            for cs, cp in corners:                       # esquinas que se pasan por el camino
                dc = (cs - cur_exit) % P
                if 1e-9 < dc < d - 1e-9:
                    poly.append(cp)
            if k == k0:
                ok = True
                break
            poly.extend(runs[k]); used.add(k)
            cur_exit = sx
        if ok and len(poly) >= 3:
            polys.append(poly)
    return polys, loose


def pip_many(poly, X, Y):
    inside = np.zeros(len(X), dtype=bool)
    n = len(poly)
    ax, ay = poly[-1]
    for i in range(n):
        bx, by = poly[i]
        if ay != by:
            m = ((ay > Y) != (by > Y)) & (X < (bx - ax) * (Y - ay) / (by - ay) + ax)
            inside ^= m
        ax, ay = bx, by
    return inside


def px_list(ll):
    x, y = to_px(ll)
    return list(zip(x.tolist(), y.tolist()))


def ray_to_rect(p, d, r):
    """Punto donde el rayo p + t*d (t>0) sale del rectángulo r, o None."""
    best = None
    for (num, den) in ((r[0] - p[0], d[0]), (r[2] - p[0], d[0])):
        if den != 0 and num / den > 1e-9:
            t = num / den; y = p[1] + t * d[1]
            if r[1] - 1e-6 <= y <= r[3] + 1e-6 and (best is None or t < best[0]): best = (t, (p[0] + t * d[0], y))
    for (num, den) in ((r[1] - p[1], d[1]), (r[3] - p[1], d[1])):
        if den != 0 and num / den > 1e-9:
            t = num / den; x = p[0] + t * d[0]
            if r[0] - 1e-6 <= x <= r[2] + 1e-6 and (best is None or t < best[0]): best = (t, (x, p[1] + t * d[1]))
    return best[1] if best else None


def extend_to_rect(ch, r):
    """Si el extracto corta la costa dentro de la zona, prolonga el extremo en línea recta hasta el borde."""
    def inside(p): return r[0] + 1e-3 < p[0] < r[2] - 1e-3 and r[1] + 1e-3 < p[1] < r[3] - 1e-3
    ch = list(ch)
    if inside(ch[-1]):
        q = ray_to_rect(ch[-1], (ch[-1][0] - ch[-2][0], ch[-1][1] - ch[-2][1]), r)
        print("  aviso: costa cortada al final, se prolonga a", q)
        if q: ch.append(q)
    if inside(ch[0]):
        q = ray_to_rect(ch[0], (ch[0][0] - ch[1][0], ch[0][1] - ch[1][1]), r)
        print("  aviso: costa cortada al inicio, se prolonga a", q)
        if q: ch.insert(0, q)
    return ch


def build_sea(db):
    # 1) costa: líneas (sentido original) y su unión en cadenas
    ways = []
    for blob, other in db.execute("select geom, other_tags from lines where other_tags like '%\"natural\"=>\"coastline\"%'"):
        g = parse_gpkg(blob)
        if g is not None and len(g) >= 2 and hstore(other).get("natural") == "coastline":
            ways.append(px_list(g))
    by_start = {}
    for i, w in enumerate(ways):
        by_start.setdefault(w[0], []).append(i)
    ends = set(w[-1] for w in ways)
    order = [i for i, w in enumerate(ways) if w[0] not in ends] + list(range(len(ways)))
    used = [False] * len(ways)
    chains = []
    for i in order:
        if used[i]:
            continue
        used[i] = True
        ch = list(ways[i])
        while ch[-1] != ch[0] or len(ch) < 4:
            nxt = next((j for j in by_start.get(ch[-1], []) if not used[j]), None)
            if nxt is None:
                break
            used[nxt] = True
            ch.extend(ways[nxt][1:])
        chains.append(ch)

    ax, ay = to_px(np.array([[BBOX[0], BBOX[3]]])); bx, by = to_px(np.array([[BBOX[2], BBOX[1]]]))
    R = (float(ax[0]), float(ay[0]), float(bx[0]), float(by[0]))

    open_runs, islands, sea_bodies = [], [], []
    for ch in chains:
        if ch[0] == ch[-1] and len(ch) >= 4:
            A = 0.0
            for k in range(len(ch) - 1):
                A += ch[k][0] * ch[k + 1][1] - ch[k + 1][0] * ch[k][1]
            (sea_bodies if A > 0 else islands).append(ch)      # y hacia abajo: A>0 = horario = el mar queda dentro
        else:
            ch = extend_to_rect(ch, R)
            open_runs.extend(clip_line(ch, *R))
    print("costa: %d tramos, %d cadenas, %d cerradas (islas %d, mares interiores %d), %d trozos dentro del extracto"
          % (len(ways), len(chains), len(islands) + len(sea_bodies), len(islands), len(sea_bodies), len(open_runs)))

    # 2) mar global (para saber si una tesela sin costa es mar o tierra)
    gpolys, loose = assemble(open_runs, R)
    print("polígonos de mar globales:", len(gpolys), " trozos con extremo suelto:", loose)

    # 3) mar por tesela: solo con los trozos de costa que la tocan
    segs = {}
    for rid, run in enumerate(open_runs):
        for i in range(len(run) - 1):
            p, q = run[i], run[i + 1]
            tx0, tx1 = tile_range(min(p[0], q[0]) - CLIP_M, max(p[0], q[0]) + CLIP_M)
            ty0, ty1 = tile_range(min(p[1], q[1]) - CLIP_M, max(p[1], q[1]) + CLIP_M)
            for ty in range(ty0, ty1 + 1):
                for tx in range(tx0, tx1 + 1):
                    segs.setdefault((tx, ty), []).append((rid, i))
    txa, txb = tile_range(R[0], R[2]); tya, tyb = tile_range(R[1], R[3])
    sea_only = []        # (tx, ty, rect) teselas sin costa: hay que decidir si son mar
    for ty in range(tya, tyb + 1):
        for tx in range(txa, txb + 1):
            ex0 = tx * TILE_PX - TILE_PX / 2 - CLIP_M; ey0 = ty * TILE_PX - TILE_PX / 2 - CLIP_M
            r = (max(ex0, R[0]), max(ey0, R[1]), min(ex0 + TILE_PX + 2 * CLIP_M, R[2]), min(ey0 + TILE_PX + 2 * CLIP_M, R[3]))
            if r[2] - r[0] < 1 or r[3] - r[1] < 1:
                continue
            lst = segs.get((tx, ty))
            if not lst:
                sea_only.append((tx, ty, r))
                continue
            lst.sort()
            subs, cur, last = [], [], None
            for rid, i in lst:
                run = open_runs[rid]
                if last is not None and last == (rid, i - 1):
                    cur.append(run[i + 1])
                else:
                    if cur: subs.append(cur)
                    cur = [run[i], run[i + 1]]
                last = (rid, i)
            if cur: subs.append(cur)
            runs = []
            for sub in subs:
                runs.extend(clip_line(sub, *r))
            polys, _ = assemble(runs, r)
            for poly in polys:
                poly = poly + [poly[0]]
                put((tx, ty), '{"type":"way","tags":{"natural":"water","sea":"1"},"clip":true,"pts":"%s"}' % flat(poly))
                stats["sea_tiles"] += 1
    if sea_only:
        cx = np.array([(r[0] + r[2]) / 2 for _, _, r in sea_only]); cy = np.array([(r[1] + r[3]) / 2 for _, _, r in sea_only])
        inside = np.zeros(len(sea_only), dtype=bool)
        for poly in gpolys:
            inside |= pip_many(poly, cx, cy)
        for (tx, ty, r), ins in zip(sea_only, inside):
            if ins:
                poly = [(r[0], r[1]), (r[2], r[1]), (r[2], r[3]), (r[0], r[3]), (r[0], r[1])]
                put((tx, ty), '{"type":"way","tags":{"natural":"water","sea":"1"},"clip":true,"pts":"%s"}' % flat(poly))
                stats["sea_tiles"] += 1

    global LAST_ISLANDS
    LAST_ISLANDS = islands          # (lo usa tools/build_overview.py)
    # 4) islas (tierra dentro del mar) y mares interiores cerrados
    for ch in islands:
        ll = np.array([lonlat(x, y) for x, y in ch])
        add_poly(ll, 3_000_000_000_000 + stats["island"], {"natural": "coastline"}, True, "island")
    for ch in sea_bodies:
        ll = np.array([lonlat(x, y) for x, y in ch])
        add_poly(ll, 3_100_000_000_000 + stats["island"], {"natural": "water", "sea": "1"}, True, "area")
    return gpolys, R


def main(path):
    db = sqlite3.connect("file:%s?mode=ro" % path, uri=True)

    # --- polígonos: edificios y terreno ---
    q = ("select id, geom, building, landuse, leisure, \"natural\", amenity, other_tags from multipolygons "
         "where building is not null or landuse is not null or leisure is not null or \"natural\" is not null")
    for fid, blob, building, landuse, leisure, natural, amenity, other in db.execute(q):
        g = parse_gpkg(blob)
        if not g:
            continue
        ot = hstore(other)
        for part, poly in enumerate(g[:64]):
            ring = poly[0]
            if len(ring) < 4:
                continue
            ident = 2_000_000_000_000 + fid * 64 + part
            if natural == "coastline":                     # cayos: tierra rodeada de mar
                add_poly(ring, 3_200_000_000_000 + fid * 64 + part, {"natural": "coastline"}, True, "island")
                continue
            if building and building != "no":
                tags = {"building": building}
                for k in ("height", "building:levels"):
                    if k in ot:
                        tags[k] = ot[k]
                worship = amenity == "place_of_worship" and ot.get("religion", "christian") not in NON_CHRISTIAN
                if building in CHURCH_B or (worship and building in ("yes", "church", "chapel")):
                    tags["church"] = "1"
                    stats["church"] += 1
                add_poly(ring, ident, tags, False, "building")
                continue
            if natural in NATURAL:
                tags = {"natural": natural}
            elif landuse in LANDUSE:
                tags = {"landuse": landuse}
            elif leisure in LEISURE:
                tags = {"leisure": leisure}
            else:
                continue
            add_poly(ring, ident, tags, True, "area")

    # --- líneas: calles, ríos, cercas y vías de tren ---
    q = ("select id, geom, highway, waterway, barrier, railway from lines "
         "where highway is not null or waterway is not null or barrier is not null or railway is not null")
    for fid, blob, highway, waterway, barrier, railway in db.execute(q):
        g = parse_gpkg(blob)
        if g is None or len(g) < 2:
            continue
        ident = 1_000_000_000_000 + fid
        if highway:
            add_line(g, ident, {"highway": highway}, "road")
        elif waterway in WATERWAY:
            add_line(g, ident, {"waterway": waterway}, "water")
        elif railway in RAIL:
            add_line(g, ident, {"railway": railway}, "rail")
        elif barrier in BARRIER:
            add_whole_line(g, {"barrier": BARRIER[barrier]}, "fence")
    # cercas y muros dibujados como polígono
    for blob, barrier in db.execute("select geom, barrier from multipolygons where barrier is not null"):
        g = parse_gpkg(blob)
        if g and barrier in BARRIER:
            for poly in g[:64]:
                if len(poly[0]) >= 4:
                    add_whole_line(poly[0], {"barrier": BARRIER[barrier]}, "fence")

    # --- árboles sueltos ---
    q = "select geom from points where other_tags like '%\"natural\"=>\"tree\"%'"
    for (blob,) in db.execute(q):
        g = parse_gpkg(blob)
        if not g:
            continue
        x, y = to_px(np.array([[g[0], g[1]]]))
        t = (math.floor((x[0] + TILE_PX / 2) / TILE_PX), math.floor((y[0] + TILE_PX / 2) / TILE_PX))
        put(t, '{"type":"node","tags":{"natural":"tree"},"lat":%.6f,"lon":%.6f}' % (g[1], g[0]))
        stats["tree"] += 1

    # --- mar ---
    gpolys, R = build_sea(db)
    sx, sy = 0.0, 0.0          # punto de aparición (origen)
    for poly in gpolys:
        if pip_many(poly, np.array([sx]), np.array([sy]))[0]:
            print("¡AVISO! el punto de aparición cae dentro del mar")

    # --- escribir ---
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)
    total = 0
    for (tx, ty), els in tiles.items():
        data = '{"elements":[%s]}' % ",".join(els)
        with open(os.path.join(OUT, "t_%d_%d.json" % (tx, ty)), "w", encoding="utf-8") as f:
            f.write(data)
        total += len(data.encode("utf-8"))
    xa, ya = to_px(np.array([[BBOX[0], BBOX[3]]])); xb, yb = to_px(np.array([[BBOX[2], BBOX[1]]]))
    t0 = tile_range(xa[0], xb[0]); t1 = tile_range(ya[0], yb[0])
    # una tesela solo cuenta como "cubierta" si cae entera dentro del extracto
    b = {"txMin": t0[0] + 1, "txMax": t0[1] - 1, "tyMin": t1[0] + 1, "tyMax": t1[1] - 1}
    with open(os.path.join(OUT, "bounds.json"), "w") as f:
        json.dump(b, f)
    print("zona cubierta (teselas):", b)
    print("teselas con datos:", len(tiles), " tamaño total: %.1f MB" % (total / 1e6))
    print(stats)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
