#!/usr/bin/env python3
"""
Convierte un extracto de OpenStreetMap en GeoPackage (BBBike) en "teselas" JSON que el juego
trae dentro del APK:  app/src/main/assets/base/t_X_Y.json

Uso:   python3 tools/build_tiles.py  ruta/al/archivo.gpkg
(Solo hace falta repetirlo si cambias el mapa. Necesita Python 3 y numpy.)

OJO: las constantes de abajo deben coincidir con Region.kt y World.kt.
"""
import json, math, os, shutil, sqlite3, struct, sys
import numpy as np

LAT0 = 20.892361111111       # punto de aparición = origen (0,0) del mundo
LON0 = -75.819483333333
M_LAT = 110540.0
M_LON = 111320.0 * math.cos(math.radians(LAT0))
PPM = 2.5                    # px del juego por metro
TILE_PX = 2048               # tamaño de una tesela en px (≈ 819 m)
CLIP_M = 48.0                # margen al recortar lo que cruza varias teselas (px)

# Zona que cubre el extracto (BBBike: lng_min, lat_min, lng_max, lat_max). Dentro de ella, una tesela
# sin archivo es mar o terreno vacío (no hace falta descargarla); fuera, el juego la descarga.
BBOX = (-76.731, 20.388, -74.647, 21.249)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(HERE), "app", "src", "main", "assets", "base")

# Lo mismo que entiende el motor (World.kt -> areaKind / Osm.query)
NATURAL = {"water", "wood", "scrub", "heath", "grassland", "sand", "beach"}
LANDUSE = {"forest", "grass", "meadow", "farmland", "farmyard", "orchard", "vineyard", "industrial",
           "commercial", "retail", "cemetery", "recreation_ground", "village_green", "reservoir", "basin"}
LEISURE = {"park", "garden", "playground", "pitch", "golf_course", "nature_reserve"}
WATERWAY = {"river", "stream", "canal"}


# ---------------------------------------------------------------- lectura de GeoPackage
def parse_gpkg(blob):
    flags = blob[3]
    if flags & 0x10:
        return None
    env = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}[(flags >> 1) & 7]
    return parse_wkb(blob, 8 + env)[0]


def parse_wkb(b, o):
    e = "<" if b[o] == 1 else ">"
    typ = struct.unpack_from(e + "I", b, o + 1)[0]
    o += 5
    base, z = typ % 1000, typ // 1000
    dim = 2 + (1 if z in (1, 3) else 0) + (1 if z in (2, 3) else 0)
    if base == 1:
        x, y = struct.unpack_from(e + "dd", b, o)
        return (x, y), o + 8 * dim
    if base == 2:
        n = struct.unpack_from(e + "I", b, o)[0]; o += 4
        a = np.frombuffer(b, dtype=e + "f8", count=n * dim, offset=o).reshape(n, dim)[:, :2]
        return a, o + 8 * n * dim
    if base == 3:
        nr = struct.unpack_from(e + "I", b, o)[0]; o += 4
        rings = []
        for _ in range(nr):
            n = struct.unpack_from(e + "I", b, o)[0]; o += 4
            a = np.frombuffer(b, dtype=e + "f8", count=n * dim, offset=o).reshape(n, dim)[:, :2]
            o += 8 * n * dim
            rings.append(a)
        return rings, o
    if base in (4, 5, 6, 7):
        n = struct.unpack_from(e + "I", b, o)[0]; o += 4
        parts = []
        for _ in range(n):
            g, o = parse_wkb(b, o)
            parts.append(g)
        return parts, o
    raise ValueError("geometría no soportada: %d" % typ)


def hstore(s):
    """other_tags de GDAL: "clave"=>"valor","clave2"=>"valor2" """
    d = {}
    if not s:
        return d
    i, n = 0, len(s)
    def rd(i):
        assert s[i] == '"'
        j, out = i + 1, []
        while s[j] != '"':
            if s[j] == "\\":
                j += 1
            out.append(s[j]); j += 1
        return "".join(out), j + 1
    while i < n:
        k, i = rd(i)
        i += 2                      # =>
        v, i = rd(i)
        d[k] = v
        if i < n and s[i] == ",":
            i += 1
    return d


# ---------------------------------------------------------------- geometría
def to_px(lonlat):
    return (lonlat[:, 0] - LON0) * M_LON * PPM, -(lonlat[:, 1] - LAT0) * M_LAT * PPM


def tile_range(v0, v1):
    return (math.floor((v0 + TILE_PX / 2) / TILE_PX), math.floor((v1 + TILE_PX / 2) / TILE_PX))


def clip_poly(pts, x0, y0, x1, y1):
    """Sutherland-Hodgman contra un rectángulo. pts: lista de (x, y) sin repetir el primero."""
    def run(pts, inside, inter):
        out = []
        if not pts:
            return out
        p = pts[-1]
        for q in pts:
            if inside(q):
                if not inside(p):
                    out.append(inter(p, q))
                out.append(q)
            elif inside(p):
                out.append(inter(p, q))
            p = q
        return out
    def ix(xc):
        return lambda p, q: (xc, p[1] + (q[1] - p[1]) * (xc - p[0]) / (q[0] - p[0]))
    def iy(yc):
        return lambda p, q: (p[0] + (q[0] - p[0]) * (yc - p[1]) / (q[1] - p[1]), yc)
    pts = run(pts, lambda p: p[0] >= x0, ix(x0))
    pts = run(pts, lambda p: p[0] <= x1, ix(x1))
    pts = run(pts, lambda p: p[1] >= y0, iy(y0))
    pts = run(pts, lambda p: p[1] <= y1, iy(y1))
    return pts


def clip_seg(p, q, x0, y0, x1, y1):
    """Liang-Barsky. Devuelve (a, b) recortados o None."""
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pp, qq in ((-dx, p[0] - x0), (dx, x1 - p[0]), (-dy, p[1] - y0), (dy, y1 - p[1])):
        if pp == 0:
            if qq < 0:
                return None
        else:
            r = qq / pp
            if pp < 0:
                if r > t1: return None
                if r > t0: t0 = r
            else:
                if r < t0: return None
                if r < t1: t1 = r
    return ((p[0] + t0 * dx, p[1] + t0 * dy), (p[0] + t1 * dx, p[1] + t1 * dy))


def clip_line(pts, x0, y0, x1, y1):
    runs, cur = [], []
    for i in range(len(pts) - 1):
        c = clip_seg(pts[i], pts[i + 1], x0, y0, x1, y1)
        if c is None:
            if len(cur) >= 2: runs.append(cur)
            cur = []
            continue
        a, b = c
        if not cur:
            cur = [a]
        cur.append(b)
        if b != pts[i + 1]:              # la línea sale del rectángulo
            if len(cur) >= 2: runs.append(cur)
            cur = []
    if len(cur) >= 2: runs.append(cur)
    return runs


def lonlat(x, y):
    return LON0 + x / (PPM * M_LON), LAT0 - y / (PPM * M_LAT)


def flat(pts_px):
    out = []
    for x, y in pts_px:
        lo, la = lonlat(x, y)
        out.append("%.6f,%.6f" % (lo, la))
    return ",".join(out)


def flat_ll(arr):
    return ",".join("%.6f,%.6f" % (a, b) for a, b in arr.tolist())


# ---------------------------------------------------------------- proceso
tiles = {}      # (tx, ty) -> [json de cada elemento]
stats = {"building": 0, "area": 0, "road": 0, "water": 0, "tree": 0, "clipped": 0}


def put(t, s):
    tiles.setdefault(t, []).append(s)


def tags_json(d):
    return json.dumps(d, separators=(",", ":"), ensure_ascii=False)


def add_poly(ring_ll, ident, tags, clip, kind):
    """ring_ll: (n,2) lon/lat, cerrado. clip=False para edificios."""
    xs, ys = to_px(ring_ll)
    tx0, tx1 = tile_range(xs.min(), xs.max())
    ty0, ty1 = tile_range(ys.min(), ys.max())
    stats[kind] += 1
    if not clip or (tx0 == tx1 and ty0 == ty1):
        s = '{"type":"way","id":%d,"tags":%s,"pts":[%s]}' % (ident, tags_json(tags), flat_ll(ring_ll))
        for ty in range(ty0, ty1 + 1):
            for tx in range(tx0, tx1 + 1):
                put((tx, ty), s)
        return
    pts = list(zip(xs.tolist(), ys.tolist()))[:-1]
    for ty in range(ty0, ty1 + 1):
        for tx in range(tx0, tx1 + 1):
            x0 = tx * TILE_PX - TILE_PX / 2 - CLIP_M; x1 = x0 + TILE_PX + 2 * CLIP_M
            y0 = ty * TILE_PX - TILE_PX / 2 - CLIP_M; y1 = y0 + TILE_PX + 2 * CLIP_M
            c = clip_poly(pts, x0, y0, x1, y1)
            if len(c) < 3:
                continue
            stats["clipped"] += 1
            c.append(c[0])
            put((tx, ty), '{"type":"way","tags":%s,"clip":true,"pts":[%s]}' % (tags_json(tags), flat(c)))


def add_line(line_ll, ident, tags, kind):
    xs, ys = to_px(line_ll)
    tx0, tx1 = tile_range(xs.min(), xs.max())
    ty0, ty1 = tile_range(ys.min(), ys.max())
    stats[kind] += 1
    if tx0 == tx1 and ty0 == ty1:
        put((tx0, ty0), '{"type":"way","id":%d,"tags":%s,"pts":[%s]}' % (ident, tags_json(tags), flat_ll(line_ll)))
        return
    pts = list(zip(xs.tolist(), ys.tolist()))
    for ty in range(ty0, ty1 + 1):
        for tx in range(tx0, tx1 + 1):
            x0 = tx * TILE_PX - TILE_PX / 2 - CLIP_M; x1 = x0 + TILE_PX + 2 * CLIP_M
            y0 = ty * TILE_PX - TILE_PX / 2 - CLIP_M; y1 = y0 + TILE_PX + 2 * CLIP_M
            for run in clip_line(pts, x0, y0, x1, y1):
                stats["clipped"] += 1
                put((tx, ty), '{"type":"way","tags":%s,"pts":[%s]}' % (tags_json(tags), flat(run)))


def main(path):
    db = sqlite3.connect("file:%s?mode=ro" % path, uri=True)

    # --- polígonos: edificios y terreno ---
    q = ("select id, geom, building, landuse, leisure, \"natural\", other_tags from multipolygons "
         "where building is not null or landuse is not null or leisure is not null or \"natural\" is not null")
    for fid, blob, building, landuse, leisure, natural, other in db.execute(q):
        g = parse_gpkg(blob)
        if not g:
            continue
        ot = hstore(other)
        for part, poly in enumerate(g[:64]):
            ring = poly[0]
            if len(ring) < 4:
                continue
            ident = 2_000_000_000_000 + fid * 64 + part
            if building and building != "no":
                tags = {"building": building}
                for k in ("height", "building:levels"):
                    if k in ot:
                        tags[k] = ot[k]
                add_poly(ring, ident, tags, False, "building")
                continue
            if natural in NATURAL:
                tags = {"natural": natural}
            elif landuse in LANDUSE:
                tags = {"landuse": landuse}
            elif leisure in LEISURE:
                tags = {"leisure": leisure}
            else:
                continue
            add_poly(ring, ident, tags, True, "area")

    # --- líneas: calles y ríos ---
    q = "select id, geom, highway, waterway from lines where highway is not null or waterway is not null"
    for fid, blob, highway, waterway in db.execute(q):
        g = parse_gpkg(blob)
        if g is None or len(g) < 2:
            continue
        ident = 1_000_000_000_000 + fid
        if highway:
            add_line(g, ident, {"highway": highway}, "road")
        elif waterway in WATERWAY:
            add_line(g, ident, {"waterway": waterway}, "water")

    # --- árboles sueltos ---
    q = "select geom from points where other_tags like '%\"natural\"=>\"tree\"%'"
    for (blob,) in db.execute(q):
        g = parse_gpkg(blob)
        if not g:
            continue
        x, y = to_px(np.array([[g[0], g[1]]]))
        t = (math.floor((x[0] + TILE_PX / 2) / TILE_PX), math.floor((y[0] + TILE_PX / 2) / TILE_PX))
        put(t, '{"type":"node","tags":{"natural":"tree"},"lat":%.6f,"lon":%.6f}' % (g[1], g[0]))
        stats["tree"] += 1

    # --- escribir ---
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)
    total = 0
    for (tx, ty), els in tiles.items():
        data = '{"elements":[%s]}' % ",".join(els)
        with open(os.path.join(OUT, "t_%d_%d.json" % (tx, ty)), "w", encoding="utf-8") as f:
            f.write(data)
        total += len(data.encode("utf-8"))
    xa, ya = to_px(np.array([[BBOX[0], BBOX[3]]])); xb, yb = to_px(np.array([[BBOX[2], BBOX[1]]]))
    t0 = tile_range(xa[0], xb[0]); t1 = tile_range(ya[0], yb[0])
    # una tesela solo cuenta como "cubierta" si cae entera dentro del extracto
    b = {"txMin": t0[0] + 1, "txMax": t0[1] - 1, "tyMin": t1[0] + 1, "tyMax": t1[1] - 1}
    with open(os.path.join(OUT, "bounds.json"), "w") as f:
        json.dump(b, f)
    print("zona cubierta (teselas):", b)
    print("teselas con datos:", len(tiles), " tamaño total: %.1f MB" % (total / 1e6))
    print(stats)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
