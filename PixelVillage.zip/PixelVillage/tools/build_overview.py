#!/usr/bin/env python3
"""
Dibuja el MAPA DEL MUNDO que se abre con el botón "Mapa" del juego.

Uso:   python3 tools/build_overview.py  ruta/al/archivo.gpkg
Genera en app/src/main/assets/map/:
  - z0..z4/X_Y.webp : teselas de 256x256 en 5 niveles de zoom (z0 = 16 m/px ... z4 = 256 m/px).
                      Cada nivel se dibuja por separado y con menos detalle cuanto más lejos
                      (caminos pequeños y casas solo de cerca; pueblos como manchas de lejos).
  - index.json      : origen, tamaño y qué teselas existen (las que son de un solo color no tienen archivo).
  - places.json     : nombres de pueblos [nombre, tipo, lon, lat]  (0 ciudad, 1 pueblo, 2 aldea, 3 caserío).

Las constantes de Region y BBOX vienen de tools/build_tiles.py (el mapa del juego y este mapa coinciden).
"""
import json, math, os, shutil, sqlite3, sys
import numpy as np
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_tiles as bt

OUT = os.path.join(os.path.dirname(HERE), "app", "src", "main", "assets", "map")
BASE_M = 16.0                      # metros por píxel del nivel más cercano
LEVELS = 5
TILE = 256

PAL = [
    (205, 200, 182),  # 0 suelo
    (222, 214, 172),  # 1 cultivos
    (186, 200, 140),  # 2 prados y parques
    (166, 178, 122),  # 3 matorral
    (118, 140, 96),   # 4 bosque
    (150, 174, 150),  # 5 humedal
    (176, 166, 156),  # 6 zona urbana
    (150, 138, 128),  # 7 vertedero
    (232, 222, 176),  # 8 arena
    (96, 134, 160),   # 9 lagos y ríos
    (74, 110, 138),   # 10 mar
    (150, 138, 130),  # 11 edificios
    (252, 250, 243),  # 12 calle
    (255, 222, 120),  # 13 carretera principal
    (176, 160, 120),  # 14 borde de carretera
    (88, 84, 82),     # 15 vía de tren
    (255, 240, 170),  # 16 carretera secundaria
    (196, 186, 166),  # 17 sendero
]
GROUND, FARM, GRASS, SCRUB, FOREST, WET, URBAN, DUMP, SAND, WATER, SEA, BLD, ST, MAJOR, CASING, RAIL, SECOND, PATH = range(18)

# ancho (px) por nivel 0..4; 0 = no se dibuja en ese nivel
ROAD = {
    "motorway": (MAJOR, (3, 3, 3, 3, 2), True), "trunk": (MAJOR, (3, 3, 3, 3, 2), True), "primary": (MAJOR, (3, 3, 3, 3, 2), True),
    "motorway_link": (MAJOR, (2, 2, 2, 0, 0), True), "trunk_link": (MAJOR, (2, 2, 2, 0, 0), True), "primary_link": (MAJOR, (2, 2, 2, 0, 0), True),
    "secondary": (SECOND, (3, 2, 2, 2, 2), True), "secondary_link": (SECOND, (2, 1, 1, 0, 0), False),
    "tertiary": (ST, (2, 2, 2, 1, 1), True), "tertiary_link": (ST, (1, 1, 1, 0, 0), False),
    "residential": (ST, (1, 1, 1, 0, 0), False), "unclassified": (ST, (1, 1, 1, 0, 0), False),
    "living_street": (ST, (1, 1, 0, 0, 0), False), "road": (ST, (1, 1, 0, 0, 0), False),
    "service": (ST, (1, 1, 0, 0, 0), False), "track": (PATH, (1, 1, 0, 0, 0), False),
    "path": (PATH, (1, 0, 0, 0, 0), False), "footway": (PATH, (1, 0, 0, 0, 0), False),
    "cycleway": (PATH, (1, 0, 0, 0, 0), False), "steps": (PATH, (1, 0, 0, 0, 0), False),
    "bridleway": (PATH, (1, 0, 0, 0, 0), False), "pedestrian": (ST, (1, 1, 0, 0, 0), False),
}
ROAD_ORDER = [PATH, ST, SECOND, MAJOR]
WATERWAY = {"river": (3, 3, 3, 2, 1), "canal": (1, 1, 1, 0, 0), "stream": (1, 1, 0, 0, 0)}
PLACE_T = {"city": 0, "town": 1, "village": 2, "hamlet": 3}

AREA_COLOR = {  # (columna, valor) -> (índice de color, orden de dibujo)
    ("landuse", "farmland"): (FARM, 0), ("landuse", "orchard"): (FARM, 0), ("landuse", "vineyard"): (FARM, 0),
    ("landuse", "farmyard"): (FARM, 0),
    ("landuse", "grass"): (GRASS, 1), ("landuse", "meadow"): (GRASS, 1), ("landuse", "village_green"): (GRASS, 1),
    ("landuse", "recreation_ground"): (GRASS, 1), ("landuse", "cemetery"): (GRASS, 1),
    ("natural", "grassland"): (GRASS, 1),
    ("leisure", "park"): (GRASS, 1), ("leisure", "garden"): (GRASS, 1), ("leisure", "golf_course"): (GRASS, 1),
    ("leisure", "pitch"): (GRASS, 1), ("leisure", "playground"): (GRASS, 1), ("leisure", "nature_reserve"): (GRASS, 1),
    ("natural", "scrub"): (SCRUB, 2), ("natural", "heath"): (SCRUB, 2),
    ("natural", "sand"): (SAND, 2), ("natural", "beach"): (SAND, 2),
    ("natural", "wood"): (FOREST, 3), ("landuse", "forest"): (FOREST, 3),
    ("natural", "wetland"): (WET, 4), ("natural", "mud"): (WET, 4),
    ("landuse", "residential"): (URBAN, 5), ("landuse", "commercial"): (URBAN, 5), ("landuse", "retail"): (URBAN, 5),
    ("landuse", "industrial"): (URBAN, 5), ("landuse", "landfill"): (DUMP, 5),
    ("natural", "water"): (WATER, 6), ("landuse", "reservoir"): (WATER, 6), ("landuse", "basin"): (WATER, 6),
}


def main(path):
    db = sqlite3.connect("file:%s?mode=ro" % path, uri=True)
    ax, ay = bt.to_px(np.array([[bt.BBOX[0], bt.BBOX[3]]])); bx, by = bt.to_px(np.array([[bt.BBOX[2], bt.BBOX[1]]]))
    X0, Y0, X1, Y1 = float(ax[0]), float(ay[0]), float(bx[0]), float(by[0])
    base_px = BASE_M * bt.PPM                                   # px del juego por píxel de imagen en z0

    # ---------- leer geometrías (en px del juego) ----------
    areas = []      # (orden, color, xs, ys)
    buildings = []  # (xs, ys)
    q = ("select geom, building, landuse, leisure, \"natural\" from multipolygons "
         "where building is not null or landuse is not null or leisure is not null or \"natural\" is not null")
    for blob, building, landuse, leisure, natural in db.execute(q):
        if natural == "coastline":
            continue
        g = bt.parse_gpkg(blob)
        if not g:
            continue
        spec = None
        if building and building != "no":
            spec = "b"
        else:
            for col, val in (("natural", natural), ("landuse", landuse), ("leisure", leisure)):
                if (col, val) in AREA_COLOR:
                    spec = AREA_COLOR[(col, val)]; break
        if spec is None:
            continue
        for poly in g[:64]:
            ring = poly[0]
            if len(ring) < 4:
                continue
            x, y = bt.to_px(ring)
            if spec == "b":
                buildings.append((x, y))
            else:
                areas.append((spec[1], spec[0], x, y))
    areas.sort(key=lambda a: a[0])

    roads = {k: [] for k in ROAD_ORDER}
    rivers, rails = [], []
    q = "select geom, highway, waterway, railway from lines where highway is not null or waterway is not null or railway is not null"
    for blob, hw, ww, rw in db.execute(q):
        g = bt.parse_gpkg(blob)
        if g is None or len(g) < 2:
            continue
        x, y = bt.to_px(g)
        if hw in ROAD:
            col, widths, _ = ROAD[hw]
            roads[col].append((hw, x, y))
        elif ww in WATERWAY:
            rivers.append((ww, x, y))
        elif rw in bt.RAIL:
            rails.append((x, y))

    gpolys, _R = bt.build_sea(db)                                 # mar (polígonos en px del juego)
    islands = [[(p[0], p[1]) for p in ch] for ch in bt.LAST_ISLANDS]
    for blob, in db.execute("select geom from multipolygons where \"natural\"='coastline'"):
        g = bt.parse_gpkg(blob)
        for poly in (g or [])[:64]:
            x, y = bt.to_px(poly[0]); islands.append(list(zip(x.tolist(), y.tolist())))

    places = []
    for name, place, lon_lat in [(r[0], r[1], bt.parse_gpkg(r[2])) for r in
                                 db.execute("select name, place, geom from points where place in ('city','town','village','hamlet') and name is not null")]:
        if lon_lat is not None:
            places.append([name, PLACE_T[place], round(lon_lat[0], 5), round(lon_lat[1], 5)])
    places.sort(key=lambda p: p[1])
    print("geometrías: %d áreas, %d edificios, %d calles, %d ríos, %d vías, %d polígonos de mar, %d islas, %d pueblos" % (
        len(areas), len(buildings), sum(len(v) for v in roads.values()), len(rivers), len(rails), len(gpolys), len(islands), len(places)))

    # ---------- dibujar y trocear cada nivel ----------
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)
    index = {"x0": X0, "y0": Y0, "base": base_px, "tile": TILE, "levels": LEVELS, "w0": 0, "h0": 0, "tiles": {}, "solid": {}}
    flat_pal = [c for rgb in PAL for c in rgb]
    total_bytes = 0
    for z in range(LEVELS):
        p = base_px * (2 ** z)
        W = int(math.ceil((X1 - X0) / p)); H = int(math.ceil((Y1 - Y0) / p))
        if z == 0:
            index["w0"], index["h0"] = W, H
        img = Image.new("P", (W, H), GROUND)
        img.putpalette(flat_pal)
        d = ImageDraw.Draw(img)

        def pts(x, y):
            return list(zip(((x - X0) / p).tolist(), ((y - Y0) / p).tolist()))

        for _o, col, x, y in areas:
            if max(x.max() - x.min(), y.max() - y.min()) / p < 0.8:
                continue
            d.polygon(pts(x, y), fill=col)
        for poly in gpolys:
            d.polygon([((px - X0) / p, (py - Y0) / p) for px, py in poly], fill=SEA)
        for isl in islands:
            d.polygon([((px - X0) / p, (py - Y0) / p) for px, py in isl], fill=GROUND)
        for ww, x, y in rivers:
            w = WATERWAY[ww][z]
            if w:
                d.line(pts(x, y), fill=WATER, width=w, joint="curve")
        if z <= 1:
            for x, y in buildings:
                d.polygon(pts(x, y), fill=BLD)
        for col in ROAD_ORDER:                                    # de menos a más importante
            for pass_casing in (True, False):
                for hw, x, y in roads[col]:
                    _c, widths, casing = ROAD[hw]
                    w = widths[z]
                    if not w or (pass_casing and not casing):
                        continue
                    d.line(pts(x, y), fill=CASING if pass_casing else col, width=w + 2 if pass_casing else w, joint="curve")
        for x, y in rails:
            d.line(pts(x, y), fill=RAIL, width=1)

        n_files = 0
        keys, solid = [], {}
        for ty in range(0, int(math.ceil(H / TILE))):
            for tx in range(0, int(math.ceil(W / TILE))):
                tile = img.crop((tx * TILE, ty * TILE, tx * TILE + TILE, ty * TILE + TILE))
                lo, hi = tile.getextrema()
                if lo == hi:                                       # un solo color: sin archivo
                    solid["%d_%d" % (tx, ty)] = "%02x%02x%02x" % PAL[lo]
                    continue
                zdir = os.path.join(OUT, "z%d" % z); os.makedirs(zdir, exist_ok=True)
                f = os.path.join(zdir, "%d_%d.webp" % (tx, ty))
                tile.convert("RGB").save(f, "WEBP", lossless=True, quality=100, method=6)
                total_bytes += os.path.getsize(f); n_files += 1
                keys.append("%d_%d" % (tx, ty))
        index["tiles"][str(z)] = keys
        index["solid"][str(z)] = solid
        print("z%d: imagen %dx%d (%.1f m/px), %d teselas con archivo, %d lisas" % (z, W, H, BASE_M * 2 ** z, n_files, len(solid)))
        del img, d

    with open(os.path.join(OUT, "index.json"), "w") as f:
        json.dump(index, f, separators=(",", ":"))
    with open(os.path.join(OUT, "places.json"), "w", encoding="utf-8") as f:
        json.dump(places, f, ensure_ascii=False, separators=(",", ":"))
    print("tamaño de las teselas: %.1f MB" % (total_bytes / 1e6))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
