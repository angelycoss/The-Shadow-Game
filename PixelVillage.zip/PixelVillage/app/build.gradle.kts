plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ── VERSIÓN DEL JUEGO ── Para publicar una nueva versión solo hay que cambiar esta línea (0.0.1 → 0.0.2 …).
// El versionCode se deriva solo (mayor*10000 + menor*100 + parche) para que Android permita actualizar instalando encima.
val gameVersion = "0.0.2"
val gameVersionCode = gameVersion.split(".").let { it[0].toInt() * 10000 + it[1].toInt() * 100 + it[2].toInt() }

android {
    namespace = "com.pixelvillage"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pixelvillage"
        minSdk = 24
        targetSdk = 34
        versionCode = gameVersionCode
        versionName = gameVersion
    }

    // Clave fija incluida en el repo: todas las compilaciones llevan la misma firma, así se puede instalar una versión sobre otra.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// Sin dependencias externas: APK pequeño y arranque rápido.
