package com.pixelvillage

/** Animales del mapa (raros). Oveja, cerdo y gallina son dóciles; los demás se espantan si te acercas. */
object Species {
    const val SHEEP = 0
    const val PIG = 1
    const val CHICKEN = 2
    const val COW = 3
    const val TURKEY = 4
    const val GOAT = 5
    const val CAT = 6
    const val DOG = 7
    val NAMES = arrayOf("oveja", "cerdo", "gallina", "vaca", "pavo", "chivo", "gato", "perro")
    fun docile(s: Int) = s <= CHICKEN
    /** Probabilidad de lograr atarlo al primer intento. */
    fun tieChance(s: Int) = when (s) { SHEEP, PIG, CHICKEN -> 1f; COW, DOG -> 0.6f; else -> 0.4f }
    /** Velocidad al caminar y al huir (px/s). */
    fun walk(s: Int) = when (s) { CHICKEN, TURKEY, CAT -> 6f; else -> 4f }
}

class Animal(val key: Long, val species: Int, var x: Float, var y: Float) {
    var tied = false
    var homeX = x
    var homeY = y
    var dirX = 0f
    var dirY = 0f
    var wanderT = 0f
    var fleeT = 0f
    var face = 1f
    var phase = 0f
    var moving = false

    fun encode() = "$key,$species,$x,$y"

    companion object {
        fun decode(s: String): Animal? {
            val f = s.split(',')
            if (f.size < 4) return null
            return try {
                Animal(f[0].toLong(), f[1].toInt(), f[2].toFloat(), f[3].toFloat()).also { it.tied = true }
            } catch (e: Exception) { null }
        }
    }
}
