package com.pixelvillage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Pantalla del mapa del mundo (botón "Mapa").
 *
 * El mapa viene dibujado de antemano (tools/build_overview.py) en 5 niveles de zoom: z0 = 16 m por píxel
 * ... z4 = 256 m por píxel, cortados en teselas de 256x256 en assets/map/. Aquí solo se elige el nivel que
 * corresponde al zoom actual y se pintan las teselas visibles; las teselas se cargan en un hilo aparte
 * y se guardan en una caché (las últimas 96). Mientras una tesela carga se ve la del nivel más lejano.
 *
 * Gestos: arrastrar = mover, pellizcar = zoom, doble toque = acercar. Botones: + / − / Aquí / Cerrar.
 */
class WorldMap(private val ctx: Context) {
    private class Place(val name: String, val type: Int, val x: Float, val y: Float)

    // ---- datos del mapa (assets/map/index.json) ----
    @Volatile private var ready = false
    @Volatile private var failed = false
    @Volatile private var preparing = false
    private var x0 = 0f
    private var y0 = 0f
    private var base = 40f                      // px del juego por píxel de imagen en z0
    private var tileSize = 256
    private var levels = 5
    private var w0 = 1
    private var h0 = 1
    private var have: Array<HashSet<Long>> = emptyArray()
    private var solid: Array<HashMap<Long, Int>> = emptyArray()
    private var alias: Array<HashMap<Long, Long>> = emptyArray()      // tesela repetida -> tesela que tiene el archivo
    private var places: List<Place> = emptyList()

    // ---- caché de teselas ----
    private val cache = object : LinkedHashMap<Long, Bitmap>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, Bitmap>) = size > 96
    }
    private val pending: MutableSet<Long> = ConcurrentHashMap.newKeySet()
    private val loader = Executors.newSingleThreadExecutor { r -> Thread(r, "map").also { it.isDaemon = true } }

    // ---- vista ----
    private var cx = 0f                        // centro de la vista (px del juego)
    private var cy = 0f
    private var zoom = 0.01f                   // px de pantalla por px del juego
    private var zMin = 0.001f
    private var zMax = 0.1f
    private var viewW = 1
    private var viewH = 1
    private var density = 1f
    @Volatile private var initPending = true

    private val tilePaint = Paint().apply { isFilterBitmap = true; isAntiAlias = false }
    private val fillP = Paint()
    private val ui = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tri = Path()
    private val placed = ArrayList<RectF>()
    private val tmp = RectF()

    /** Al abrir: carga los datos si hace falta y centra el mapa en el jugador. */
    fun open() {
        initPending = true
        prepare()
    }

    private fun prepare() {
        if (ready || failed || preparing) return
        preparing = true
        loader.execute {
            try {
                val idx = JSONObject(readAsset("map/index.json"))
                x0 = idx.getDouble("x0").toFloat(); y0 = idx.getDouble("y0").toFloat()
                base = idx.getDouble("base").toFloat()
                tileSize = idx.getInt("tile"); levels = idx.getInt("levels")
                w0 = idx.getInt("w0"); h0 = idx.getInt("h0")
                val tj = idx.getJSONObject("tiles"); val sj = idx.getJSONObject("solid")
                have = Array(levels) { z ->
                    val set = HashSet<Long>()
                    val arr = tj.getJSONArray(z.toString())
                    for (i in 0 until arr.length()) parseKey(z, arr.getString(i))?.let { set.add(it) }
                    set
                }
                solid = Array(levels) { z ->
                    val m = HashMap<Long, Int>()
                    val o = sj.getJSONObject(z.toString())
                    for (name in o.keys()) {
                        val k = parseKey(z, name) ?: continue
                        m[k] = 0xFF000000.toInt() or o.getString(name).toInt(16)
                    }
                    m
                }
                val aj = idx.getJSONObject("alias")
                alias = Array(levels) { z ->
                    val m = HashMap<Long, Long>()
                    val o = aj.getJSONObject(z.toString())
                    for (name in o.keys()) {
                        val a = parseKey(z, name) ?: continue
                        val b = parseKey(z, o.getString(name)) ?: continue
                        m[a] = b
                    }
                    m
                }
                val pj = JSONArray(readAsset("map/places.json"))
                val list = ArrayList<Place>(pj.length())
                for (i in 0 until pj.length()) {
                    val p = pj.getJSONArray(i)
                    list.add(Place(p.getString(0), p.getInt(1), Region.px(p.getDouble(2)), Region.py(p.getDouble(3))))
                }
                places = list
                ready = true
            } catch (e: Throwable) {
                failed = true
            } finally {
                preparing = false
            }
        }
    }

    private fun readAsset(name: String) = ctx.assets.open(name).bufferedReader().use { it.readText() }

    private fun key(z: Int, tx: Int, ty: Int) = (z.toLong() shl 48) or (tx.toLong() shl 24) or ty.toLong()

    private fun parseKey(z: Int, s: String): Long? {
        val i = s.indexOf('_')
        if (i < 0) return null
        val tx = s.substring(0, i).toIntOrNull() ?: return null
        val ty = s.substring(i + 1).toIntOrNull() ?: return null
        return key(z, tx, ty)
    }

    private fun canon(z: Int, k: Long): Long = alias[z][k] ?: k

    private fun bitmap(k0: Long, z: Int): Bitmap? {
        val k = canon(z, k0)
        val tx = ((k shr 24) and 0xFFFFFF).toInt(); val ty = (k and 0xFFFFFF).toInt()
        synchronized(cache) { cache[k]?.let { return it } }
        if (pending.add(k)) {
            loader.execute {
                try {
                    val o = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
                    val b = ctx.assets.open("map/z$z/${tx}_$ty.png").use { BitmapFactory.decodeStream(it, null, o) }
                    if (b != null) synchronized(cache) { cache[k] = b }
                } catch (e: Throwable) {
                } finally {
                    pending.remove(k)
                }
            }
        }
        return null
    }

    // ---------- dibujo ----------

    fun draw(c: Canvas, w: Int, h: Int, density: Float, playerX: Float, playerY: Float) {
        viewW = w; viewH = h; this.density = density
        c.drawColor(GROUND)
        if (!ready) {
            label(c, if (failed) "No se pudo cargar el mapa" else "Cargando el mapa…", w / 2f, h / 2f, 15f * density, DARK, false)
            drawButtons(c, w, h)
            return
        }
        val worldW = w0 * base; val worldH = h0 * base
        zMin = min(w / worldW, h / worldH)
        zMax = 4f / base                                   // 4 px de pantalla por píxel de la imagen más cercana
        if (initPending) {
            cx = playerX; cy = playerY
            zoom = (0.5f / base).coerceIn(zMin, zMax)      // al abrir: unos 30 km de ancho alrededor del jugador
            initPending = false
        }
        zoom = zoom.coerceIn(zMin, zMax)
        clampCenter()

        val s0 = base * zoom                               // px de pantalla por píxel de z0
        val z = (-ln(s0) / ln(2f)).roundToInt().coerceIn(0, levels - 1)
        val tw = tileSize * base * (1 shl z)               // px del juego que cubre una tesela
        val nx = ceil(ceil(w0 / (1 shl z).toFloat()) / tileSize).toInt()
        val ny = ceil(ceil(h0 / (1 shl z).toFloat()) / tileSize).toInt()
        val left = cx - w / 2f / zoom; val right = cx + w / 2f / zoom
        val top = cy - h / 2f / zoom; val bottom = cy + h / 2f / zoom
        val tx0 = max(0, floor((left - x0) / tw).toInt()); val tx1 = min(nx - 1, floor((right - x0) / tw).toInt())
        val ty0 = max(0, floor((top - y0) / tw).toInt()); val ty1 = min(ny - 1, floor((bottom - y0) / tw).toInt())
        val dst = RectF()
        for (ty in ty0..ty1) for (tx in tx0..tx1) {
            val dl = (x0 + tx * tw - cx) * zoom + w / 2f
            val dt = (y0 + ty * tw - cy) * zoom + h / 2f
            dst.set(floor(dl), floor(dt), ceil(dl + tw * zoom), ceil(dt + tw * zoom))
            val k = key(z, tx, ty)
            val col = solid[z][k]
            if (col != null) {
                fillP.color = col; c.drawRect(dst, fillP)
            } else if (have[z].contains(k)) {
                val b = bitmap(k, z)
                if (b != null) c.drawBitmap(b, null, dst, tilePaint) else fallback(c, z, tx, ty, dst)
            }
        }

        drawPlaces(c, w, h, s0)
        drawFrame(c, w, h)
        drawPlayer(c, w, h, playerX, playerY)
        drawButtons(c, w, h)
        drawScale(c, h)
    }

    /** Mientras carga una tesela, se pinta la parte que le toca de la tesela de un nivel más lejano. */
    private fun fallback(c: Canvas, z: Int, tx: Int, ty: Int, dst: RectF) {
        for (zz in z + 1 until levels) {
            val dz = zz - z
            val ptx = tx shr dz; val pty = ty shr dz
            val pk = key(zz, ptx, pty)
            val col = solid[zz][pk]
            if (col != null) { fillP.color = col; c.drawRect(dst, fillP); return }
            val b = synchronized(cache) { cache[canon(zz, pk)] } ?: continue
            val sz = tileSize shr dz
            val sl = (tx - (ptx shl dz)) * sz; val st = (ty - (pty shl dz)) * sz
            c.drawBitmap(b, Rect(sl, st, sl + sz, st + sz), dst, tilePaint)
            return
        }
    }

    /** Nombres de pueblos: los grandes siempre, los pequeños solo al acercar; sin que se pisen. */
    private fun drawPlaces(c: Canvas, w: Int, h: Int, s0: Float) {
        placed.clear()
        for (p in places) {
            if (p.type == 2 && s0 < 0.18f) continue          // aldeas
            if (p.type == 3 && s0 < 0.5f) continue           // caseríos
            val x = (p.x - cx) * zoom + w / 2f
            val y = (p.y - cy) * zoom + h / 2f
            if (x < -120f * density || x > w + 120f * density || y < -30f * density || y > h + 30f * density) continue
            val size = when (p.type) { 0 -> 16f; 1 -> 13f; 2 -> 11.5f; else -> 10.5f } * density
            text.textSize = size
            text.typeface = if (p.type <= 1) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
            val tw = text.measureText(p.name)
            val lx = x + 6f * density
            tmp.set(lx - 2f * density, y - size * 0.7f, lx + tw + 2f * density, y + size * 0.4f)
            var hit = false
            for (r in placed) if (RectF.intersects(r, tmp)) { hit = true; break }
            if (hit) continue
            placed.add(RectF(tmp))
            val dot = (if (p.type == 0) 4.5f else if (p.type == 1) 3.5f else 2.6f) * density
            ui.style = Paint.Style.FILL; ui.color = Color.WHITE
            c.drawRect(x - dot - 1.5f * density, y - dot - 1.5f * density, x + dot + 1.5f * density, y + dot + 1.5f * density, ui)
            ui.color = DARK
            c.drawRect(x - dot, y - dot, x + dot, y + dot, ui)
            text.textAlign = Paint.Align.LEFT
            text.style = Paint.Style.STROKE; text.strokeWidth = 3.6f * density; text.color = DARK
            c.drawText(p.name, lx, y + size * 0.3f, text)
            text.style = Paint.Style.FILL; text.color = Color.WHITE
            c.drawText(p.name, lx, y + size * 0.3f, text)
        }
    }

    /** Punto rojo donde está el jugador (con un aro que late). Si queda fuera de la pantalla, una flecha en el borde. */
    private fun drawPlayer(c: Canvas, w: Int, h: Int, playerX: Float, playerY: Float) {
        val x = (playerX - cx) * zoom + w / 2f
        val y = (playerY - cy) * zoom + h / 2f
        val m = 18f * density
        if (x < m || x > w - m || y < m || y > h - m) {
            val ang = atan2(y - h / 2f, x - w / 2f)
            // punto del borde de la pantalla en la dirección del jugador
            val t = min(
                if (cos(ang) != 0f) ((if (cos(ang) > 0) w - m else m) - w / 2f) / cos(ang) else 1e9f,
                if (sin(ang) != 0f) ((if (sin(ang) > 0) h - m else m) - h / 2f) / sin(ang) else 1e9f
            )
            val bx = w / 2f + cos(ang) * t; val by = h / 2f + sin(ang) * t
            val r = 10f * density
            tri.rewind()
            tri.moveTo(bx + cos(ang) * r, by + sin(ang) * r)
            tri.lineTo(bx + cos(ang + 2.5f) * r, by + sin(ang + 2.5f) * r)
            tri.lineTo(bx + cos(ang - 2.5f) * r, by + sin(ang - 2.5f) * r)
            tri.close()
            ui.style = Paint.Style.FILL; ui.color = RED
            c.drawPath(tri, ui)
            ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density; ui.color = Color.WHITE
            c.drawPath(tri, ui)
            return
        }
        val ph = (SystemClock.uptimeMillis() % 1400L) / 1400f
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 2.5f * density
        ui.color = Color.argb(((1f - ph) * 170f).toInt(), 229, 57, 53)
        c.drawCircle(x, y, (7f + 14f * ph) * density, ui)
        ui.style = Paint.Style.FILL; ui.color = Color.WHITE
        c.drawCircle(x, y, 8f * density, ui)
        ui.color = RED
        c.drawCircle(x, y, 6f * density, ui)
    }

    /** Marco de tinta con filo blanco, como una lámina del juego. */
    private fun drawFrame(c: Canvas, w: Int, h: Int) {
        val t = 6f * density
        ui.style = Paint.Style.STROKE; ui.strokeWidth = t; ui.color = DARK
        c.drawRect(t / 2f, t / 2f, w - t / 2f, h - t / 2f, ui)
        ui.strokeWidth = 1.5f * density; ui.color = CREAM
        c.drawRect(t + 2f * density, t + 2f * density, w - t - 2f * density, h - t - 2f * density, ui)
    }

    // ---------- botones y escala ----------

    private fun closeRect(w: Int) = RectF(w - 92f * density, 12f * density, w - 12f * density, 56f * density)
    private fun plusRect(w: Int, h: Int) = RectF(w - 56f * density, h / 2f - 54f * density, w - 12f * density, h / 2f - 10f * density)
    private fun minusRect(w: Int, h: Int) = RectF(w - 56f * density, h / 2f + 10f * density, w - 12f * density, h / 2f + 54f * density)
    private fun meRect(w: Int, h: Int) = RectF(w - 56f * density, h / 2f + 64f * density, w - 12f * density, h / 2f + 108f * density)

    private fun drawButtons(c: Canvas, w: Int, h: Int) {
        box(c, closeRect(w), "Cerrar")
        if (!ready) return
        box(c, plusRect(w, h), "+")
        box(c, minusRect(w, h), "−")
        box(c, meRect(w, h), "Aquí")
        // título
        text.textSize = 13f * density; text.typeface = Typeface.MONOSPACE
        val title = "MAPA DEL MUNDO"
        val tw = text.measureText(title)
        val r = RectF(12f * density, 12f * density, 12f * density + tw + 20f * density, 44f * density)
        ui.style = Paint.Style.FILL; ui.color = Color.rgb(14, 14, 16)
        c.drawRect(r, ui)
        text.textAlign = Paint.Align.LEFT; text.style = Paint.Style.FILL; text.color = CREAM
        c.drawText(title, r.left + 10f * density, r.centerY() + 4.5f * density, text)
    }

    private fun box(c: Canvas, r: RectF, s: String) {
        ui.style = Paint.Style.FILL; ui.color = Color.rgb(14, 14, 16)
        c.drawRect(r, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density; ui.color = CREAM
        c.drawRect(r, ui)
        tmp.set(r.left + 4f * density, r.top + 4f * density, r.right - 4f * density, r.bottom - 4f * density)
        ui.strokeWidth = 1f * density; ui.color = Color.argb(110, 234, 233, 219)
        c.drawRect(tmp, ui)
        label(c, s, r.centerX(), r.centerY(), (if (s.length > 2) 12f else 20f) * density, CREAM, true)
    }

    private fun label(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, mono: Boolean) {
        text.typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
        text.textSize = size; text.textAlign = Paint.Align.CENTER; text.style = Paint.Style.FILL; text.color = color
        c.drawText(s, x, y + size * 0.35f, text)
    }

    /** Regla de escala abajo a la izquierda (metros / kilómetros). */
    private fun drawScale(c: Canvas, h: Int) {
        val target = 110f * density
        val metersPerPx = 1f / (zoom * PPM)
        val steps = floatArrayOf(50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f, 50000f, 100000f)
        var m = steps[0]
        for (s in steps) if (s / metersPerPx <= target) m = s
        val len = m / metersPerPx
        val l = 14f * density; val y = h - 22f * density
        val txt = if (m >= 1000f) "${(m / 1000f).toInt()} km" else "${m.toInt()} m"
        text.textSize = 12f * density; text.typeface = Typeface.MONOSPACE
        val tw = text.measureText(txt)
        val bg = RectF(l - 8f * density, y - 24f * density, l + max(len, tw) + 8f * density, y + 10f * density)
        ui.style = Paint.Style.FILL; ui.color = Color.rgb(14, 14, 16)
        c.drawRect(bg, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density; ui.color = CREAM
        c.drawLine(l, y, l + len, y, ui)
        c.drawLine(l, y - 4f * density, l, y + 4f * density, ui)
        c.drawLine(l + len, y - 4f * density, l + len, y + 4f * density, ui)
        text.textAlign = Paint.Align.LEFT; text.style = Paint.Style.FILL; text.color = CREAM
        c.drawText(txt, l, y - 9f * density, text)
    }

    // ---------- gestos ----------

    private var panId = -1
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L
    private var moved = false
    private var lastTapT = 0L
    private var lastTapX = 0f
    private var lastTapY = 0f
    private var pinching = false
    private var pinchD0 = 1f
    private var pinchZ0 = 1f
    private var anchorX = 0f
    private var anchorY = 0f

    private fun clampCenter() {
        cx = cx.coerceIn(x0, x0 + w0 * base)
        cy = cy.coerceIn(y0, y0 + h0 * base)
    }

    private fun zoomAt(sx: Float, sy: Float, factor: Float) {
        val wx = cx + (sx - viewW / 2f) / zoom
        val wy = cy + (sy - viewH / 2f) / zoom
        zoom = (zoom * factor).coerceIn(zMin, zMax)
        cx = wx - (sx - viewW / 2f) / zoom
        cy = wy - (sy - viewH / 2f) / zoom
        clampCenter()
    }

    /** Procesa un toque mientras el mapa está abierto. close() cierra el mapa. */
    fun onTouch(e: MotionEvent, close: () -> Unit): Boolean {
        val w = viewW; val h = viewH
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = e.x; val y = e.y
                if (closeRect(w).contains(x, y)) { close(); return true }
                if (ready) {
                    if (plusRect(w, h).contains(x, y)) { zoomAt(w / 2f, h / 2f, 1.6f); return true }
                    if (minusRect(w, h).contains(x, y)) { zoomAt(w / 2f, h / 2f, 1f / 1.6f); return true }
                    if (meRect(w, h).contains(x, y)) { initPending = true; return true }
                }
                panId = e.getPointerId(0)
                lastX = x; lastY = y; downX = x; downY = y
                downT = SystemClock.uptimeMillis(); moved = false; pinching = false
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount >= 2) {
                    pinching = true; moved = true
                    pinchD0 = max(1f, hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)))
                    pinchZ0 = zoom
                    val mx = (e.getX(0) + e.getX(1)) / 2f; val my = (e.getY(0) + e.getY(1)) / 2f
                    anchorX = cx + (mx - w / 2f) / zoom
                    anchorY = cy + (my - h / 2f) / zoom
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (pinching && e.pointerCount >= 2) {
                    val d = max(1f, hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)))
                    val mx = (e.getX(0) + e.getX(1)) / 2f; val my = (e.getY(0) + e.getY(1)) / 2f
                    zoom = (pinchZ0 * d / pinchD0).coerceIn(zMin, zMax)
                    cx = anchorX - (mx - w / 2f) / zoom
                    cy = anchorY - (my - h / 2f) / zoom
                    clampCenter()
                } else if (!pinching && panId != -1) {
                    val i = e.findPointerIndex(panId)
                    if (i >= 0) {
                        val x = e.getX(i); val y = e.getY(i)
                        cx -= (x - lastX) / zoom; cy -= (y - lastY) / zoom
                        lastX = x; lastY = y
                        if (hypot(x - downX, y - downY) > 12f * density) moved = true
                        clampCenter()
                    }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (pinching) {
                    pinching = false
                    val rem = if (e.actionIndex == 0) 1 else 0
                    if (rem < e.pointerCount) {
                        panId = e.getPointerId(rem); lastX = e.getX(rem); lastY = e.getY(rem)
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                val now = SystemClock.uptimeMillis()
                if (!moved && panId != -1 && now - downT < 300L) {
                    // doble toque: acerca hacia ese punto
                    if (now - lastTapT < 320L && hypot(downX - lastTapX, downY - lastTapY) < 48f * density) {
                        zoomAt(downX, downY, 2f); lastTapT = 0L
                    } else { lastTapT = now; lastTapX = downX; lastTapY = downY }
                }
                panId = -1; pinching = false
            }
            MotionEvent.ACTION_CANCEL -> { panId = -1; pinching = false }
        }
        return true
    }

    private companion object {
        val GROUND = Color.rgb(242, 242, 238)      // papel
        val DARK = Color.rgb(14, 14, 16)           // tinta
        val CREAM = Color.rgb(234, 233, 219)
        val RED = Color.rgb(229, 57, 53)
    }
}
