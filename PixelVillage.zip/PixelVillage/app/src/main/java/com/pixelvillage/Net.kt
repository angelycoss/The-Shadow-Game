package com.pixelvillage

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue

/** Otro jugador visto desde este teléfono. */
class Remote(val id: Int) {
    @Volatile var name = "Jugador"
    @Volatile var tx = 0f
    @Volatile var ty = 0f
    @Volatile var face = 1f
    @Volatile var moving = false
    @Volatile var mounted = false
    var x = 0f
    var y = 0f
    var phase = 0f
    var init = false
    val horse = Horse(-1L - id, 0f, 0f)
}

/**
 * Multijugador LAN: una persona crea la partida (anfitrión) y las demás se conectan a su IP.
 * Protocolo de texto (una línea por mensaje) sobre TCP:
 *   cliente -> anfitrión:  H nombre | P x y cara mov monta | E evento
 *   anfitrión -> clientes: I id | R id nombre x y cara mov monta | L id | E evento
 * El mundo es el mismo en todos los teléfonos (se genera igual); solo se envían
 * posiciones y los cambios del mundo (árboles talados, recursos sacados, fogatas, cultivos).
 */
class Net(private val applyEvent: (String) -> Unit, private val snapshot: () -> List<String>) {
    companion object { const val PORT = 47800 }

    @Volatile var mode = 0                 // 0 = apagado, 1 = anfitrión, 2 = cliente
    @Volatile var status = ""
    @Volatile var myName = "Jugador"
    val remotes = ConcurrentHashMap<Int, Remote>()

    private class Conn(val id: Int, val sock: Socket) {
        val q = LinkedBlockingQueue<String>()
        @Volatile var alive = true
        @Volatile var name = "Jugador"
    }

    private var server: ServerSocket? = null
    private val conns = ConcurrentHashMap<Int, Conn>()
    private var upstream: Conn? = null
    @Volatile private var myId = 0
    private var nextId = 1

    fun localIps(): List<String> {
        val out = ArrayList<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    val h = a.hostAddress ?: continue
                    if (a is java.net.Inet4Address && a.isSiteLocalAddress) out.add(h)
                }
            }
        } catch (e: Exception) { }
        return out
    }

    // ---------- anfitrión ----------
    fun startHost(): Boolean {
        stop()
        return try {
            val ss = ServerSocket(PORT)
            ss.reuseAddress = true
            server = ss
            mode = 1; myId = 0; status = "Anfitrión · puerto $PORT"
            Thread {
                while (!ss.isClosed) {
                    try { attach(Conn(nextId++, ss.accept())) } catch (e: Exception) { if (ss.isClosed) break }
                }
            }.also { it.isDaemon = true }.start()
            true
        } catch (e: Exception) {
            status = "No se pudo crear la partida: ${e.message}"; mode = 0; false
        }
    }

    private fun attach(c: Conn) {
        conns[c.id] = c
        writer(c)
        Thread {
            try {
                val rd = BufferedReader(InputStreamReader(c.sock.getInputStream()))
                while (c.alive) {
                    val line = rd.readLine() ?: break
                    hostHandle(c, line)
                }
            } catch (e: Exception) { }
            c.alive = false
            conns.remove(c.id); remotes.remove(c.id)
            try { c.sock.close() } catch (e: Exception) { }
            if (mode == 1) broadcast("L ${c.id}", -1)
        }.also { it.isDaemon = true }.start()
    }

    private fun hostHandle(c: Conn, line: String) {
        val p = line.split(' ')
        when (p[0]) {
            "H" -> {
                c.name = clean(p.getOrNull(1) ?: "Jugador")
                c.q.offer("I ${c.id}")
                for (s in snapshot()) c.q.offer("E $s")
                remotes.getOrPut(c.id) { Remote(c.id) }.name = c.name
            }
            "P" -> if (p.size >= 6) {
                val r = remotes.getOrPut(c.id) { Remote(c.id).also { it.name = c.name } }
                setPos(r, p[1], p[2], p[3], p[4], p[5])
                broadcast("R ${c.id} ${c.name} ${p[1]} ${p[2]} ${p[3]} ${p[4]} ${p[5]}", c.id)
            }
            "E" -> if (p.size >= 2) {
                val ev = line.substring(2)
                applyEvent(ev)
                broadcast("E $ev", c.id)
            }
        }
    }

    // ---------- cliente ----------
    fun join(ip: String) {
        stop()
        mode = 2; status = "Conectando a $ip…"
        Thread {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(ip.trim(), PORT), 6000)
                val c = Conn(0, s)
                upstream = c
                writer(c)
                c.q.offer("H $myName")
                status = "Conectado a $ip"
                val rd = BufferedReader(InputStreamReader(s.getInputStream()))
                while (c.alive) {
                    val line = rd.readLine() ?: break
                    clientHandle(line)
                }
            } catch (e: Exception) {
                if (mode == 2) status = "No se pudo conectar: ${e.message ?: e.javaClass.simpleName}"
            }
            if (mode == 2) { if (!status.startsWith("No se pudo")) status = "Desconectado"; mode = 0 }
            upstream?.alive = false
            remotes.clear()
        }.also { it.isDaemon = true }.start()
    }

    private fun clientHandle(line: String) {
        val p = line.split(' ')
        when (p[0]) {
            "I" -> myId = p.getOrNull(1)?.toIntOrNull() ?: 0
            "R" -> if (p.size >= 8) {
                val id = p[1].toIntOrNull() ?: return
                if (id == myId) return
                val r = remotes.getOrPut(id) { Remote(id) }
                r.name = p[2]
                setPos(r, p[3], p[4], p[5], p[6], p[7])
            }
            "L" -> p.getOrNull(1)?.toIntOrNull()?.let { remotes.remove(it) }
            "E" -> if (line.length > 2) applyEvent(line.substring(2))
        }
    }

    // ---------- común ----------
    private fun writer(c: Conn) {
        Thread {
            try {
                val out = c.sock.getOutputStream()
                while (c.alive) {
                    val s = c.q.take()
                    out.write((s + "\n").toByteArray())
                    out.flush()
                }
            } catch (e: Exception) { c.alive = false }
        }.also { it.isDaemon = true }.start()
    }

    private fun clean(s: String) = s.replace(Regex("\\s+"), "_").take(14).ifEmpty { "Jugador" }

    private fun setPos(r: Remote, x: String, y: String, f: String, m: String, mt: String) {
        r.tx = x.toFloatOrNull() ?: r.tx
        r.ty = y.toFloatOrNull() ?: r.ty
        r.face = if (f == "1") 1f else -1f
        r.moving = m == "1"
        r.mounted = mt == "1"
    }

    private fun broadcast(line: String, exceptId: Int) {
        for (c in conns.values) if (c.id != exceptId && c.alive) c.q.offer(line)
    }

    /** Mi posición (se manda unas 5 veces por segundo). */
    fun sendPos(x: Float, y: Float, face: Float, moving: Boolean, mounted: Boolean) {
        val f = if (face >= 0f) 1 else 0
        val m = if (moving) 1 else 0
        val mt = if (mounted) 1 else 0
        when (mode) {
            1 -> broadcast("R 0 ${clean(myName)} $x $y $f $m $mt", -1)
            2 -> upstream?.q?.offer("P $x $y $f $m $mt")
        }
    }

    /** Un cambio del mundo hecho por mí, para los demás. */
    fun event(ev: String) {
        when (mode) {
            1 -> broadcast("E $ev", -1)
            2 -> upstream?.q?.offer("E $ev")
        }
    }

    fun stop() {
        val m = mode
        mode = 0
        try { server?.close() } catch (e: Exception) { }
        server = null
        for (c in conns.values) { c.alive = false; try { c.sock.close() } catch (e: Exception) { } }
        conns.clear()
        upstream?.let { it.alive = false; try { it.sock.close() } catch (e: Exception) { } }
        upstream = null
        remotes.clear()
        if (m != 0) status = ""
    }

    fun connectedCount(): Int = if (mode == 1) conns.size else if (mode == 2) remotes.size + 1 else 0
}
