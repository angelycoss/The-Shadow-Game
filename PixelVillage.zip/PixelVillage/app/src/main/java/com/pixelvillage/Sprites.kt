package com.pixelvillage

import android.graphics.Matrix
import android.graphics.Path
import android.graphics.RectF

/** Sprites vectoriales mínimos (coordenadas locales, base del objeto en 0,0). */
object Sprites {
    val treeBig = Path().apply {
        moveTo(0f, -19f); lineTo(-3f, -12f); lineTo(3f, -12f); close()
        moveTo(0f, -15f); lineTo(-4f, -7f); lineTo(4f, -7f); close()
        moveTo(0f, -10f); lineTo(-5f, -2f); lineTo(5f, -2f); close()
        addRect(-1f, -3f, 1f, 0f, Path.Direction.CCW)
    }

    val treeSmall = Path().also {
        treeBig.transform(Matrix().apply { setScale(0.72f, 0.72f) }, it)
    }

    // La luz viene del noroeste: la sombra cae hacia el este.
    val treeShadow = Path().apply {
        moveTo(-3f, 0f); lineTo(3f, 0f); lineTo(17f, -5f); lineTo(13f, -8f); lineTo(-2f, -3f); close()
    }

    // arbusto: tres masas redondeadas + un brillo
    val bush = Path().apply {
        addOval(RectF(-7f, -6f, 0f, 0f), Path.Direction.CW)
        addOval(RectF(-3f, -9f, 5f, 0f), Path.Direction.CW)
        addOval(RectF(1f, -6f, 8f, 0f), Path.Direction.CW)
    }
    val bushHi = Path().apply {
        addOval(RectF(-3f, -8f, 2f, -4f), Path.Direction.CW)
    }
    val bushShadow = Path().apply {
        addOval(RectF(-2f, -3f, 13f, 1f), Path.Direction.CW)
    }

    // tocón de un árbol talado
    val stump = Path().apply {
        addRect(-2f, -2f, 2f, 0f, Path.Direction.CW)
    }
    val stumpTop = Path().apply {
        addRect(-2f, -3f, 2f, -2f, Path.Direction.CW)
    }

    // árbol de hoja ancha (los que no son pinos)
    val treeRound = Path().apply {
        addRect(-1f, -8f, 1f, 0f, Path.Direction.CW)
        addOval(RectF(-7f, -19f, 7f, -6f), Path.Direction.CW)
    }
    val treeRoundHi = Path().apply { addOval(RectF(-4f, -17f, 1f, -12f), Path.Direction.CW) }

    // junco: varios tallos finos con la punta densa
    val reed = Path().apply {
        for (i in -3..3) {
            val h = 7f + (i * i) % 4 * 2f
            addRect(i * 1.6f - 0.4f, -h, i * 1.6f + 0.4f, 0f, Path.Direction.CW)
            addRect(i * 1.6f - 0.9f, -h - 1.5f, i * 1.6f + 0.9f, -h + 1f, Path.Direction.CW)
        }
    }

    // marabú: arbusto bajo con espinas
    val marabu = Path().apply {
        addOval(RectF(-6f, -5f, 6f, 0f), Path.Direction.CW)
        for (i in -2..2) {
            moveTo(i * 3f - 1f, -4f); lineTo(i * 3f, -9f - (i * i) % 2 * 2f); lineTo(i * 3f + 1f, -4f); close()
        }
    }

    // frutos / flores (puntos claros sobre el arbusto)
    val dots = Path().apply {
        addRect(-4f, -5f, -2.5f, -3.5f, Path.Direction.CW)
        addRect(0f, -7f, 1.5f, -5.5f, Path.Direction.CW)
        addRect(3f, -4f, 4.5f, -2.5f, Path.Direction.CW)
        addRect(-1f, -3f, 0.5f, -1.5f, Path.Direction.CW)
    }

    // hojas anchas de tabaco
    val tobacco = Path().apply {
        addRect(-0.5f, -12f, 0.5f, 0f, Path.Direction.CW)
        addOval(RectF(-6f, -5f, 0f, -1f), Path.Direction.CW)
        addOval(RectF(0f, -8f, 6f, -4f), Path.Direction.CW)
        addOval(RectF(-5f, -11f, 0f, -7f), Path.Direction.CW)
        addOval(RectF(0f, -13f, 5f, -9f), Path.Direction.CW)
    }

    // guaraná: arbusto de tallos finos con hojas en abanico (parecido a la yuca)
    val guarana = Path().apply {
        addRect(-0.5f, -12f, 0.5f, 0f, Path.Direction.CW)
        addRect(-4f, -9f, -3f, 0f, Path.Direction.CW)
        addRect(3f, -10f, 4f, 0f, Path.Direction.CW)
        for (k in -2..2) addOval(RectF(k * 2.4f - 1.2f - 4f, -15f + (k * k) * 0.7f, k * 2.4f + 1.2f - 4f, -9f + (k * k) * 0.7f), Path.Direction.CW)
        for (k in -2..2) addOval(RectF(k * 2.4f - 1.2f + 4f, -16f + (k * k) * 0.7f, k * 2.4f + 1.2f + 4f, -10f + (k * k) * 0.7f), Path.Direction.CW)
        for (k in -2..2) addOval(RectF(k * 2.4f - 1.2f, -18f + (k * k) * 0.7f, k * 2.4f + 1.2f, -12f + (k * k) * 0.7f), Path.Direction.CW)
    }

    // planta pequeña con flor (semillas de huerta silvestres)
    val wildPlant = Path().apply {
        addRect(-0.5f, -6f, 0.5f, 0f, Path.Direction.CW)
        addOval(RectF(-4f, -3f, 0f, -1f), Path.Direction.CW)
        addOval(RectF(0f, -5f, 4f, -3f), Path.Direction.CW)
        addOval(RectF(-2f, -9f, 2f, -5f), Path.Direction.CW)
    }

    // cultivo sembrado: brote y planta crecida
    val sprout = Path().apply {
        addRect(-0.5f, -3f, 0.5f, 0f, Path.Direction.CW)
        addOval(RectF(-3f, -4f, 0f, -2f), Path.Direction.CW)
        addOval(RectF(0f, -5f, 3f, -3f), Path.Direction.CW)
    }
    val grown = Path().apply {
        addRect(-0.5f, -8f, 0.5f, 0f, Path.Direction.CW)
        addOval(RectF(-5f, -5f, 0f, -2f), Path.Direction.CW)
        addOval(RectF(0f, -7f, 5f, -4f), Path.Direction.CW)
        addOval(RectF(-3f, -11f, 3f, -7f), Path.Direction.CW)
    }

    // bulto con cosas (lo que se tira o suelta al morir)
    val sack = Path().apply {
        addOval(RectF(-5f, -7f, 5f, 0f), Path.Direction.CW)
        addRect(-2f, -10f, 2f, -6f, Path.Direction.CW)
    }

    // horno de fusión: base de piedra con chimenea
    val furnace = Path().apply {
        moveTo(-8f, 0f); lineTo(-6f, -9f); lineTo(6f, -9f); lineTo(8f, 0f); close()
        addRect(2f, -19f, 6f, -8f, Path.Direction.CW)
    }
    val furnaceMouth = Path().apply { addRect(-3f, -6f, 3f, -1f, Path.Direction.CW) }

    // yacimiento de mineral: pedruscos con vetas
    val ore = Path().apply {
        addOval(RectF(-7f, -5f, -1f, 0f), Path.Direction.CW)
        addOval(RectF(-3f, -8f, 4f, 0f), Path.Direction.CW)
        addOval(RectF(2f, -5f, 8f, 0f), Path.Direction.CW)
    }
    val oreFleck = Path().apply {
        addRect(-5f, -3f, -3.5f, -2f, Path.Direction.CW)
        addRect(0f, -6f, 1.5f, -4.5f, Path.Direction.CW)
        addRect(4f, -3f, 5.5f, -1.5f, Path.Direction.CW)
        addRect(-1f, -2f, 0.5f, -0.8f, Path.Direction.CW)
    }
}
