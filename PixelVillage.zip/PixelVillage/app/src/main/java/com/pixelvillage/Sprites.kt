package com.pixelvillage

import android.graphics.Matrix
import android.graphics.Path
import android.graphics.RectF

/** Sprites vectoriales mínimos (coordenadas locales, base del objeto en 0,0). */
object Sprites {
    val treeBig = Path().apply {
        moveTo(0f, -19f); lineTo(-3f, -12f); lineTo(3f, -12f); close()
        moveTo(0f, -15f); lineTo(-4f, -7f); lineTo(4f, -7f); close()
        moveTo(0f, -10f); lineTo(-5f, -2f); lineTo(5f, -2f); close()
        addRect(-1f, -3f, 1f, 0f, Path.Direction.CCW)
    }

    val treeSmall = Path().also {
        treeBig.transform(Matrix().apply { setScale(0.72f, 0.72f) }, it)
    }

    // La luz viene del noroeste: la sombra cae hacia el este.
    val treeShadow = Path().apply {
        moveTo(-3f, 0f); lineTo(3f, 0f); lineTo(17f, -5f); lineTo(13f, -8f); lineTo(-2f, -3f); close()
    }

    // arbusto: tres masas redondeadas + un brillo
    val bush = Path().apply {
        addOval(RectF(-7f, -6f, 0f, 0f), Path.Direction.CW)
        addOval(RectF(-3f, -9f, 5f, 0f), Path.Direction.CW)
        addOval(RectF(1f, -6f, 8f, 0f), Path.Direction.CW)
    }
    val bushHi = Path().apply {
        addOval(RectF(-3f, -8f, 2f, -4f), Path.Direction.CW)
    }
    val bushShadow = Path().apply {
        addOval(RectF(-2f, -3f, 13f, 1f), Path.Direction.CW)
    }

    // tocón de un árbol talado
    val stump = Path().apply {
        addRect(-2f, -2f, 2f, 0f, Path.Direction.CW)
    }
    val stumpTop = Path().apply {
        addRect(-2f, -3f, 2f, -2f, Path.Direction.CW)
    }
}
