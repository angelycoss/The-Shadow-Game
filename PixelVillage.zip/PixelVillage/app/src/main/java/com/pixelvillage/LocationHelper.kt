package com.pixelvillage

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/** Obtiene una ubicación una sola vez, sin Google Play Services. */
object LocationHelper {
    @SuppressLint("MissingPermission")
    fun once(ctx: Context, cb: (Location?) -> Unit) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        var best: Location? = null
        try {
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                val b = best
                if (b == null || l.accuracy < b.accuracy) best = l
            }
        } catch (e: Exception) { }
        val known = best
        if (known != null) { cb(known); return }

        val providers = lm.getProviders(true).filter { it != LocationManager.PASSIVE_PROVIDER }
        if (providers.isEmpty()) { cb(null); return }

        val handler = Handler(Looper.getMainLooper())
        val listeners = ArrayList<LocationListener>()
        var done = false

        fun finish(l: Location?) {
            if (done) return
            done = true
            handler.removeCallbacksAndMessages(null)
            for (x in listeners) try { lm.removeUpdates(x) } catch (e: Exception) { }
            cb(l)
        }

        for (p in providers) {
            val li = object : LocationListener {
                override fun onLocationChanged(location: Location) { finish(location) }
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            listeners.add(li)
            try { lm.requestLocationUpdates(p, 0L, 0f, li, Looper.getMainLooper()) } catch (e: Exception) { }
        }
        handler.postDelayed({ finish(null) }, 20000)
    }
}
