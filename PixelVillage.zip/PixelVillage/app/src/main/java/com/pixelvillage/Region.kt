package com.pixelvillage

import kotlin.math.cos

/**
 * Dónde está el mundo. El Parque Los Pinos (barrio Los Pinos, Antilla/Banes), 20°53′27.5″N 75°49′06″W,
 * es el origen (0, 0) del juego: x crece hacia el este, y hacia el sur (como en pantalla).
 *
 * OJO: estas constantes deben coincidir con tools/fetch_base_map.py y tools/base_region.json.
 */
object Region {
    const val LAT0 = 20.89098
    const val LON0 = -75.81833
    const val M_LAT = 110540.0                              // metros por grado de latitud
    val M_LON = 111320.0 * cos(Math.toRadians(LAT0))        // metros por grado de longitud

    fun px(lon: Double): Float = ((lon - LON0) * M_LON * PPM).toFloat()
    fun py(lat: Double): Float = (-(lat - LAT0) * M_LAT * PPM).toFloat()
    fun lon(px: Float): Double = LON0 + px / (PPM * M_LON)
    fun lat(py: Float): Double = LAT0 - py / (PPM * M_LAT)

    /** Pueblos donde se puede aparecer (nombre, longitud, latitud). */
    val TOWNS = listOf(
        Triple("Parque Los Pinos", -75.81833, 20.89098),
        Triple("Escuela Antonio Maceo", -75.81989, 20.89050),
        Triple("Campo de béisbol", -75.81638, 20.89117),
        Triple("Iglesia Bautista", -75.82015, 20.89167),
        Triple("Caimana", -75.83218, 20.89172),
        Triple("San Antonio", -75.82807, 20.87453)
    )
}
