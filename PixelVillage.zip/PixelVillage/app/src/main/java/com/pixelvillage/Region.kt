package com.pixelvillage

import kotlin.math.cos

/**
 * Dónde está el mundo. El punto de aparición del personaje, 20°53′32.5″N 75°49′10.14″W,
 * es el origen (0, 0) del juego: x crece hacia el este, y hacia el sur (como en pantalla).
 *
 * OJO: estas constantes deben coincidir con tools/fetch_base_map.py y tools/base_region.json.
 */
object Region {
    const val LAT0 = 20.892361111111
    const val LON0 = -75.819483333333
    const val M_LAT = 110540.0                              // metros por grado de latitud
    val M_LON = 111320.0 * cos(Math.toRadians(LAT0))        // metros por grado de longitud

    fun px(lon: Double): Float = ((lon - LON0) * M_LON * PPM).toFloat()
    fun py(lat: Double): Float = (-(lat - LAT0) * M_LAT * PPM).toFloat()
    fun lon(px: Float): Double = LON0 + px / (PPM * M_LON)
    fun lat(py: Float): Double = LAT0 - py / (PPM * M_LAT)
}
