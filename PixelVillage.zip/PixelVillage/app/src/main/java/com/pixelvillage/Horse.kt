package com.pixelvillage

/** Un caballo: silvestre hasta que se doma montándolo. Los domados se guardan en el teléfono. */
class Horse(val key: Long, var x: Float, var y: Float) {
    @Volatile var tame = false
    var energy = 100f          // baja corriendo (18 min seguidos); se recupera comiendo
    var water = 100f           // baja corriendo (30 min seguidos); se recupera bebiendo
    var saddle = false         // con montura de junco caben 2 jinetes
    var tied = false
    var tiedKey = 0L           // árbol al que está amarrado
    var homeX = x
    var homeY = y
    var dirX = 0f
    var dirY = 0f
    var wanderT = 0f
    var face = 1f
    var phase = 0f
    var moving = false
    val shade: Float = 0.20f + (key and 7L).toInt() * 0.035f

    fun encode() = "$key,$x,$y,$energy,$water,${if (saddle) 1 else 0},${if (tied) 1 else 0},$tiedKey"

    companion object {
        fun decode(s: String): Horse? {
            val f = s.split(',')
            if (f.size < 8) return null
            val key = f[0].toLongOrNull() ?: return null
            val x = f[1].toFloatOrNull() ?: return null
            val y = f[2].toFloatOrNull() ?: return null
            val h = Horse(key, x, y)
            h.tame = true
            h.energy = f[3].toFloatOrNull() ?: 100f
            h.water = f[4].toFloatOrNull() ?: 100f
            h.saddle = f[5] == "1"
            h.tied = f[6] == "1"
            h.tiedKey = f[7].toLongOrNull() ?: 0L
            return h
        }
    }
}
