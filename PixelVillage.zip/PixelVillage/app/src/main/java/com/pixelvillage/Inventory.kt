package com.pixelvillage

import android.content.SharedPreferences
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

object Items {
    const val STICK = 0
    const val STONE = 1
    const val LOG = 2
    const val LEAF = 3
    const val AXE = 4
    const val COUNT = 5
    val NAMES = arrayOf("Palo", "Piedra", "Tronco", "Hoja", "Hacha")

    /** Lo que se puede llevar en la mano. */
    fun equippable(id: Int) = id == STICK || id == AXE
}

class Recipe(
    val id: Int,
    val name: String,
    val needs: IntArray,     // cantidad que cuesta de cada objeto
    val gives: Int,          // objeto que da (-1 = ninguno)
    val qty: Int,
    val desc: String
) {
    companion object {
        const val AXE = 0
        const val LOGS = 1
        const val FIRE = 2
    }
}

/** Inventario, objeto en mano, recursos ya recogidos y fogatas. Se guarda en el teléfono. */
class Inventory(private val prefs: SharedPreferences) {
    val counts = IntArray(Items.COUNT)
    @Volatile var hand = -1                                   // objeto en la mano (-1 = nada)
    val taken = ConcurrentHashMap<Long, Int>()                // palos ya sacados de cada árbol
    val stoneTaken = ConcurrentHashMap<Long, Int>()           // piedras ya recogidas de cada montoncito
    val felled: MutableSet<Long> = ConcurrentHashMap.newKeySet<Long>()   // árboles talados
    @Volatile var fires: Array<FloatArray> = emptyArray()     // fogatas (x, y), ordenadas por y

    init { load() }

    private fun decode(s: String, into: MutableMap<Long, Int>) {
        for (part in s.split(';')) {
            val kv = part.split('=')
            if (kv.size == 2) {
                val k = kv[0].toLongOrNull()
                val v = kv[1].toIntOrNull()
                if (k != null && v != null) into[k] = v
            }
        }
    }

    private fun encode(m: Map<Long, Int>) = m.entries.joinToString(";") { "${it.key}=${it.value}" }

    private fun load() {
        for (i in 0 until Items.COUNT) counts[i] = prefs.getInt("inv_$i", 0)
        hand = prefs.getInt("inv_hand", -1)
        decode(prefs.getString("trees_taken", "") ?: "", taken)
        decode(prefs.getString("stones_taken", "") ?: "", stoneTaken)
        for (p in (prefs.getString("felled", "") ?: "").split(';')) p.toLongOrNull()?.let { felled.add(it) }
        val list = ArrayList<FloatArray>()
        for (p in (prefs.getString("fires", "") ?: "").split(';')) {
            val xy = p.split(',')
            if (xy.size == 2) {
                val a = xy[0].toFloatOrNull()
                val b = xy[1].toFloatOrNull()
                if (a != null && b != null) list.add(floatArrayOf(a, b))
            }
        }
        fires = list.sortedBy { it[1] }.toTypedArray()
    }

    fun save() {
        val e = prefs.edit()
        for (i in 0 until Items.COUNT) e.putInt("inv_$i", counts[i])
        e.putInt("inv_hand", hand)
        e.putString("trees_taken", encode(taken))
        e.putString("stones_taken", encode(stoneTaken))
        e.putString("felled", felled.joinToString(";"))
        e.putString("fires", fires.joinToString(";") { "${it[0]},${it[1]}" })
        e.apply()
    }

    /** Ids de los objetos que tienes (cantidad > 0), en orden. */
    fun slots(): List<Int> = (0 until Items.COUNT).filter { counts[it] > 0 }

    fun equip(id: Int) {
        if (!Items.equippable(id) || counts[id] <= 0 || hand == id) return
        if (hand != -1) counts[hand]++          // lo que había en la mano vuelve a la bolsa
        counts[id]--
        hand = id
        save()
    }

    fun unequip() {
        if (hand == -1) return
        counts[hand]++
        hand = -1
        save()
    }

    fun canCraft(r: Recipe): Boolean {
        for (i in 0 until Items.COUNT) if (counts[i] < r.needs[i]) return false
        return true
    }

    /** Gasta los materiales y entrega el resultado (la fogata la coloca el juego). */
    fun craft(r: Recipe) {
        for (i in 0 until Items.COUNT) counts[i] -= r.needs[i]
        if (r.gives >= 0) counts[r.gives] += r.qty
        save()
    }

    fun addFire(x: Float, y: Float) {
        fires = (fires.toList() + floatArrayOf(x, y)).sortedBy { it[1] }.toTypedArray()
        save()
    }

    companion object {
        private fun need(vararg p: Pair<Int, Int>): IntArray {
            val a = IntArray(Items.COUNT)
            for ((id, n) in p) a[id] = n
            return a
        }

        val RECIPES = listOf(
            Recipe(Recipe.AXE, "Hacha", need(Items.STONE to 1, Items.STICK to 1), Items.AXE, 1, "1 Piedra + 1 Palo"),
            Recipe(Recipe.LOGS, "Cortar tronco", need(Items.LOG to 1), Items.STICK, 2, "1 Tronco  ->  2 Palos"),
            Recipe(Recipe.FIRE, "Fogata", need(Items.STICK to 3, Items.STONE to 2), -1, 0, "3 Palos + 2 Piedras (chispa)")
        )

        fun keyOf(o: Obj): Long =
            (o.x.roundToInt().toLong() shl 32) xor (o.y.roundToInt().toLong() and 0xFFFFFFFFL)

        /** Cada árbol esconde 1 o 2 palos (siempre los mismos para ese árbol). */
        fun sticksIn(key: Long): Int = 1 + (((key * 2654435761L) ushr 9).toInt() and 1)

        /** Cada montoncito de piedras tiene 1 o 2 piedras. */
        fun stonesIn(key: Long): Int = 1 + (((key * 40503L) ushr 11).toInt() and 1)
    }
}
