package com.pixelvillage

import android.content.SharedPreferences
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.roundToInt

object Items {
    const val STICK = 0
    const val STONE = 1
    const val LOG = 2
    const val LEAF = 3
    const val AXE = 4
    const val REED = 5          // junco
    const val RICE = 6          // semillas de arroz
    const val MARABU = 7        // palo de marabú (con espinas)
    const val PINECONE = 8      // piña de pino
    const val PINELEAF = 9      // hojas (agujas) de pino
    const val KNIFE = 10        // cuchillo rústico
    const val SPEAR = 11        // lanza
    const val BOWL = 12         // cuenco vacío
    const val BOWL_DIRTY = 13   // cuenco con agua sin hervir
    const val BOWL_CLEAN = 14   // cuenco con agua hervida
    const val CHERRY = 15
    const val CHERRY_SEED = 16
    const val SEED0 = 17        // 17..23: semillas de tomate, lechuga, pepino, remolacha, patata, frijol, sandía
    const val VEG0 = 24         // 24..30: lo que dan al cosechar
    const val TOBACCO_SEED = 31
    const val TOBACCO_LEAF = 32
    const val ROPE = 33
    const val BASKET = 34
    const val PICK = 35         // pico
    const val IRON_ORE = 36
    const val COPPER_ORE = 37
    const val GOLD_ORE = 38
    const val IRON_INGOT = 39
    const val COPPER_INGOT = 40
    const val GOLD_INGOT = 41
    const val COIN = 42         // moneda de oro (9 por lingote)
    const val GRASS = 43        // hierba cortada
    const val HAY = 44          // paca de hierba
    const val SADDLE = 45       // montura de junco
    const val COUNT = 46

    val NAMES = arrayOf(
        "Palo", "Piedra", "Tronco", "Hoja", "Hacha",
        "Junco", "Semillas de arroz", "Palo de marabú", "Piña de pino", "Hojas de pino",
        "Cuchillo rústico", "Lanza", "Cuenco", "Cuenco (agua sucia)", "Cuenco (agua hervida)",
        "Cereza", "Semilla de cerezo",
        "Semilla de tomate", "Semilla de lechuga", "Semilla de pepino", "Semilla de remolacha",
        "Semilla de patata", "Semilla de frijol", "Semilla de sandía",
        "Tomate", "Lechuga", "Pepino", "Remolacha", "Patata", "Frijol", "Sandía",
        "Semilla de tabaco", "Hoja de tabaco", "Cuerda de junco", "Cesta de junco",
        "Pico", "Mineral de hierro", "Mineral de cobre", "Mineral de oro",
        "Lingote de hierro", "Lingote de cobre", "Lingote de oro", "Moneda de oro",
        "Hierba", "Paca de hierba", "Montura de junco"
    )

    /** Peso de cada objeto en kg. */
    val WEIGHT = floatArrayOf(
        0.4f, 1.5f, 6.0f, 0.05f, 2.0f,
        0.15f, 0.02f, 0.5f, 0.3f, 0.03f,
        0.4f, 1.2f, 0.5f, 1.0f, 1.0f,
        0.03f, 0.005f,
        0.005f, 0.005f, 0.005f, 0.005f, 0.005f, 0.005f, 0.005f,
        0.2f, 0.3f, 0.35f, 0.3f, 0.25f, 0.1f, 3.0f,
        0.005f, 0.05f, 0.3f, 1.0f,
        2.5f, 3.0f, 3.0f, 2.0f,
        2.0f, 2.0f, 1.5f, 0.01f,
        0.3f, 1.5f, 1.5f
    )

    // cultivos: 0..6 hortalizas, 7 cerezo, 8 tabaco
    val CROP_NAMES = arrayOf("Tomate", "Lechuga", "Pepino", "Remolacha", "Patata", "Frijol", "Sandía", "Cerezo", "Tabaco")
    val CROP_SEED = intArrayOf(17, 18, 19, 20, 21, 22, 23, CHERRY_SEED, TOBACCO_SEED)
    val CROP_SECS = intArrayOf(600, 360, 480, 480, 720, 540, 900, 1200, 720)   // tiempo de crecimiento (s)

    fun cropOfSeed(id: Int): Int = CROP_SEED.indexOf(id)
    fun isSeed(id: Int) = cropOfSeed(id) >= 0 && id != RICE

    /** Lo que se puede llevar en la mano. */
    fun equippable(id: Int) = id == STICK || id == AXE || id == MARABU || id == KNIFE || id == SPEAR || id == PICK

    /** Cuánta agua repone comerlo (0 = no se come). */
    fun hydro(id: Int): Float = when (id) {
        CHERRY -> 4f
        VEG0 -> 8f; VEG0 + 1 -> 6f; VEG0 + 2 -> 12f; VEG0 + 3 -> 5f; VEG0 + 4 -> 2f; VEG0 + 5 -> 1f; VEG0 + 6 -> 25f
        else -> 0f
    }

    fun usable(id: Int) = hydro(id) > 0f || id == BOWL_CLEAN || id == BOWL_DIRTY
}

class Recipe(
    val id: Int,
    val name: String,
    val needs: IntArray,     // cantidad que cuesta de cada objeto
    val tools: IntArray,     // herramientas que hay que tener (no se gastan)
    val gives: Int,          // objeto que da (-1 = ninguno)
    val qty: Int,
    val desc: String
) {
    companion object {
        const val AXE = 0
        const val LOGS = 1
        const val FIRE = 2
        const val KNIFE = 3
        const val SPEAR = 4
        const val ROPE = 5
        const val BASKET = 6
        const val BOWL = 7
        const val PICK = 8
        const val HAY = 9
        const val SADDLE = 10
        const val COINS = 11
    }
}

class Pile(val x: Float, val y: Float, val counts: IntArray)
class Planted(val x: Float, val y: Float, val type: Int, val t0: Long)

/** Inventario con peso, objeto en mano, recursos ya recogidos, fogatas, cultivos, bultos y agua del cuerpo. */
class Inventory(private val prefs: SharedPreferences) {
    val counts = IntArray(Items.COUNT)
    @Volatile var hand = -1                                   // objeto en la mano (-1 = nada)
    val taken = ConcurrentHashMap<Long, Int>()                // recursos ya sacados de cada árbol / planta
    val stoneTaken = ConcurrentHashMap<Long, Int>()           // piedras ya recogidas de cada montoncito
    val felled: MutableSet<Long> = ConcurrentHashMap.newKeySet<Long>()   // árboles talados
    @Volatile var fires: Array<FloatArray> = emptyArray()     // fogatas (x, y), ordenadas por y
    val planted = CopyOnWriteArrayList<Planted>()
    val piles = CopyOnWriteArrayList<Pile>()                  // lo que se tira o suelta al morir
    @Volatile var water = 100f                                // agua en el estómago/reserva (0..100)
    @Volatile var body = 100f                                 // agua del cuerpo: se gasta cuando la reserva llega a 0
    val fuel = ConcurrentHashMap<Long, Int>()                 // leña dentro de cada horno de fusión
    @Volatile var bowlWear = 0                                // veces que se ha hervido con el cuenco

    init { load() }

    // ---------- peso ----------
    fun weight(): Float {
        var w = 0f
        for (i in 0 until Items.COUNT) w += counts[i] * Items.WEIGHT[i]
        if (hand >= 0) w += Items.WEIGHT[hand]
        return w
    }

    fun capacity(): Float = BASE_CAPACITY + (if (counts[Items.BASKET] > 0) BASKET_BONUS else 0f)

    fun canAdd(id: Int, n: Int = 1): Boolean = weight() + Items.WEIGHT[id] * n <= capacity() + 0.001f

    /** Cuántas unidades más de este objeto caben. */
    fun fits(id: Int, want: Int): Int {
        var n = 0
        val free = capacity() - weight() + 0.001f
        val w = Items.WEIGHT[id]
        while (n < want && (n + 1) * w <= free) n++
        return n
    }

    /** Multiplicador de velocidad por la carga: sin penalización hasta el 70 %, hasta -35 % al límite. */
    fun loadSpeed(): Float {
        val r = weight() / capacity()
        return if (r <= 0.7f) 1f else (1f - (r - 0.7f) / 0.3f * 0.35f).coerceAtLeast(0.55f)
    }

    fun has(id: Int) = counts[id] > 0 || hand == id

    private fun decode(s: String, into: MutableMap<Long, Int>) {
        for (part in s.split(';')) {
            val kv = part.split('=')
            if (kv.size == 2) {
                val k = kv[0].toLongOrNull()
                val v = kv[1].toIntOrNull()
                if (k != null && v != null) into[k] = v
            }
        }
    }

    private fun encode(m: Map<Long, Int>) = m.entries.joinToString(";") { "${it.key}=${it.value}" }

    private fun load() {
        for (i in 0 until Items.COUNT) counts[i] = prefs.getInt("inv_$i", 0)
        hand = prefs.getInt("inv_hand", -1)
        water = prefs.getFloat("water", 100f)
        body = prefs.getFloat("body", 100f)
        bowlWear = prefs.getInt("bowl_wear", 0)
        decode(prefs.getString("trees_taken", "") ?: "", taken)
        decode(prefs.getString("stones_taken", "") ?: "", stoneTaken)
        decode(prefs.getString("fuel", "") ?: "", fuel)
        for (p in (prefs.getString("felled", "") ?: "").split(';')) p.toLongOrNull()?.let { felled.add(it) }
        val list = ArrayList<FloatArray>()
        for (p in (prefs.getString("fires", "") ?: "").split(';')) {
            val xy = p.split(',')
            if (xy.size == 2) {
                val a = xy[0].toFloatOrNull()
                val b = xy[1].toFloatOrNull()
                if (a != null && b != null) list.add(floatArrayOf(a, b))
            }
        }
        fires = list.sortedBy { it[1] }.toTypedArray()
        for (p in (prefs.getString("planted", "") ?: "").split(';')) {
            val f = p.split(',')
            if (f.size == 4) {
                val x = f[0].toFloatOrNull(); val y = f[1].toFloatOrNull()
                val t = f[2].toIntOrNull(); val t0 = f[3].toLongOrNull()
                if (x != null && y != null && t != null && t0 != null && t in 0..8) planted.add(Planted(x, y, t, t0))
            }
        }
        for (p in (prefs.getString("piles", "") ?: "").split(';')) {
            val f = p.split(',')
            if (f.size >= 3) {
                val x = f[0].toFloatOrNull(); val y = f[1].toFloatOrNull()
                if (x == null || y == null) continue
                val cn = IntArray(Items.COUNT)
                for (j in 2 until f.size) {
                    val kv = f[j].split(':')
                    val id = kv.getOrNull(0)?.toIntOrNull(); val n = kv.getOrNull(1)?.toIntOrNull()
                    if (id != null && n != null && id in 0 until Items.COUNT) cn[id] = n
                }
                piles.add(Pile(x, y, cn))
            }
        }
    }

    fun save() {
        val e = prefs.edit()
        for (i in 0 until Items.COUNT) e.putInt("inv_$i", counts[i])
        e.putInt("inv_hand", hand)
        e.putFloat("water", water)
        e.putFloat("body", body)
        e.putInt("bowl_wear", bowlWear)
        e.putString("trees_taken", encode(taken))
        e.putString("stones_taken", encode(stoneTaken))
        e.putString("fuel", encode(fuel))
        e.putString("felled", felled.joinToString(";"))
        e.putString("fires", fires.joinToString(";") { "${it[0]},${it[1]}" })
        e.putString("planted", planted.joinToString(";") { "${it.x},${it.y},${it.type},${it.t0}" })
        e.putString("piles", piles.joinToString(";") { p ->
            val items = (0 until Items.COUNT).filter { p.counts[it] > 0 }.joinToString(",") { "$it:${p.counts[it]}" }
            "${p.x},${p.y},$items"
        })
        e.apply()
    }

    /** Ids de los objetos que tienes (cantidad > 0), en orden. */
    fun slots(): List<Int> = (0 until Items.COUNT).filter { counts[it] > 0 }

    fun equip(id: Int) {
        if (!Items.equippable(id) || counts[id] <= 0 || hand == id) return
        if (hand != -1) counts[hand]++          // lo que había en la mano vuelve a la bolsa
        counts[id]--
        hand = id
        save()
    }

    fun unequip() {
        if (hand == -1) return
        counts[hand]++
        hand = -1
        save()
    }

    fun canCraft(r: Recipe): Boolean {
        for (i in 0 until Items.COUNT) if (counts[i] < r.needs[i]) return false
        for (t in r.tools) if (!has(t)) return false
        return true
    }

    /** Cuánto pesa de más (o de menos, si es negativo) la bolsa después de fabricar. */
    fun craftWeightDelta(r: Recipe): Float {
        var d = 0f
        for (i in 0 until Items.COUNT) d -= r.needs[i] * Items.WEIGHT[i]
        if (r.gives >= 0) d += r.qty * Items.WEIGHT[r.gives]
        return d
    }

    /** Gasta los materiales y entrega el resultado (la fogata la coloca el juego). */
    fun craft(r: Recipe) {
        for (i in 0 until Items.COUNT) counts[i] -= r.needs[i]
        if (r.gives >= 0) counts[r.gives] += r.qty
        save()
    }

    fun addFire(x: Float, y: Float) {
        fires = (fires.toList() + floatArrayOf(x, y)).sortedBy { it[1] }.toTypedArray()
        save()
    }

    // ---------- bultos en el suelo ----------
    /** Deja objetos en el suelo, juntándolos con un bulto cercano si lo hay. */
    fun drop(x: Float, y: Float, id: Int, n: Int) {
        var p = piles.firstOrNull { Math.abs(it.x - x) < 8f && Math.abs(it.y - y) < 8f }
        if (p == null) { p = Pile(x, y, IntArray(Items.COUNT)); piles.add(p) }
        p.counts[id] += n
        save()
    }

    /** Al morir: todo lo que llevas (y la mano) queda en el suelo. */
    fun dropAll(x: Float, y: Float) {
        val cn = IntArray(Items.COUNT)
        var any = false
        for (i in 0 until Items.COUNT) if (counts[i] > 0) { cn[i] = counts[i]; counts[i] = 0; any = true }
        if (hand >= 0) { cn[hand]++; hand = -1; any = true }
        if (any) piles.add(Pile(x, y, cn))
        water = 100f; body = 100f; bowlWear = 0
        save()
    }

    // ---------- cultivos ----------
    fun plant(x: Float, y: Float, type: Int) {
        planted.add(Planted(x, y, type, System.currentTimeMillis()))
        save()
    }

    companion object {
        const val BASE_CAPACITY = 25f      // kg que aguanta el personaje
        const val BASKET_BONUS = 12f       // kg extra con una cesta de junco

        private fun need(vararg p: Pair<Int, Int>): IntArray {
            val a = IntArray(Items.COUNT)
            for ((id, n) in p) a[id] = n
            return a
        }

        private fun tools(vararg t: Int) = t

        val RECIPES = listOf(
            Recipe(Recipe.KNIFE, "Cuchillo rústico", need(Items.STONE to 1, Items.STICK to 1), tools(), Items.KNIFE, 1, "1 Piedra + 1 Palo"),
            Recipe(Recipe.SPEAR, "Lanza", need(Items.STICK to 1), tools(Items.KNIFE), Items.SPEAR, 1, "1 Palo afilado (con cuchillo)"),
            Recipe(Recipe.AXE, "Hacha", need(Items.STONE to 1, Items.STICK to 1), tools(), Items.AXE, 1, "1 Piedra + 1 Palo"),
            Recipe(Recipe.LOGS, "Cortar tronco", need(Items.LOG to 1), tools(), Items.STICK, 2, "1 Tronco  ->  2 Palos"),
            Recipe(Recipe.ROPE, "Cuerda de junco", need(Items.REED to 3), tools(), Items.ROPE, 1, "3 Juncos"),
            Recipe(Recipe.BASKET, "Cesta de junco", need(Items.REED to 6, Items.ROPE to 1), tools(), Items.BASKET, 1, "6 Juncos + 1 Cuerda  (+12 kg)"),
            Recipe(Recipe.BOWL, "Cuenco", need(Items.LOG to 1), tools(Items.KNIFE), Items.BOWL, 1, "1 Tronco (con cuchillo)"),
            Recipe(Recipe.PICK, "Pico", need(Items.STICK to 2, Items.STONE to 2, Items.ROPE to 1), tools(), Items.PICK, 1, "2 Palos + 2 Piedras + 1 Cuerda"),
            Recipe(Recipe.HAY, "Paca de hierba", need(Items.GRASS to 4), tools(), Items.HAY, 1, "4 Hierba (córtala con cuchillo)"),
            Recipe(Recipe.SADDLE, "Montura de junco", need(Items.REED to 8, Items.ROPE to 2), tools(), Items.SADDLE, 1, "8 Juncos + 2 Cuerdas (2 jinetes)"),
            Recipe(Recipe.COINS, "Monedas de oro", need(Items.GOLD_INGOT to 1), tools(), Items.COIN, 9, "1 Lingote de oro  ->  9 monedas"),
            Recipe(Recipe.FIRE, "Fogata", need(Items.STICK to 3, Items.STONE to 2, Items.PINELEAF to 2), tools(), -1, 0, "3 Palos + 2 Piedras + 2 Hojas de pino")
        )

        fun keyOf(o: Obj): Long =
            (o.x.roundToInt().toLong() shl 32) xor (o.y.roundToInt().toLong() and 0xFFFFFFFFL)

        /** Clave de recolección: distingue plantas que caen en el mismo sitio que un árbol. */
        fun harvKey(o: Obj): Long = keyOf(o) xor (o.kind.toLong() shl 58)

        private fun h(key: Long, salt: Long): Int = (((key * 2654435761L + salt * 40503L) ushr 9).toInt()) and 0x7FFFFFFF

        /** Los pinos son 3 de cada 5 árboles (los demás son de hoja ancha). */
        fun isPine(o: Obj): Boolean = o.variant % 5 < 3

        /** Qué esconde cada árbol, en orden: 1-2 palos y, si es un pino, 1-3 piñas y 2-4 hojas de pino. */
        fun treeYield(o: Obj): IntArray {
            val k = keyOf(o)
            val list = ArrayList<Int>()
            repeat(1 + (h(k, 1) and 1)) { list.add(Items.STICK) }
            if (isPine(o)) {
                repeat(1 + h(k, 2) % 3) { list.add(Items.PINECONE) }
                repeat(2 + h(k, 3) % 3) { list.add(Items.PINELEAF) }
            }
            return list.toIntArray()
        }

        private val yieldCache = ConcurrentHashMap<Long, IntArray>()

        /** Igual que plantYield pero guardado (se consulta en cada cuadro al dibujar). */
        fun yieldOf(o: Obj): IntArray = yieldCache.getOrPut(harvKey(o)) { plantYield(o) }

        /** Qué da cada planta silvestre, en orden. */
        fun plantYield(o: Obj): IntArray {
            val k = harvKey(o)
            val list = ArrayList<Int>()
            when (o.kind) {
                KIND_REED -> {
                    repeat(3) { list.add(Items.REED) }
                    repeat(h(k, 4) % 3) { list.add(Items.RICE) }
                }
                KIND_MARABU -> repeat(2 + (h(k, 5) and 1)) { list.add(Items.MARABU) }
                KIND_CHERRY -> repeat(3) { list.add(Items.CHERRY) }
                KIND_SEEDS -> {
                    val seed = Items.SEED0 + h(k, 6) % 7
                    repeat(1 + (h(k, 7) and 1)) { list.add(seed) }
                }
                KIND_ORE -> {
                    val ore = (o as MineObj).ore
                    repeat(if (ore == Items.GOLD_ORE) 1 + (h(k, 8) and 1) else 3 + h(k, 8) % 3) { list.add(ore) }
                }
                KIND_TOBACCO -> { list.add(Items.TOBACCO_LEAF); list.add(Items.TOBACCO_SEED); list.add(Items.TOBACCO_SEED) }
            }
            return list.toIntArray()
        }

        /** Cada montoncito de piedras tiene 1 o 2 piedras. */
        fun stonesIn(key: Long): Int = 1 + (((key * 40503L) ushr 11).toInt() and 1)
    }
}
