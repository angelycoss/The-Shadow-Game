package com.pixelvillage

import android.content.Context
import org.json.JSONObject

/** Una mina a cielo abierto (de assets/mines.json, generado por tools/build_mines.py). */
class Mine(
    val id: Long, val type: Int, val name: String,
    val xs: FloatArray, val ys: FloatArray, val furn: FloatArray
) {
    val shape = Shape(xs, ys)
    /** Mineral que da cada yacimiento de esta mina. */
    val ore: Int = when (type) { 0 -> Items.IRON_ORE; 1 -> Items.COPPER_ORE; else -> Items.GOLD_ORE }
}

/** Yacimiento de mineral: lleva su tipo de mineral. */
class MineObj(x: Float, y: Float, val ore: Int, variant: Int) : Obj(x, y, null, variant, KIND_ORE)

object Mines {
    @Volatile var list: List<Mine> = emptyList()
        private set

    fun ensure(ctx: Context) {
        if (list.isNotEmpty()) return
        try {
            val txt = ctx.assets.open("mines.json").bufferedReader().use { it.readText() }
            val arr = JSONObject(txt).getJSONArray("mines")
            val out = ArrayList<Mine>()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                val pts = m.getJSONArray("pts")
                val n = pts.length() / 2
                val xs = FloatArray(n) { pts.getDouble(it * 2).toFloat() }
                val ys = FloatArray(n) { pts.getDouble(it * 2 + 1).toFloat() }
                val fa = m.getJSONArray("furn")
                val furn = FloatArray(fa.length()) { fa.getDouble(it).toFloat() }
                val type = when (m.getString("type")) { "iron" -> 0; "copper" -> 1; else -> 2 }
                out.add(Mine(m.getLong("id"), type, m.getString("name"), xs, ys, furn))
            }
            list = out
        } catch (e: Exception) {
            list = emptyList()
        }
    }
}
