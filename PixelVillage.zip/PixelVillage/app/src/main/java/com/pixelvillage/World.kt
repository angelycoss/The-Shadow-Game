package com.pixelvillage

import android.content.Context
import android.graphics.Path
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.*

const val PPM = 2.5f   // píxeles del juego por metro real
const val CELL = 2     // tamaño de celda de colisión (px)
const val SOLID = 1
const val ROAD = 2
const val INSIDE = 4   // interior caminable de un edificio
const val SWIM = 8     // agua por la que se puede caminar (hundido)
const val FENCE = 16   // cerca: no se traspasa, solo se salta
const val MUD = 32     // humedal / fango: te hundes hasta las rodillas y vas muy lento

// tipos de objeto del mundo (los que no son edificios)
const val KIND_TREE = 0
const val KIND_BUSH = 1
const val KIND_STONE = 2
const val KIND_FENCE = 3
const val KIND_TRASH = 4

/** Tipos de terreno, ordenados por prioridad de dibujo. */
object K {
    const val GRASS = 0
    const val FARM = 1
    const val URBAN = 2
    const val PARK = 3
    const val SAND = 4
    const val SCRUB = 5
    const val FOREST = 6
    const val DUMP = 7      // vertedero
    const val WET = 8       // humedal, pantano, fango
    const val WATER = 9     // lagos, lagunas y mar
    const val LAND = 10     // tierra firme dentro del mar (cayos): se dibuja sobre el agua
    // luminancia (0 = oscuro, 1 = claro) de cada terreno
    val LUM = floatArrayOf(0.70f, 0.76f, 0.50f, 0.74f, 0.88f, 0.52f, 0.38f, 0.46f, 0.47f, 0.14f, 0.70f)
}

/** Punto dentro de polígono (ray casting). */
fun pointInPoly(xs: FloatArray, ys: FloatArray, x: Float, y: Float): Boolean {
    var c = false
    var j = xs.size - 1
    for (i in xs.indices) {
        if ((ys[i] > y) != (ys[j] > y) &&
            x < (xs[j] - xs[i]) * (y - ys[i]) / (ys[j] - ys[i]) + xs[i]) c = !c
        j = i
    }
    return c
}

open class Shape(val xs: FloatArray, val ys: FloatArray) {
    val minX = xs.min()
    val maxX = xs.max()
    val minY = ys.min()
    val maxY = ys.max()
}

class Area(val kind: Int, xs: FloatArray, ys: FloatArray) : Shape(xs, ys) {
    var id = 0L              // id del way en OpenStreetMap (para no repetirlo entre teselas)
    var clipped = false      // pedazo recortado en el borde de una tesela (no se dibuja su contorno)
    var crop = false         // campo de cultivo (landuse=farmland): lleva trigo decorativo
    val path = Path().apply {
        moveTo(xs[0], ys[0])
        for (i in 1 until xs.size) lineTo(xs[i], ys[i])
        close()
    }
}

/** Vía de tren (activa o abandonada): dos rieles y traviesas. */
class Rail(xs: FloatArray, ys: FloatArray) : Shape(xs, ys) {
    var id = 0L
    val path = Path()       // eje (las traviesas)
    val left = Path()       // riel izquierdo
    val right = Path()      // riel derecho

    init {
        val n = xs.size
        path.moveTo(xs[0], ys[0])
        for (i in 1 until n) path.lineTo(xs[i], ys[i])
        val ox = FloatArray(n); val oy = FloatArray(n)
        for (i in 0 until n) {
            val a = max(0, i - 1); val b = min(n - 1, i + 1)
            var dx = xs[b] - xs[a]; var dy = ys[b] - ys[a]
            val l = hypot(dx, dy)
            if (l < 0.0001f) { dx = 1f; dy = 0f } else { dx /= l; dy /= l }
            ox[i] = -dy * 1.9f; oy[i] = dx * 1.9f
        }
        left.moveTo(xs[0] + ox[0], ys[0] + oy[0]); right.moveTo(xs[0] - ox[0], ys[0] - oy[0])
        for (i in 1 until n) {
            left.lineTo(xs[i] + ox[i], ys[i] + oy[i]); right.lineTo(xs[i] - ox[i], ys[i] - oy[i])
        }
    }
}

class Road(val width: Float, xs: FloatArray, ys: FloatArray) : Shape(xs, ys) {
    var id = 0L
    val path = Path().apply {
        moveTo(xs[0], ys[0])
        for (i in 1 until xs.size) lineTo(xs[i], ys[i])
    }
}

/** Edificio extruido en proyección oblicua: paredes, tejado nevado, ventanas, sombra, puerta e interior. */
class Building(xs: FloatArray, ys: FloatArray, val h: Float) : Shape(xs, ys) {
    var id = 0L
    var church = false      // iglesia (OpenStreetMap): lleva torre con cruz
    val roof = Path()       // huella del edificio (también sirve de suelo)
    val wallA = Path()      // paredes orientadas al este (en sombra)
    val wallB = Path()      // paredes orientadas al oeste (iluminadas)
    val windows = Path()
    val shadow = Path()
    val wallBack = Path()   // cara interior de las paredes del fondo (vista de interior)
    val wallFront = Path()  // pared baja delantera con hueco de puerta (vista de interior)
    val door = Path()       // puerta dibujada en la pared exterior

    var enterable = false
    var doorAx = 0f; var doorAy = 0f; var doorBx = 0f; var doorBy = 0f
    var doorMx = 0f; var doorMy = 0f
    var doorNx = 0f; var doorNy = 0f

    private fun quad(p: Path, x1: Float, y1: Float, x2: Float, y2: Float, hh: Float) {
        p.moveTo(x1, y1); p.lineTo(x2, y2); p.lineTo(x2, y2 - hh); p.lineTo(x1, y1 - hh); p.close()
    }

    init {
        val n = xs.size
        roof.moveTo(xs[0], ys[0])
        for (i in 1 until n) roof.lineTo(xs[i], ys[i])
        roof.close()

        var area = 0f
        var j = n - 1
        for (i in 0 until n) { area += xs[j] * ys[i] - xs[i] * ys[j]; j = i }
        val cw = area > 0f
        val backH = min(h, 24f)

        var bestLen = 0f
        var bestI = -1
        for (i in 0 until n) {
            val k = (i + 1) % n
            val x1 = xs[i]; val y1 = ys[i]; val x2 = xs[k]; val y2 = ys[k]
            val dx = x2 - x1; val dy = y2 - y1
            val nx: Float; val ny: Float
            if (cw) { nx = dy; ny = -dx } else { nx = -dy; ny = dx }
            val len = hypot(dx, dy)
            if (ny > 0.001f) {                               // pared que mira a la cámara
                quad(if (nx > 0f) wallA else wallB, x1, y1, x2, y2, h)
                if (h >= 9f && len >= 9f) {
                    val cnt = (len / 9f).toInt()
                    for (m in 0 until cnt) {
                        val t = (m + 0.5f) / cnt
                        val wx = x1 + dx * t
                        val wy = y1 + dy * t - h * 0.5f
                        windows.addRect(wx - 1f, wy - 1.5f, wx + 1f, wy + 1.5f, Path.Direction.CW)
                    }
                }
                if (len > bestLen) { bestLen = len; bestI = i }
            } else if (ny < -0.001f) {                       // pared del fondo (solo se ve por dentro)
                quad(wallBack, x1, y1, x2, y2, backH)
            }
        }

        // Solo se puede entrar a edificios de tamaño razonable con una pared sur larga.
        enterable = bestI >= 0 && bestLen >= 12f && (maxX - minX) >= 14f &&
            (maxY - minY) >= 12f && abs(area) / 2f >= 200f

        val lowH = 6f
        for (i in 0 until n) {
            val k = (i + 1) % n
            val x1 = xs[i]; val y1 = ys[i]; val x2 = xs[k]; val y2 = ys[k]
            val dx = x2 - x1; val dy = y2 - y1
            val nx: Float; val ny: Float
            if (cw) { nx = dy; ny = -dx } else { nx = -dy; ny = dx }
            if (ny <= 0.001f) continue
            val len = hypot(dx, dy)
            if (enterable && i == bestI) {
                val dw = min(9f, len * 0.5f)
                val t0 = 0.5f - dw / (2f * len)
                val t1 = 0.5f + dw / (2f * len)
                doorAx = x1 + dx * t0; doorAy = y1 + dy * t0
                doorBx = x1 + dx * t1; doorBy = y1 + dy * t1
                doorMx = x1 + dx * 0.5f; doorMy = y1 + dy * 0.5f
                doorNx = nx / len; doorNy = ny / len
                quad(wallFront, x1, y1, doorAx, doorAy, lowH)
                quad(wallFront, doorBx, doorBy, x2, y2, lowH)
                quad(door, doorAx, doorAy, doorBx, doorBy, min(h - 3f, 9f))
            } else {
                quad(wallFront, x1, y1, x2, y2, lowH)
            }
        }

        shadow.set(roof)
        for (t in floatArrayOf(0.4f, 0.7f, 1f)) {
            val p = Path(roof)
            p.offset(h * 0.9f * t, -h * 0.18f * t)
            shadow.op(p, Path.Op.UNION)
        }
    }
}

/** Objeto ordenable por profundidad: edificio (b != null) o árbol. */
open class Obj(val x: Float, val y: Float, val b: Building?, val variant: Int, val kind: Int = KIND_TREE)

/** Trocito de cerca, seto o muro (≈ 12 px). style: 0 cerca de postes, 1 seto, 2 muro. Mide la mitad del personaje. */
class FencePiece(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val style: Int) :
    Obj((x1 + x2) / 2f, (y1 + y2) / 2f, null, 0, KIND_FENCE)

// ---------------------------------------------------------------------------------------------
//  Mundo por teselas: el mapa se divide en cuadros de TILE_PX px (≈ 819 m). El origen (0,0) del
//  mundo es el punto de aparición y está en el centro de la tesela (0,0).
// ---------------------------------------------------------------------------------------------

const val CHUNK = 64                       // celdas por lado de un trozo de la rejilla
const val CHUNK_PX = CHUNK * CELL          // 128 px
const val TILE_CH = 16                     // trozos por lado de una tesela
const val TILE_PX = TILE_CH * CHUNK_PX     // 2048 px  (≈ 819 m)

/** Índice de la tesela que contiene la coordenada v (en px). */
fun tileOf(v: Float): Int = floor((v + TILE_PX / 2f) / TILE_PX).toInt()

/** Borde mínimo (px) de la tesela t. */
fun tileMin(t: Int): Float = t * TILE_PX.toFloat() - TILE_PX / 2f

fun tkey(tx: Int, ty: Int): Long = (tx.toLong() shl 32) or (ty.toLong() and 0xFFFFFFFFL)

/** Rango de celdas (inclusive) donde una tesela puede escribir en la rejilla. */
class Clip(val gx0: Int, val gy0: Int, val gx1: Int, val gy1: Int)

/** Rejilla de colisión / ocupación por trozos: solo gasta memoria donde hay algo. */
class Grid {
    private val chunks = ConcurrentHashMap<Long, ByteArray>()

    private fun gi(v: Float) = floor((v + TILE_PX / 2f) / CELL).toInt()
    private fun ckey(cx: Int, cy: Int) = (cx.toLong() shl 32) or (cy.toLong() and 0xFFFFFFFFL)

    fun clipOf(tx: Int, ty: Int): Clip {
        val n = TILE_PX / CELL
        return Clip(tx * n, ty * n, tx * n + n - 1, ty * n + n - 1)
    }

    /** Marcas de la celda que contiene (x, y). Lo que no se ha escrito está libre (0). */
    fun flags(x: Float, y: Float): Int {
        val gx = gi(x); val gy = gi(y)
        val ch = chunks[ckey(gx shr 6, gy shr 6)] ?: return 0
        return ch[((gy and 63) shl 6) or (gx and 63)].toInt()
    }

    /** Marca (o borra) las celdas gx in a..b de la fila gy, reutilizando el trozo de memoria. */
    private fun run(gy: Int, a: Int, b: Int, flag: Int, c: Clip, erase: Boolean) {
        var gx = a
        while (gx <= b) {
            val cxk = gx shr 6
            val end = min(b, (cxk shl 6) + 63)
            val k = ckey(cxk, gy shr 6)
            val ch: ByteArray? =
                if (erase) chunks[k] else (chunks[k] ?: ByteArray(CHUNK * CHUNK).let { f -> chunks.putIfAbsent(k, f) ?: f })
            if (ch != null) {
                val base = (gy and 63) shl 6
                for (x in gx..end) {
                    val i = base or (x and 63)
                    ch[i] = if (erase) (ch[i].toInt() and flag.inv()).toByte() else (ch[i].toInt() or flag).toByte()
                }
            }
            gx = end + 1
        }
    }

    private fun set(gx: Int, gy: Int, flag: Int, c: Clip) {
        if (gx < c.gx0 || gx > c.gx1 || gy < c.gy0 || gy > c.gy1) return
        val k = ckey(gx shr 6, gy shr 6)
        val ch = chunks[k] ?: ByteArray(CHUNK * CHUNK).let { fresh -> chunks.putIfAbsent(k, fresh) ?: fresh }
        val i = ((gy and 63) shl 6) or (gx and 63)
        ch[i] = (ch[i].toInt() or flag).toByte()
    }

    private fun clear(gx: Int, gy: Int, flag: Int, c: Clip) {
        if (gx < c.gx0 || gx > c.gx1 || gy < c.gy0 || gy > c.gy1) return
        val ch = chunks[ckey(gx shr 6, gy shr 6)] ?: return
        val i = ((gy and 63) shl 6) or (gx and 63)
        ch[i] = (ch[i].toInt() and flag.inv()).toByte()
    }

    /** Borra todo lo de una tesela (cuando se descarga de memoria). */
    fun dropTile(tx: Int, ty: Int) {
        for (cy in ty * TILE_CH until (ty + 1) * TILE_CH) {
            for (cx in tx * TILE_CH until (tx + 1) * TILE_CH) chunks.remove(ckey(cx, cy))
        }
    }

    /** Relleno de polígono por scanline (solo dentro del recorte c). */
    fun fillPoly(xs: FloatArray, ys: FloatArray, flag: Int, c: Clip, erase: Boolean = false) {
        val n = xs.size
        if (n < 3) return
        val gy0 = max(c.gy0, gi(ys.min())); val gy1 = min(c.gy1, gi(ys.max()))
        if (gy0 > gy1) return
        val tmp = FloatArray(n)
        for (gy in gy0..gy1) {
            val y = (gy + 0.5f) * CELL - TILE_PX / 2f
            var cnt = 0
            var j = n - 1
            for (i in 0 until n) {
                if ((ys[i] > y) != (ys[j] > y)) {
                    tmp[cnt++] = xs[i] + (y - ys[i]) * (xs[j] - xs[i]) / (ys[j] - ys[i])
                }
                j = i
            }
            java.util.Arrays.sort(tmp, 0, cnt)
            var k = 0
            while (k + 1 < cnt) {
                val a = max(c.gx0, gi(tmp[k])); val b = min(c.gx1, gi(tmp[k + 1]))
                if (a <= b) run(gy, a, b, flag, c, erase)
                k += 2
            }
        }
    }

    /** Quita una marca a lo largo de un segmento (para abrir el hueco de una puerta). */
    fun clearSegment(x1: Float, y1: Float, x2: Float, y2: Float, flag: Int, c: Clip) {
        val steps = max(1, (hypot(x2 - x1, y2 - y1) * 2f).toInt())
        for (s in 0..steps) {
            val t = s.toFloat() / steps
            val cx = gi(x1 + (x2 - x1) * t); val cy = gi(y1 + (y2 - y1) * t)
            for (oy in -1..1) for (ox in -1..1) clear(cx + ox, cy + oy, flag, c)
        }
    }

    fun markLine(xs: FloatArray, ys: FloatArray, width: Float, flag: Int, c: Clip) {
        val rc = ceil(width / 2f / CELL).toInt()
        for (i in 0 until xs.size - 1) {
            val dx = xs[i + 1] - xs[i]; val dy = ys[i + 1] - ys[i]
            val steps = max(1, (hypot(dx, dy) / CELL).toInt())
            for (s in 0..steps) {
                val t = s.toFloat() / steps
                val cx = gi(xs[i] + dx * t); val cy = gi(ys[i] + dy * t)
                if (cx + rc < c.gx0 || cx - rc > c.gx1 || cy + rc < c.gy0 || cy - rc > c.gy1) continue
                for (oy in -rc..rc) for (ox in -rc..rc) {
                    if (ox * ox + oy * oy <= rc * rc) set(cx + ox, cy + oy, flag, c)
                }
            }
        }
    }
}

/** Todo lo que se dibuja, ya unido (sin repetidos) a partir de las teselas cargadas. */
class Snapshot(
    val areas: List<Area>,
    val roads: List<Road>,
    val waterLines: List<Road>,
    val rails: List<Rail>,
    val objs: Array<Obj>,
    val enterables: List<Building>
) {
    /** Primer índice de objs cuya base (y) sea >= y. */
    fun firstIndexAtY(y: Float): Int {
        var lo = 0; var hi = objs.size
        while (lo < hi) {
            val m = (lo + hi) ushr 1
            if (objs[m].y < y) lo = m + 1 else hi = m
        }
        return lo
    }
}

/** Una tesela ya construida: formas del mapa + objetos que caen dentro de ella. */
class TileData(
    val tx: Int,
    val ty: Int,
    val areas: List<Area>,
    val roads: List<Road>,
    val waterLines: List<Road>,
    val rails: List<Rail>,
    val buildings: List<Building>,
    val buildingObjs: List<Obj>,
    val objs: List<Obj>            // árboles, arbustos y piedras (solo los que están dentro de la tesela)
)

class World(private val ctx: Context) {
    private companion object {
        const val RETRY_MS = 15_000L     // espera antes de reintentar una descarga fallida
        const val LOAD_R = 1             // se cargan las teselas a esta distancia del jugador (3x3)
        const val KEEP_R = 2             // las que quedan más lejos se descargan de memoria
    }

    @Volatile var snap = Snapshot(emptyList(), emptyList(), emptyList(), emptyList(), emptyArray(), emptyList())
        private set
    @Volatile var status: String? = null
        private set
    @Volatile var startX = 0f
        private set
    @Volatile var startY = 0f
        private set

    private val grid = Grid()
    private val lock = Any()
    private val loaded = ConcurrentHashMap<Long, TileData>()
    private val pending: MutableSet<Long> = ConcurrentHashMap.newKeySet<Long>()
    private val failed = ConcurrentHashMap<Long, Long>()
    private val netBusy = AtomicInteger(0)

    private fun daemon(name: String) = ThreadFactory { r -> Thread(r, name).also { it.isDaemon = true } }
    private val loader = Executors.newSingleThreadExecutor(daemon("tiles"))
    private val net = Executors.newSingleThreadExecutor(daemon("net"))

    // foco: tesela donde está el jugador (solo lo toca el hilo del juego)
    private var fx = Int.MIN_VALUE
    private var fy = 0
    private var fT = 0L

    fun close() {
        loader.shutdownNow()
        net.shutdownNow()
    }

    // ---------- arranque ----------

    /** Carga la tesela de aparición (del mapa incluido en el juego) y busca el sitio de salida. */
    fun loadStart() {
        status = "Cargando el mapa…"
        val json = Osm.readLocal(ctx, 0, 0) ?: Osm.download(ctx, 0, 0) { status = it }
        installTile(0, 0, json)

        var sx = 0f; var sy = 0f
        if ((grid.flags(0f, 0f) and SOLID) != 0) {
            search@ for (r in 1..200) {
                for (dx in -r..r) for (dy in -r..r) {
                    if (abs(dx) != r && abs(dy) != r) continue
                    val x = (dx * CELL).toFloat(); val y = (dy * CELL).toFloat()
                    if ((grid.flags(x, y) and SOLID) == 0) { sx = x; sy = y; break@search }
                }
            }
        }
        startX = sx; startY = sy
        status = null
        focus(sx, sy)
    }

    // ---------- carga progresiva ----------

    /** El juego avisa de dónde está el jugador: se piden las teselas vecinas y se sueltan las lejanas. */
    fun focus(x: Float, y: Float) {
        val tx = tileOf(x); val ty = tileOf(y)
        val now = System.currentTimeMillis()
        if (tx == fx && ty == fy && now - fT < 1000L) return
        fx = tx; fy = ty; fT = now
        try { loader.execute { reconcile(tx, ty) } } catch (e: RejectedExecutionException) { }
    }

    /** null si el punto está en una tesela cargada; si no, un aviso para el jugador. */
    fun edgeNote(x: Float, y: Float): String? {
        val k = tkey(tileOf(x), tileOf(y))
        if (loaded.containsKey(k)) return null
        return when {
            failed.containsKey(k) -> "Sin conexión: no se pudo descargar esta zona"
            pending.contains(k) -> "Descargando esta zona…"
            else -> "Cargando esta zona…"
        }
    }

    private fun reconcile(cx: Int, cy: Int) {
        val now = System.currentTimeMillis()
        for (dy in -LOAD_R..LOAD_R) for (dx in -LOAD_R..LOAD_R) {
            val tx = cx + dx; val ty = cy + dy
            val k = tkey(tx, ty)
            if (loaded.containsKey(k) || pending.contains(k)) continue
            val f = failed[k]
            if (f != null && now - f < RETRY_MS) continue
            request(tx, ty)
        }
        // los fallos de zonas lejanas ya no importan
        for (k in failed.keys.toList()) {
            val tx = (k shr 32).toInt(); val ty = k.toInt()
            if (abs(tx - cx) > LOAD_R || abs(ty - cy) > LOAD_R) failed.remove(k)
        }
        var dropped = false
        for (t in loaded.values.toList()) {
            if (abs(t.tx - cx) > KEEP_R || abs(t.ty - cy) > KEEP_R) {
                synchronized(lock) {
                    loaded.remove(tkey(t.tx, t.ty))
                    grid.dropTile(t.tx, t.ty)
                }
                dropped = true
            }
        }
        if (dropped) synchronized(lock) { rebuild() }
        refreshStatus()
    }

    /** Pide una tesela: primero lo guardado (mapa incluido o ya descargado); si no, la descarga. */
    private fun request(tx: Int, ty: Int) {
        val k = tkey(tx, ty)
        pending.add(k)
        val local = try { Osm.readLocal(ctx, tx, ty) } catch (e: Exception) { null }
        if (local != null) { finish(tx, ty, local); return }
        netBusy.incrementAndGet()
        refreshStatus()
        try {
            net.execute {
                val json = try { Osm.download(ctx, tx, ty) {} } catch (e: Exception) { null }
                netBusy.decrementAndGet()
                try {
                    loader.execute { if (json != null) finish(tx, ty, json) else fail(tx, ty) }
                } catch (e: RejectedExecutionException) { }
            }
        } catch (e: RejectedExecutionException) {
            netBusy.decrementAndGet()
        }
    }

    private fun finish(tx: Int, ty: Int, json: String) {
        val k = tkey(tx, ty)
        try {
            installTile(tx, ty, json)
            failed.remove(k)
        } catch (e: Throwable) {
            Osm.dropCache(ctx, tx, ty)            // si el archivo guardado estaba roto, se vuelve a bajar
            failed[k] = System.currentTimeMillis()
        } finally {
            pending.remove(k)
            refreshStatus()
        }
    }

    private fun fail(tx: Int, ty: Int) {
        val k = tkey(tx, ty)
        failed[k] = System.currentTimeMillis()
        pending.remove(k)
        refreshStatus()
    }

    private fun refreshStatus() {
        status = when {
            netBusy.get() > 0 -> "Descargando mapa…"
            failed.isNotEmpty() -> "Sin conexión: no se pudo descargar el mapa"
            else -> null
        }
    }

    private fun installTile(tx: Int, ty: Int, json: String) {
        val data = WorldBuilder.buildTile(json, tx, ty, grid)
        synchronized(lock) {
            loaded[tkey(tx, ty)] = data
            rebuild()
        }
    }

    /** Une las teselas cargadas en un solo conjunto, sin repetir lo que cruza el borde entre dos. */
    private fun rebuild() {
        val seen = HashSet<Long>()
        val areas = ArrayList<Area>()
        val roads = ArrayList<Road>()
        val waters = ArrayList<Road>()
        val rails = ArrayList<Rail>()
        val objs = ArrayList<Obj>()
        val ent = ArrayList<Building>()
        for (t in loaded.values.sortedBy { tkey(it.tx, it.ty) }) {
            for (a in t.areas) if (a.id == 0L || seen.add(a.id)) areas.add(a)
            for (r in t.roads) if (r.id == 0L || seen.add(r.id)) roads.add(r)
            for (r in t.waterLines) if (r.id == 0L || seen.add(r.id)) waters.add(r)
            for (r in t.rails) if (r.id == 0L || seen.add(r.id)) rails.add(r)
            for (o in t.buildingObjs) {
                val b = o.b ?: continue
                if (b.id == 0L || seen.add(b.id)) {
                    objs.add(o)
                    if (b.enterable) ent.add(b)
                }
            }
            objs.addAll(t.objs)
        }
        areas.sortBy { it.kind }          // los de arriba se dibujan encima
        roads.sortBy { it.width }         // las anchas se dibujan encima
        objs.sortBy { it.y }
        snap = Snapshot(areas, roads, waters, rails, objs.toTypedArray(), ent)
    }

    // ---------- consultas del juego ----------

    fun blocked(x: Float, y: Float): Boolean {
        if (!loaded.containsKey(tkey(tileOf(x), tileOf(y)))) return true     // zona aún sin descargar
        return (grid.flags(x, y) and SOLID) != 0
    }

    /** Como blocked, pero las cercas se saltan (jumping) o se dejan si ya estás encima de una. */
    fun blockedMove(fx: Float, fy: Float, tx: Float, ty: Float, jumping: Boolean): Boolean {
        if (!loaded.containsKey(tkey(tileOf(tx), tileOf(ty)))) return true
        val f = grid.flags(tx, ty)
        if ((f and SOLID) != 0) return true
        if ((f and FENCE) != 0 && !jumping && !onFence(fx, fy)) return true
        return false
    }

    fun onFence(x: Float, y: Float) = (grid.flags(x, y) and FENCE) != 0

    /** ¿Hay una cerca a menos de r px? (para mostrar el botón Saltar) */
    fun nearFence(x: Float, y: Float, r: Float): Boolean {
        var a = -r
        while (a <= r) {
            var b = -r
            while (b <= r) { if (onFence(x + a, y + b)) return true; b += 2f }
            a += 2f
        }
        return false
    }

    /** Humedal o fango (sin camino, edificio ni agua profunda): hundes las piernas. */
    fun inMud(x: Float, y: Float): Boolean {
        val f = grid.flags(x, y)
        return (f and MUD) != 0 && (f and (ROAD or INSIDE or SWIM)) == 0
    }

    /** Multiplicador de velocidad según el terreno: camino 1.0, campo 0.8, agua 0.5, fango 0.2. */
    fun speedFactorAt(x: Float, y: Float): Float {
        val f = grid.flags(x, y)
        return when {
            (f and INSIDE) != 0 -> 1f
            (f and ROAD) != 0 -> 1f
            (f and SWIM) != 0 -> 0.5f
            (f and MUD) != 0 -> 0.2f
            else -> 0.8f
        }
    }

    fun inWater(x: Float, y: Float): Boolean {
        val f = grid.flags(x, y)
        return (f and SWIM) != 0 && (f and (ROAD or INSIDE)) == 0
    }

    /** Suelo libre (sin camino, edificio, agua ni interior): ahí crece la hierba. */
    fun groundFree(x: Float, y: Float) = grid.flags(x, y) == 0

    /** Objeto (no edificio) más cercano dentro del radio r que cumpla accept, o null. */
    fun nearest(x: Float, y: Float, r: Float, accept: (Obj) -> Boolean): Obj? {
        val s = snap
        val objs = s.objs
        var best: Obj? = null
        var bd = r * r
        var i = s.firstIndexAtY(y - r)
        while (i < objs.size && objs[i].y <= y + r) {
            val o = objs[i]
            if (o.b == null && accept(o)) {
                val dx = o.x - x; val dy = o.y - y
                val d = dx * dx + dy * dy
                if (d < bd) { bd = d; best = o }
            }
            i++
        }
        return best
    }

    /** Edificio en cuyo interior está el punto, o null si está fuera. */
    fun buildingAt(x: Float, y: Float): Building? {
        if ((grid.flags(x, y) and INSIDE) == 0) return null
        for (b in snap.enterables) {
            if (x < b.minX || x > b.maxX || y < b.minY || y > b.maxY) continue
            if (pointInPoly(b.xs, b.ys, x, y)) return b
        }
        return null
    }
}

/** Convierte el JSON de Overpass (out geom) de una tesela en formas, colisiones y objetos. */
object WorldBuilder {
    private const val TREE_CAP = 9000
    private const val BUSH_CAP = 4000

    private val SKIP_HIGHWAY = setOf("proposed", "construction", "raceway", "platform", "bus_stop")

    fun buildTile(json: String, tx: Int, ty: Int, grid: Grid): TileData {
        val minX = tileMin(tx); val maxX = minX + TILE_PX
        val minY = tileMin(ty); val maxY = minY + TILE_PX
        val clip = grid.clipOf(tx, ty)

        fun touches(s: Shape, pad: Float) =
            s.maxX + pad >= minX && s.minX - pad < maxX && s.maxY + pad >= minY && s.minY - pad < maxY

        val els = JSONObject(json).optJSONArray("elements") ?: JSONArray()
        val areas = ArrayList<Area>()
        val roads = ArrayList<Road>()
        val waterLines = ArrayList<Road>()
        val buildings = ArrayList<Building>()
        val treeNodes = ArrayList<FloatArray>()
        val rails = ArrayList<Rail>()
        val fenceLines = ArrayList<Pair<Int, Shape>>()     // (estilo, línea)

        for (idx in 0 until els.length()) {
            val e = els.getJSONObject(idx)
            val tags = e.optJSONObject("tags") ?: continue
            val id = e.optLong("id", 0L)

            if (e.optString("type") == "node") {
                if (tags.optString("natural") == "tree") {
                    val x = Region.px(e.getDouble("lon")); val y = Region.py(e.getDouble("lat"))
                    if (x >= minX && x < maxX && y >= minY && y < maxY) treeNodes.add(floatArrayOf(x, y))
                }
                continue
            }

            val xs: FloatArray; val ys: FloatArray
            val pts = e.optString("pts", "")
            if (pts.isNotEmpty()) {
                // formato del mapa base: "lon,lat,lon,lat,..."
                val parts = pts.split(',')
                val n = parts.size / 2
                if (n < 2) continue
                xs = FloatArray(n); ys = FloatArray(n)
                for (k in 0 until n) {
                    xs[k] = Region.px(parts[2 * k].toDouble()); ys[k] = Region.py(parts[2 * k + 1].toDouble())
                }
            } else {
                // formato de Overpass (zonas descargadas): geometry = [{lat, lon}, ...]
                val g = e.optJSONArray("geometry") ?: continue
                val n = g.length()
                if (n < 2) continue
                xs = FloatArray(n); ys = FloatArray(n)
                for (k in 0 until n) {
                    val p = g.optJSONObject(k)
                    if (p == null) {
                        xs[k] = if (k > 0) xs[k - 1] else 0f
                        ys[k] = if (k > 0) ys[k - 1] else 0f
                    } else {
                        xs[k] = Region.px(p.getDouble("lon")); ys[k] = Region.py(p.getDouble("lat"))
                    }
                }
            }
            val n0 = xs.size
            val isClip = e.optBoolean("clip", false)
            val closed = n0 >= 4 && xs[0] == xs[n0 - 1] && ys[0] == ys[n0 - 1]

            val bar = tags.optString("barrier")
            if (bar.isNotEmpty()) {
                val style = when (bar) { "hedge" -> 1; "wall" -> 2; else -> 0 }
                fenceLines.add(Pair(style, Shape(xs, ys)))
                continue
            }
            val rw = tags.optString("railway")
            if (rw.isNotEmpty()) {
                rails.add(Rail(xs, ys).also { it.id = id })
                continue
            }

            val bt = tags.optString("building")
            if (bt.isNotEmpty() && bt != "no") {
                if (closed) {
                    val b = Building(xs.copyOf(n0 - 1), ys.copyOf(n0 - 1), buildingHeightPx(tags, bt))
                    b.id = id
                    b.church = tags.optString("church") == "1"
                    buildings.add(b)
                }
                continue
            }
            val hw = tags.optString("highway")
            if (hw.isNotEmpty()) {
                if (hw !in SKIP_HIGHWAY) roads.add(Road(roadWidthM(hw) * PPM, xs, ys).also { it.id = id })
                continue
            }
            val ww = tags.optString("waterway")
            if (ww.isNotEmpty()) {
                waterLines.add(Road(waterWidthM(ww) * PPM, xs, ys).also { it.id = id })
                continue
            }
            if (!closed) continue
            val kind = areaKind(tags)
            if (kind >= 0) areas.add(Area(kind, xs.copyOf(n0 - 1), ys.copyOf(n0 - 1)).also { it.id = id; it.clipped = isClip; it.crop = kind == K.FARM && tags.optString("landuse") == "farmland" })
        }

        // --- rejilla de colisión / ocupación (solo la parte que cae dentro de esta tesela) ---
        for (b in buildings) {
            if (!touches(b, 4f)) continue
            if (b.enterable) {
                // interior caminable + anillo de pared sólido
                grid.fillPoly(b.xs, b.ys, INSIDE, clip)
                val n = b.xs.size
                val rx = b.xs.copyOf(n + 1); val ry = b.ys.copyOf(n + 1)
                rx[n] = b.xs[0]; ry[n] = b.ys[0]
                grid.markLine(rx, ry, 2f, SOLID, clip)
            } else {
                grid.fillPoly(b.xs, b.ys, SOLID, clip)
            }
        }
        for (a in areas) {
            if (!touches(a, 0f)) continue
            if (a.kind == K.WATER) grid.fillPoly(a.xs, a.ys, SWIM, clip)
            else if (a.kind == K.WET) grid.fillPoly(a.xs, a.ys, MUD, clip)
        }
        // tierra firme dentro del mar (cayos): quita el agua que se marcó debajo
        for (a in areas) if (a.kind == K.LAND && touches(a, 0f)) grid.fillPoly(a.xs, a.ys, SWIM, clip, true)
        for (r in waterLines) if (touches(r, r.width)) grid.markLine(r.xs, r.ys, r.width, SWIM, clip)
        for (r in roads) if (touches(r, r.width)) grid.markLine(r.xs, r.ys, r.width + 4f, ROAD, clip)
        for ((_, f) in fenceLines) if (touches(f, 3f)) grid.markLine(f.xs, f.ys, 1f, FENCE, clip)

        // Puertas: si la salida está bloqueada (vecino pegado, agua…) el edificio queda cerrado.
        for (b in buildings) {
            if (!b.enterable) continue
            if (!touches(b, 4f)) continue
            val ox = b.doorMx + b.doorNx * 8f
            val oy = b.doorMy + b.doorNy * 8f
            if ((grid.flags(ox, oy) and SOLID) != 0) {
                b.enterable = false
                grid.fillPoly(b.xs, b.ys, SOLID, clip)
            } else {
                grid.clearSegment(b.doorAx, b.doorAy, b.doorBx, b.doorBy, SOLID, clip)
            }
        }

        // --- objetos ordenables: edificios y árboles ---
        val buildingObjs = ArrayList<Obj>()
        for (b in buildings) buildingObjs.add(Obj((b.minX + b.maxX) / 2f, b.maxY, b, 0))

        val objs = ArrayList<Obj>()
        for (t in treeNodes) {
            if ((grid.flags(t[0], t[1]) and (SOLID or INSIDE)) == 0) objs.add(Obj(t[0], t[1], null, (t[0] * 7f + t[1]).toInt() and 0xFF))
        }

        var count = 0
        forest@ for (a in areas) {
            val cellM: Float; val prob: Float
            when (a.kind) {
                K.FOREST -> { cellM = 8.5f; prob = 0.9f }
                K.SCRUB -> { cellM = 14f; prob = 0.35f }
                K.PARK -> { cellM = 16f; prob = 0.45f }
                else -> continue@forest
            }
            if (!touches(a, 0f)) continue
            val cs = cellM * PPM
            val gx0 = floor(max(a.minX, minX) / cs).toInt(); val gx1 = floor(min(a.maxX, maxX) / cs).toInt()
            val gy0 = floor(max(a.minY, minY) / cs).toInt(); val gy1 = floor(min(a.maxY, maxY) / cs).toInt()
            for (gy in gy0..gy1) for (gx in gx0..gx1) {
                if (count >= TREE_CAP) break@forest
                val h = hash(gx, gy, a.kind)
                if (r01(h, 0) > prob) continue
                val x = (gx + 0.15f + 0.7f * r01(h, 8)) * cs
                val y = (gy + 0.15f + 0.7f * r01(h, 16)) * cs
                if (x < minX || x >= maxX || y < minY || y >= maxY) continue
                if (!pip(a.xs, a.ys, x, y)) continue
                if (grid.flags(x, y) != 0) continue
                objs.add(Obj(x, y, null, h ushr 24))
                count++
            }
        }

        // --- arbustos: en bosques, matorral, parques y praderas ---
        var bushCount = 0
        bush@ for (a in areas) {
            val cellM: Float; val prob: Float
            when (a.kind) {
                K.FOREST -> { cellM = 11f; prob = 0.30f }
                K.SCRUB -> { cellM = 8f; prob = 0.55f }
                K.PARK -> { cellM = 14f; prob = 0.30f }
                K.GRASS -> { cellM = 16f; prob = 0.22f }
                else -> continue@bush
            }
            if (!touches(a, 0f)) continue
            val cs = cellM * PPM
            val gx0 = floor(max(a.minX, minX) / cs).toInt(); val gx1 = floor(min(a.maxX, maxX) / cs).toInt()
            val gy0 = floor(max(a.minY, minY) / cs).toInt(); val gy1 = floor(min(a.maxY, maxY) / cs).toInt()
            for (gy in gy0..gy1) for (gx in gx0..gx1) {
                if (bushCount >= BUSH_CAP) break@bush
                val h = hash(gx, gy, a.kind + 50)
                if (r01(h, 0) > prob) continue
                val x = (gx + 0.15f + 0.7f * r01(h, 8)) * cs
                val y = (gy + 0.15f + 0.7f * r01(h, 16)) * cs
                if (x < minX || x >= maxX || y < minY || y >= maxY) continue
                if (!pip(a.xs, a.ys, x, y)) continue
                if (grid.flags(x, y) != 0) continue
                objs.add(Obj(x, y, null, h ushr 24, KIND_BUSH))
                bushCount++
            }
        }

        // --- piedras sueltas por el suelo (cada una guarda 1 o 2 piedras) ---
        val stoneCell = 35f
        val sx0 = floor(minX / stoneCell).toInt(); val sx1 = floor(maxX / stoneCell).toInt()
        val sy0 = floor(minY / stoneCell).toInt(); val sy1 = floor(maxY / stoneCell).toInt()
        for (gy in sy0..sy1) for (gx in sx0..sx1) {
            val h = hash(gx, gy, 777)
            if (r01(h, 0) > 0.17f) continue
            val x = (gx + 0.15f + 0.7f * r01(h, 8)) * stoneCell
            val y = (gy + 0.15f + 0.7f * r01(h, 16)) * stoneCell
            if (x < minX || x >= maxX || y < minY || y >= maxY) continue
            if (grid.flags(x, y) != 0) continue
            objs.add(Obj(x, y, null, h ushr 24, KIND_STONE))
        }

        // --- cercas, setos y muros: trozos de ~12 px (cada trozo pertenece a la tesela donde está su centro) ---
        for ((style, f) in fenceLines) {
            if (!touches(f, 8f)) continue
            fencePieces(f, style, minX, maxX, minY, maxY, objs)
        }

        // --- montones de basura en los vertederos (decorativos) ---
        var trash = 0
        dump@ for (a in areas) {
            if (a.kind != K.DUMP || !touches(a, 0f)) continue
            val cs = 11f * PPM
            val gx0 = floor(max(a.minX, minX) / cs).toInt(); val gx1 = floor(min(a.maxX, maxX) / cs).toInt()
            val gy0 = floor(max(a.minY, minY) / cs).toInt(); val gy1 = floor(min(a.maxY, maxY) / cs).toInt()
            for (gy in gy0..gy1) for (gx in gx0..gx1) {
                if (trash >= 2500) break@dump
                val h = hash(gx, gy, 4242)
                if (r01(h, 0) > 0.5f) continue
                val x = (gx + 0.15f + 0.7f * r01(h, 8)) * cs
                val y = (gy + 0.15f + 0.7f * r01(h, 16)) * cs
                if (x < minX || x >= maxX || y < minY || y >= maxY) continue
                if (!pip(a.xs, a.ys, x, y)) continue
                if (grid.flags(x, y) != 0) continue
                objs.add(Obj(x, y, null, h ushr 24, KIND_TRASH))
                trash++
            }
        }

        return TileData(tx, ty, areas, roads, waterLines, rails, buildings, buildingObjs, objs)
    }

    private const val FENCE_LEN = 12f

    /** Reparte una línea en trocitos de cerca; solo se queda con los que tienen su centro dentro de la tesela. */
    private fun fencePieces(f: Shape, style: Int, minX: Float, maxX: Float, minY: Float, maxY: Float, out: MutableList<Obj>) {
        val xs = f.xs; val ys = f.ys
        var prevX = xs[0]; var prevY = ys[0]
        var rem = 0f
        fun add(ax: Float, ay: Float, bx: Float, by: Float) {
            val mx = (ax + bx) / 2f; val my = (ay + by) / 2f
            if (mx >= minX && mx < maxX && my >= minY && my < maxY) out.add(FencePiece(ax, ay, bx, by, style))
        }
        for (i in 1 until xs.size) {
            val ax = xs[i - 1]; val ay = ys[i - 1]; val bx = xs[i]; val by = ys[i]
            val seg = hypot(bx - ax, by - ay)
            if (seg < 0.01f) continue
            var p = FENCE_LEN - rem
            var lastP = 0f
            var cut = false
            while (p <= seg) {
                val qx = ax + (bx - ax) * (p / seg); val qy = ay + (by - ay) * (p / seg)
                add(prevX, prevY, qx, qy)
                prevX = qx; prevY = qy
                lastP = p; cut = true
                p += FENCE_LEN
            }
            rem = if (cut) seg - lastP else rem + seg
        }
        if (rem > 1f) add(prevX, prevY, xs[xs.size - 1], ys[ys.size - 1])
    }

    private fun buildingHeightPx(tags: JSONObject, type: String): Float {
        val explicit = tags.optString("height").takeWhile { it.isDigit() || it == '.' }.toFloatOrNull()
        val levels = tags.optString("building:levels").toFloatOrNull()
        val hm: Float = explicit ?: (levels?.let { it * 3f + 0.5f } ?: when (type) {
            "shed", "garage", "garages", "carport", "hut", "roof", "kiosk", "service" -> 3f
            "apartments", "commercial", "industrial", "retail", "office", "hotel", "hospital", "school" -> 12f
            "church", "cathedral" -> 14f
            else -> 6.5f
        })
        return (hm * PPM).coerceIn(7f, 60f)
    }

    private fun roadWidthM(hw: String) = when (hw) {
        "motorway", "trunk" -> 12f
        "primary" -> 10f
        "secondary" -> 9f
        "tertiary" -> 8f
        "residential", "unclassified", "living_street", "road" -> 6f
        "service" -> 4f
        "track" -> 3.5f
        "pedestrian" -> 5f
        "footway", "cycleway", "steps", "corridor" -> 1.2f
        "path", "bridleway" -> 0.9f          // senderos: muy estrechos
        else -> 4f
    }

    private fun waterWidthM(ww: String) = when (ww) {
        "river" -> 10f
        "canal" -> 6f
        "stream" -> 2.6f
        else -> 1.6f
    }

    private fun areaKind(tags: JSONObject): Int {
        when (tags.optString("natural")) {
            "water" -> return K.WATER
            "coastline" -> return K.LAND
            "wetland", "mud" -> return K.WET
            "wood" -> return K.FOREST
            "scrub", "heath" -> return K.SCRUB
            "grassland" -> return K.GRASS
            "sand", "beach" -> return K.SAND
        }
        when (tags.optString("landuse")) {
            "forest" -> return K.FOREST
            "grass", "meadow", "cemetery", "village_green", "recreation_ground" -> return K.GRASS
            "farmland", "farmyard", "orchard", "vineyard" -> return K.FARM
            "industrial", "commercial", "retail" -> return K.URBAN
            "reservoir", "basin" -> return K.WATER
            "landfill" -> return K.DUMP
        }
        when (tags.optString("leisure")) {
            "park", "garden", "playground", "pitch", "golf_course", "nature_reserve" -> return K.PARK
        }
        return -1
    }

    private fun pip(xs: FloatArray, ys: FloatArray, x: Float, y: Float): Boolean {
        var c = false
        var j = xs.size - 1
        for (i in xs.indices) {
            if ((ys[i] > y) != (ys[j] > y) &&
                x < (xs[j] - xs[i]) * (y - ys[i]) / (ys[j] - ys[i]) + xs[i]) c = !c
            j = i
        }
        return c
    }

    private fun hash(a: Int, b: Int, s: Int): Int {
        var h = a * 374761393 + b * 668265263 + s * 144665
        h = (h xor (h ushr 13)) * 1274126177.toInt()
        return h xor (h ushr 16)
    }

    private fun r01(h: Int, shift: Int) = ((h ushr shift) and 0xFF) / 255f
}
