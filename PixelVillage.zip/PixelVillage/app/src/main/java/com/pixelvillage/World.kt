package com.pixelvillage

import android.graphics.Path
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

const val PPM = 2.5f   // píxeles del juego por metro real
const val CELL = 2     // tamaño de celda de colisión (px)
const val SOLID = 1
const val ROAD = 2
const val INSIDE = 4   // interior caminable de un edificio
const val SWIM = 8     // agua por la que se puede caminar (hundido)

// tipos de objeto del mundo (los que no son edificios)
const val KIND_TREE = 0
const val KIND_BUSH = 1
const val KIND_STONE = 2

/** Tipos de terreno, ordenados por prioridad de dibujo. */
object K {
    const val GRASS = 0
    const val FARM = 1
    const val URBAN = 2
    const val PARK = 3
    const val SAND = 4
    const val SCRUB = 5
    const val FOREST = 6
    const val WATER = 7
    // luminancia (0 = oscuro, 1 = claro) de cada terreno
    val LUM = floatArrayOf(0.70f, 0.76f, 0.50f, 0.74f, 0.88f, 0.52f, 0.38f, 0.14f)
}

/** Punto dentro de polígono (ray casting). */
fun pointInPoly(xs: FloatArray, ys: FloatArray, x: Float, y: Float): Boolean {
    var c = false
    var j = xs.size - 1
    for (i in xs.indices) {
        if ((ys[i] > y) != (ys[j] > y) &&
            x < (xs[j] - xs[i]) * (y - ys[i]) / (ys[j] - ys[i]) + xs[i]) c = !c
        j = i
    }
    return c
}

open class Shape(val xs: FloatArray, val ys: FloatArray) {
    val minX = xs.min()
    val maxX = xs.max()
    val minY = ys.min()
    val maxY = ys.max()
}

class Area(val kind: Int, xs: FloatArray, ys: FloatArray) : Shape(xs, ys) {
    val path = Path().apply {
        moveTo(xs[0], ys[0])
        for (i in 1 until xs.size) lineTo(xs[i], ys[i])
        close()
    }
}

class Road(val width: Float, xs: FloatArray, ys: FloatArray) : Shape(xs, ys) {
    val path = Path().apply {
        moveTo(xs[0], ys[0])
        for (i in 1 until xs.size) lineTo(xs[i], ys[i])
    }
}

/** Edificio extruido en proyección oblicua: paredes, tejado nevado, ventanas, sombra, puerta e interior. */
class Building(xs: FloatArray, ys: FloatArray, val h: Float) : Shape(xs, ys) {
    val roof = Path()       // huella del edificio (también sirve de suelo)
    val wallA = Path()      // paredes orientadas al este (en sombra)
    val wallB = Path()      // paredes orientadas al oeste (iluminadas)
    val windows = Path()
    val shadow = Path()
    val wallBack = Path()   // cara interior de las paredes del fondo (vista de interior)
    val wallFront = Path()  // pared baja delantera con hueco de puerta (vista de interior)
    val door = Path()       // puerta dibujada en la pared exterior

    var enterable = false
    var doorAx = 0f; var doorAy = 0f; var doorBx = 0f; var doorBy = 0f
    var doorMx = 0f; var doorMy = 0f
    var doorNx = 0f; var doorNy = 0f

    private fun quad(p: Path, x1: Float, y1: Float, x2: Float, y2: Float, hh: Float) {
        p.moveTo(x1, y1); p.lineTo(x2, y2); p.lineTo(x2, y2 - hh); p.lineTo(x1, y1 - hh); p.close()
    }

    init {
        val n = xs.size
        roof.moveTo(xs[0], ys[0])
        for (i in 1 until n) roof.lineTo(xs[i], ys[i])
        roof.close()

        var area = 0f
        var j = n - 1
        for (i in 0 until n) { area += xs[j] * ys[i] - xs[i] * ys[j]; j = i }
        val cw = area > 0f
        val backH = min(h, 24f)

        var bestLen = 0f
        var bestI = -1
        for (i in 0 until n) {
            val k = (i + 1) % n
            val x1 = xs[i]; val y1 = ys[i]; val x2 = xs[k]; val y2 = ys[k]
            val dx = x2 - x1; val dy = y2 - y1
            val nx: Float; val ny: Float
            if (cw) { nx = dy; ny = -dx } else { nx = -dy; ny = dx }
            val len = hypot(dx, dy)
            if (ny > 0.001f) {                               // pared que mira a la cámara
                quad(if (nx > 0f) wallA else wallB, x1, y1, x2, y2, h)
                if (h >= 9f && len >= 9f) {
                    val cnt = (len / 9f).toInt()
                    for (m in 0 until cnt) {
                        val t = (m + 0.5f) / cnt
                        val wx = x1 + dx * t
                        val wy = y1 + dy * t - h * 0.5f
                        windows.addRect(wx - 1f, wy - 1.5f, wx + 1f, wy + 1.5f, Path.Direction.CW)
                    }
                }
                if (len > bestLen) { bestLen = len; bestI = i }
            } else if (ny < -0.001f) {                       // pared del fondo (solo se ve por dentro)
                quad(wallBack, x1, y1, x2, y2, backH)
            }
        }

        // Solo se puede entrar a edificios de tamaño razonable con una pared sur larga.
        enterable = bestI >= 0 && bestLen >= 12f && (maxX - minX) >= 14f &&
            (maxY - minY) >= 12f && abs(area) / 2f >= 200f

        val lowH = 6f
        for (i in 0 until n) {
            val k = (i + 1) % n
            val x1 = xs[i]; val y1 = ys[i]; val x2 = xs[k]; val y2 = ys[k]
            val dx = x2 - x1; val dy = y2 - y1
            val nx: Float; val ny: Float
            if (cw) { nx = dy; ny = -dx } else { nx = -dy; ny = dx }
            if (ny <= 0.001f) continue
            val len = hypot(dx, dy)
            if (enterable && i == bestI) {
                val dw = min(9f, len * 0.5f)
                val t0 = 0.5f - dw / (2f * len)
                val t1 = 0.5f + dw / (2f * len)
                doorAx = x1 + dx * t0; doorAy = y1 + dy * t0
                doorBx = x1 + dx * t1; doorBy = y1 + dy * t1
                doorMx = x1 + dx * 0.5f; doorMy = y1 + dy * 0.5f
                doorNx = nx / len; doorNy = ny / len
                quad(wallFront, x1, y1, doorAx, doorAy, lowH)
                quad(wallFront, doorBx, doorBy, x2, y2, lowH)
                quad(door, doorAx, doorAy, doorBx, doorBy, min(h - 3f, 9f))
            } else {
                quad(wallFront, x1, y1, x2, y2, lowH)
            }
        }

        shadow.set(roof)
        for (t in floatArrayOf(0.4f, 0.7f, 1f)) {
            val p = Path(roof)
            p.offset(h * 0.9f * t, -h * 0.18f * t)
            shadow.op(p, Path.Op.UNION)
        }
    }
}

/** Objeto ordenable por profundidad: edificio (b != null) o árbol. */
class Obj(val x: Float, val y: Float, val b: Building?, val variant: Int, val kind: Int = KIND_TREE)

/** Rejilla de colisión / ocupación. */
class Grid(val half: Int) {
    val dim = (2 * half + CELL - 1) / CELL
    val cells = ByteArray(dim * dim)

    private fun gi(v: Float) = floor((v + half) / CELL).toInt()

    fun flags(x: Float, y: Float): Int {
        val gx = gi(x); val gy = gi(y)
        if (gx < 0 || gy < 0 || gx >= dim || gy >= dim) return SOLID
        return cells[gy * dim + gx].toInt()
    }

    private fun set(gx: Int, gy: Int, flag: Int) {
        if (gx < 0 || gy < 0 || gx >= dim || gy >= dim) return
        val i = gy * dim + gx
        cells[i] = (cells[i].toInt() or flag).toByte()
    }

    /** Relleno de polígono por scanline. */
    fun fillPoly(xs: FloatArray, ys: FloatArray, flag: Int) {
        val n = xs.size
        if (n < 3) return
        val gy0 = max(0, gi(ys.min())); val gy1 = min(dim - 1, gi(ys.max()))
        val tmp = FloatArray(n)
        for (gy in gy0..gy1) {
            val y = (gy + 0.5f) * CELL - half
            var cnt = 0
            var j = n - 1
            for (i in 0 until n) {
                if ((ys[i] > y) != (ys[j] > y)) {
                    tmp[cnt++] = xs[i] + (y - ys[i]) * (xs[j] - xs[i]) / (ys[j] - ys[i])
                }
                j = i
            }
            java.util.Arrays.sort(tmp, 0, cnt)
            var k = 0
            while (k + 1 < cnt) {
                val a = max(0, gi(tmp[k])); val b = min(dim - 1, gi(tmp[k + 1]))
                for (gx in a..b) set(gx, gy, flag)
                k += 2
            }
        }
    }

    private fun clear(gx: Int, gy: Int, flag: Int) {
        if (gx < 0 || gy < 0 || gx >= dim || gy >= dim) return
        val i = gy * dim + gx
        cells[i] = (cells[i].toInt() and flag.inv()).toByte()
    }

    /** Quita una marca a lo largo de un segmento (para abrir el hueco de una puerta). */
    fun clearSegment(x1: Float, y1: Float, x2: Float, y2: Float, flag: Int) {
        val steps = max(1, (hypot(x2 - x1, y2 - y1) * 2f).toInt())
        for (s in 0..steps) {
            val t = s.toFloat() / steps
            val cx = gi(x1 + (x2 - x1) * t); val cy = gi(y1 + (y2 - y1) * t)
            for (oy in -1..1) for (ox in -1..1) clear(cx + ox, cy + oy, flag)
        }
    }

    fun markLine(xs: FloatArray, ys: FloatArray, width: Float, flag: Int) {
        val rc = ceil(width / 2f / CELL).toInt()
        for (i in 0 until xs.size - 1) {
            val dx = xs[i + 1] - xs[i]; val dy = ys[i + 1] - ys[i]
            val steps = max(1, (hypot(dx, dy) / CELL).toInt())
            for (s in 0..steps) {
                val t = s.toFloat() / steps
                val cx = gi(xs[i] + dx * t); val cy = gi(ys[i] + dy * t)
                for (oy in -rc..rc) for (ox in -rc..rc) {
                    if (ox * ox + oy * oy <= rc * rc) set(cx + ox, cy + oy, flag)
                }
            }
        }
    }
}

class World(
    val areas: List<Area>,
    val roads: List<Road>,
    val waterLines: List<Road>,
    val objs: Array<Obj>,
    private val grid: Grid,
    val startX: Float,
    val startY: Float,
    private val enterables: List<Building>
) {
    fun blocked(x: Float, y: Float) = (grid.flags(x, y) and SOLID) != 0

    /** Multiplicador de velocidad según el terreno: camino 1.0, campo 0.8, agua 0.5. */
    fun speedFactorAt(x: Float, y: Float): Float {
        val f = grid.flags(x, y)
        return when {
            (f and INSIDE) != 0 -> 1f
            (f and ROAD) != 0 -> 1f
            (f and SWIM) != 0 -> 0.5f
            else -> 0.8f
        }
    }

    fun inWater(x: Float, y: Float): Boolean {
        val f = grid.flags(x, y)
        return (f and SWIM) != 0 && (f and (ROAD or INSIDE)) == 0
    }

    /** Suelo libre (sin camino, edificio, agua ni interior): ahí crece la hierba. */
    fun groundFree(x: Float, y: Float) = grid.flags(x, y) == 0

    /** Objeto (no edificio) más cercano dentro del radio r que cumpla accept, o null. */
    fun nearest(x: Float, y: Float, r: Float, accept: (Obj) -> Boolean): Obj? {
        var best: Obj? = null
        var bd = r * r
        var i = firstIndexAtY(y - r)
        while (i < objs.size && objs[i].y <= y + r) {
            val o = objs[i]
            if (o.b == null && accept(o)) {
                val dx = o.x - x; val dy = o.y - y
                val d = dx * dx + dy * dy
                if (d < bd) { bd = d; best = o }
            }
            i++
        }
        return best
    }

    /** Árbol más cercano dentro del radio r, o null. */
    fun nearestTree(x: Float, y: Float, r: Float): Obj? {
        var best: Obj? = null
        var bd = r * r
        var i = firstIndexAtY(y - r)
        while (i < objs.size && objs[i].y <= y + r) {
            val o = objs[i]
            if (o.b == null) {
                val dx = o.x - x; val dy = o.y - y
                val d = dx * dx + dy * dy
                if (d < bd) { bd = d; best = o }
            }
            i++
        }
        return best
    }

    /** Edificio en cuyo interior está el punto, o null si está fuera. */
    fun buildingAt(x: Float, y: Float): Building? {
        if ((grid.flags(x, y) and INSIDE) == 0) return null
        for (b in enterables) {
            if (x < b.minX || x > b.maxX || y < b.minY || y > b.maxY) continue
            if (pointInPoly(b.xs, b.ys, x, y)) return b
        }
        return null
    }

    /** Primer índice de objs cuya base (y) sea >= y. */
    fun firstIndexAtY(y: Float): Int {
        var lo = 0; var hi = objs.size
        while (lo < hi) {
            val m = (lo + hi) ushr 1
            if (objs[m].y < y) lo = m + 1 else hi = m
        }
        return lo
    }
}

/** Convierte el JSON de Overpass (out geom) en un mundo jugable. */
object WorldBuilder {
    private const val TREE_CAP = 30000

    private val SKIP_HIGHWAY = setOf("proposed", "construction", "raceway", "platform", "bus_stop")

    fun build(json: String, lat0: Double, lon0: Double, radiusM: Int): World {
        val mLat = 110540.0
        val mLon = 111320.0 * cos(Math.toRadians(lat0))
        fun px(lon: Double) = ((lon - lon0) * mLon * PPM).toFloat()
        fun py(lat: Double) = (-(lat - lat0) * mLat * PPM).toFloat()

        val els = JSONObject(json).optJSONArray("elements") ?: JSONArray()
        val areas = ArrayList<Area>()
        val roads = ArrayList<Road>()
        val waterLines = ArrayList<Road>()
        val buildings = ArrayList<Building>()
        val treeNodes = ArrayList<FloatArray>()

        for (idx in 0 until els.length()) {
            val e = els.getJSONObject(idx)
            val tags = e.optJSONObject("tags") ?: continue

            if (e.optString("type") == "node") {
                if (tags.optString("natural") == "tree") {
                    treeNodes.add(floatArrayOf(px(e.getDouble("lon")), py(e.getDouble("lat"))))
                }
                continue
            }

            val g = e.optJSONArray("geometry") ?: continue
            val n0 = g.length()
            if (n0 < 2) continue
            val xs = FloatArray(n0); val ys = FloatArray(n0)
            for (k in 0 until n0) {
                val p = g.optJSONObject(k)
                if (p == null) {
                    xs[k] = if (k > 0) xs[k - 1] else 0f
                    ys[k] = if (k > 0) ys[k - 1] else 0f
                } else {
                    xs[k] = px(p.getDouble("lon")); ys[k] = py(p.getDouble("lat"))
                }
            }
            val closed = n0 >= 4 && xs[0] == xs[n0 - 1] && ys[0] == ys[n0 - 1]

            val bt = tags.optString("building")
            if (bt.isNotEmpty() && bt != "no") {
                if (closed) buildings.add(Building(xs.copyOf(n0 - 1), ys.copyOf(n0 - 1), buildingHeightPx(tags, bt)))
                continue
            }
            val hw = tags.optString("highway")
            if (hw.isNotEmpty()) {
                if (hw !in SKIP_HIGHWAY) roads.add(Road(roadWidthM(hw) * PPM, xs, ys))
                continue
            }
            val ww = tags.optString("waterway")
            if (ww.isNotEmpty()) {
                waterLines.add(Road(waterWidthM(ww) * PPM, xs, ys))
                continue
            }
            if (!closed) continue
            val kind = areaKind(tags)
            if (kind >= 0) areas.add(Area(kind, xs.copyOf(n0 - 1), ys.copyOf(n0 - 1)))
        }

        roads.sortBy { it.width }          // las anchas se dibujan encima
        areas.sortBy { it.kind }

        // --- rejilla de colisión / ocupación ---
        val grid = Grid((radiusM * PPM).toInt() + 60)
        for (b in buildings) {
            if (b.enterable) {
                // interior caminable + anillo de pared sólido
                grid.fillPoly(b.xs, b.ys, INSIDE)
                val n = b.xs.size
                val rx = b.xs.copyOf(n + 1); val ry = b.ys.copyOf(n + 1)
                rx[n] = b.xs[0]; ry[n] = b.ys[0]
                grid.markLine(rx, ry, 2f, SOLID)
            } else {
                grid.fillPoly(b.xs, b.ys, SOLID)
            }
        }
        for (a in areas) if (a.kind == K.WATER) grid.fillPoly(a.xs, a.ys, SWIM)
        for (r in waterLines) grid.markLine(r.xs, r.ys, r.width, SWIM)
        for (r in roads) grid.markLine(r.xs, r.ys, r.width + 4f, ROAD)

        // Puertas: si la salida está bloqueada (vecino pegado, agua…) el edificio queda cerrado.
        for (b in buildings) {
            if (!b.enterable) continue
            val ox = b.doorMx + b.doorNx * 8f
            val oy = b.doorMy + b.doorNy * 8f
            if ((grid.flags(ox, oy) and SOLID) != 0) {
                b.enterable = false
                grid.fillPoly(b.xs, b.ys, SOLID)
            } else {
                grid.clearSegment(b.doorAx, b.doorAy, b.doorBx, b.doorBy, SOLID)
            }
        }
        val enterables = buildings.filter { it.enterable }

        // --- objetos ordenables: edificios y árboles ---
        val objs = ArrayList<Obj>()
        for (b in buildings) objs.add(Obj((b.minX + b.maxX) / 2f, b.maxY, b, 0))

        for (t in treeNodes) {
            if ((grid.flags(t[0], t[1]) and (SOLID or INSIDE)) == 0) objs.add(Obj(t[0], t[1], null, (t[0] * 7f + t[1]).toInt() and 0xFF))
        }

        var count = 0
        forest@ for (a in areas) {
            val cellM: Float; val prob: Float
            when (a.kind) {
                K.FOREST -> { cellM = 8.5f; prob = 0.9f }
                K.SCRUB -> { cellM = 14f; prob = 0.35f }
                K.PARK -> { cellM = 16f; prob = 0.45f }
                else -> continue@forest
            }
            val cs = cellM * PPM
            val gx0 = floor(a.minX / cs).toInt(); val gx1 = floor(a.maxX / cs).toInt()
            val gy0 = floor(a.minY / cs).toInt(); val gy1 = floor(a.maxY / cs).toInt()
            for (gy in gy0..gy1) for (gx in gx0..gx1) {
                if (count >= TREE_CAP) break@forest
                val h = hash(gx, gy, a.kind)
                if (r01(h, 0) > prob) continue
                val x = (gx + 0.15f + 0.7f * r01(h, 8)) * cs
                val y = (gy + 0.15f + 0.7f * r01(h, 16)) * cs
                if (!pip(a.xs, a.ys, x, y)) continue
                if (grid.flags(x, y) != 0) continue
                objs.add(Obj(x, y, null, h ushr 24))
                count++
            }
        }

        // --- arbustos: en bosques, matorral, parques y praderas ---
        var bushCount = 0
        bush@ for (a in areas) {
            val cellM: Float; val prob: Float
            when (a.kind) {
                K.FOREST -> { cellM = 11f; prob = 0.30f }
                K.SCRUB -> { cellM = 8f; prob = 0.55f }
                K.PARK -> { cellM = 14f; prob = 0.30f }
                K.GRASS -> { cellM = 16f; prob = 0.22f }
                else -> continue@bush
            }
            val cs = cellM * PPM
            val gx0 = floor(a.minX / cs).toInt(); val gx1 = floor(a.maxX / cs).toInt()
            val gy0 = floor(a.minY / cs).toInt(); val gy1 = floor(a.maxY / cs).toInt()
            for (gy in gy0..gy1) for (gx in gx0..gx1) {
                if (bushCount >= 8000) break@bush
                val h = hash(gx, gy, a.kind + 50)
                if (r01(h, 0) > prob) continue
                val x = (gx + 0.15f + 0.7f * r01(h, 8)) * cs
                val y = (gy + 0.15f + 0.7f * r01(h, 16)) * cs
                if (!pip(a.xs, a.ys, x, y)) continue
                if (grid.flags(x, y) != 0) continue
                objs.add(Obj(x, y, null, h ushr 24, KIND_BUSH))
                bushCount++
            }
        }

        // --- piedras sueltas por el suelo (cada una guarda 1 o 2 piedras) ---
        val stoneCell = 35f
        val cellsN = (2 * grid.half / stoneCell).toInt()
        for (gy in 0 until cellsN) for (gx in 0 until cellsN) {
            val h = hash(gx, gy, 777)
            if (r01(h, 0) > 0.17f) continue
            val x = -grid.half + (gx + 0.15f + 0.7f * r01(h, 8)) * stoneCell
            val y = -grid.half + (gy + 0.15f + 0.7f * r01(h, 16)) * stoneCell
            if (grid.flags(x, y) != 0) continue
            objs.add(Obj(x, y, null, h ushr 24, KIND_STONE))
        }

        objs.sortBy { it.y }

        // --- punto de inicio: tu casa (o el sitio libre más cercano) ---
        var sx = 0f; var sy = 0f
        if ((grid.flags(0f, 0f) and SOLID) != 0) {
            search@ for (r in 1..200) {
                for (dx in -r..r) for (dy in -r..r) {
                    if (abs(dx) != r && abs(dy) != r) continue
                    val x = (dx * CELL).toFloat(); val y = (dy * CELL).toFloat()
                    if ((grid.flags(x, y) and SOLID) == 0) { sx = x; sy = y; break@search }
                }
            }
        }

        return World(areas, roads, waterLines, objs.toTypedArray(), grid, sx, sy, enterables)
    }

    private fun buildingHeightPx(tags: JSONObject, type: String): Float {
        val explicit = tags.optString("height").takeWhile { it.isDigit() || it == '.' }.toFloatOrNull()
        val levels = tags.optString("building:levels").toFloatOrNull()
        val hm: Float = explicit ?: (levels?.let { it * 3f + 0.5f } ?: when (type) {
            "shed", "garage", "garages", "carport", "hut", "roof", "kiosk", "service" -> 3f
            "apartments", "commercial", "industrial", "retail", "office", "hotel", "hospital", "school" -> 12f
            "church", "cathedral" -> 14f
            else -> 6.5f
        })
        return (hm * PPM).coerceIn(7f, 60f)
    }

    private fun roadWidthM(hw: String) = when (hw) {
        "motorway", "trunk" -> 12f
        "primary" -> 10f
        "secondary" -> 9f
        "tertiary" -> 8f
        "residential", "unclassified", "living_street", "road" -> 6f
        "service" -> 4f
        "track" -> 3.5f
        "pedestrian" -> 5f
        "footway", "path", "cycleway", "steps", "bridleway", "corridor" -> 1.8f
        else -> 4f
    }

    private fun waterWidthM(ww: String) = when (ww) {
        "river" -> 10f
        "canal" -> 6f
        "stream" -> 2.6f
        else -> 1.6f
    }

    private fun areaKind(tags: JSONObject): Int {
        when (tags.optString("natural")) {
            "water" -> return K.WATER
            "wood" -> return K.FOREST
            "scrub", "heath" -> return K.SCRUB
            "grassland" -> return K.GRASS
            "sand", "beach" -> return K.SAND
        }
        when (tags.optString("landuse")) {
            "forest" -> return K.FOREST
            "grass", "meadow", "cemetery", "village_green", "recreation_ground" -> return K.GRASS
            "farmland", "farmyard", "orchard", "vineyard" -> return K.FARM
            "industrial", "commercial", "retail" -> return K.URBAN
            "reservoir", "basin" -> return K.WATER
        }
        when (tags.optString("leisure")) {
            "park", "garden", "playground", "pitch", "golf_course", "nature_reserve" -> return K.PARK
        }
        return -1
    }

    private fun pip(xs: FloatArray, ys: FloatArray, x: Float, y: Float): Boolean {
        var c = false
        var j = xs.size - 1
        for (i in xs.indices) {
            if ((ys[i] > y) != (ys[j] > y) &&
                x < (xs[j] - xs[i]) * (y - ys[i]) / (ys[j] - ys[i]) + xs[i]) c = !c
            j = i
        }
        return c
    }

    private fun hash(a: Int, b: Int, s: Int): Int {
        var h = a * 374761393 + b * 668265263 + s * 144665
        h = (h xor (h ushr 13)) * 1274126177.toInt()
        return h xor (h ushr 16)
    }

    private fun r01(h: Int, shift: Int) = ((h ushr shift) and 0xFF) / 255f
}
