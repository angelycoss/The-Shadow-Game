package com.pixelvillage

import android.content.Context
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/** Descarga de datos de OpenStreetMap (Overpass) con caché local, y búsqueda de direcciones (Nominatim). */
object Osm {
    // Pon aquí tu contacto: la política de uso de OSM pide identificar la app.
    private const val UA = "PixelVillage/0.1 (juego Android personal)"

    private val ENDPOINTS = arrayOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter"
    )

    fun fetch(ctx: Context, lat: Double, lon: Double, radiusM: Int): String {
        val cache = File(ctx.filesDir, "osm_${fmt(lat, 3)}_${fmt(lon, 3)}_$radiusM.json")
        if (cache.exists() && cache.length() > 50) return cache.readText()

        val a = "(around:$radiusM,${fmt(lat, 6)},${fmt(lon, 6)})"
        val q = """[out:json][timeout:40];(
way["building"]$a;
way["highway"]$a;
way["natural"~"^(wood|water|scrub|heath|grassland|sand|beach)$"]$a;
way["landuse"~"^(forest|grass|meadow|farmland|farmyard|orchard|vineyard|industrial|commercial|retail|cemetery|recreation_ground|village_green|reservoir|basin)$"]$a;
way["leisure"~"^(park|garden|playground|pitch|golf_course|nature_reserve)$"]$a;
way["waterway"~"^(river|stream|canal|drain|ditch)$"]$a;
node["natural"="tree"]$a;
);out geom qt;"""

        var last: Exception = IOException("Sin respuesta")
        for (ep in ENDPOINTS) {
            try {
                val txt = request(ep, q)
                if (!txt.trimStart().startsWith("{")) throw IOException("Respuesta no válida")
                if (txt.contains("\"remark\"") && txt.contains("runtime error")) throw IOException("Servidor de mapas saturado")
                cache.writeText(txt)
                return txt
            } catch (e: Exception) {
                last = e
            }
        }
        throw last
    }

    /** Devuelve (lat, lon) de la primera coincidencia, o null. */
    fun geocode(query: String): Pair<Double, Double>? {
        return try {
            val url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" + URLEncoder.encode(query, "UTF-8")
            val arr = JSONArray(request(url, null))
            if (arr.length() == 0) null
            else {
                val o = arr.getJSONObject(0)
                Pair(o.getString("lat").toDouble(), o.getString("lon").toDouble())
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun fmt(d: Double, dec: Int) = String.format(Locale.US, "%.${dec}f", d)

    private fun request(url: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", UA)
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            c.outputStream.use { it.write(("data=" + URLEncoder.encode(body, "UTF-8")).toByteArray()) }
        }
        if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }
}
