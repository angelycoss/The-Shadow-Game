package com.pixelvillage

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Datos de OpenStreetMap (Overpass) por teselas.
 *
 * Cada tesela sale de uno de tres sitios, en este orden:
 *  1. assets/base/t_X_Y.json  -> el mapa base, que viene DENTRO del APK (se baja al compilar).
 *  2. filesDir/tiles/t_X_Y.json -> zonas que ya se descargaron antes mientras explorabas.
 *  3. Internet (Overpass) -> zona nueva; se guarda en (2) para la próxima vez.
 */
object Osm {
    // Pon aquí tu contacto: la política de uso de OSM pide identificar la app.
    private const val UA = "PixelVillage/0.2 (juego Android personal)"

    // Servidores públicos de Overpass: se prueban en orden si uno está lento o saturado.
    private val ENDPOINTS = arrayOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.private.coffee/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter"
    )

    // Se pide un poco más que la tesela para que lo que cruza el borde llegue completo.
    private const val MARGIN_PX = 200f      // 80 m

    private fun name(tx: Int, ty: Int) = "t_${tx}_$ty.json"
    private fun cacheFile(ctx: Context, tx: Int, ty: Int) = File(File(ctx.filesDir, "tiles"), name(tx, ty))

    /** Lo que ya está en el teléfono (mapa base o zona descargada antes), o null. */
    fun readLocal(ctx: Context, tx: Int, ty: Int): String? {
        try {
            return ctx.assets.open("base/" + name(tx, ty)).bufferedReader().use { it.readText() }
        } catch (e: IOException) { /* no está en el mapa base */ }
        val f = cacheFile(ctx, tx, ty)
        if (f.exists() && f.length() > 50) return f.readText()
        // dentro de la zona cubierta por el mapa base, una tesela sin archivo está vacía (mar, etc.)
        return if (covered(ctx, tx, ty)) "{\"elements\":[]}" else null
    }

    @Volatile private var bounds: IntArray? = null

    private fun covered(ctx: Context, tx: Int, ty: Int): Boolean {
        val b: IntArray = bounds ?: run {
            val loaded = try {
                val j = org.json.JSONObject(ctx.assets.open("base/bounds.json").bufferedReader().use { it.readText() })
                intArrayOf(j.getInt("txMin"), j.getInt("txMax"), j.getInt("tyMin"), j.getInt("tyMax"))
            } catch (e: Exception) { intArrayOf(1, 0, 1, 0) }      // sin mapa base: nada cubierto
            bounds = loaded
            loaded
        }
        return tx >= b[0] && tx <= b[1] && ty >= b[2] && ty <= b[3]
    }

    fun dropCache(ctx: Context, tx: Int, ty: Int) {
        try { cacheFile(ctx, tx, ty).delete() } catch (e: Exception) { }
    }

    /** Consulta Overpass de una tesela. Debe coincidir con tools/fetch_base_map.py. */
    fun query(tx: Int, ty: Int): String {
        val x0 = tileMin(tx) - MARGIN_PX; val x1 = tileMin(tx) + TILE_PX + MARGIN_PX
        val y0 = tileMin(ty) - MARGIN_PX; val y1 = tileMin(ty) + TILE_PX + MARGIN_PX
        // y crece hacia el sur, así que y1 es el borde sur
        val a = "(${fmt(Region.lat(y1), 6)},${fmt(Region.lon(x0), 6)},${fmt(Region.lat(y0), 6)},${fmt(Region.lon(x1), 6)})"
        return """[out:json][timeout:60];(
way["building"]$a;
way["highway"]$a;
way["natural"~"^(wood|water|scrub|heath|grassland|sand|beach)$"]$a;
way["landuse"~"^(forest|grass|meadow|farmland|farmyard|orchard|vineyard|industrial|commercial|retail|cemetery|recreation_ground|village_green|reservoir|basin)$"]$a;
way["leisure"~"^(park|garden|playground|pitch|golf_course|nature_reserve)$"]$a;
way["waterway"~"^(river|stream|canal)$"]$a;
node["natural"="tree"]$a;
);out geom qt;"""
    }

    /** Descarga una tesela de Overpass y la guarda en el teléfono. Lanza IOException si falla. */
    fun download(ctx: Context, tx: Int, ty: Int, status: (String) -> Unit): String {
        val q = query(tx, ty)
        val errors = ArrayList<String>()
        for ((i, ep) in ENDPOINTS.withIndex()) {
            status("Descargando el mapa…\n(servidor ${i + 1} de ${ENDPOINTS.size})")
            try {
                val txt = request(ep, q)
                if (!txt.trimStart().startsWith("{")) throw IOException("respuesta no válida")
                if (txt.contains("\"remark\"") && txt.contains("runtime error")) throw IOException("servidor saturado")
                val f = cacheFile(ctx, tx, ty)
                f.parentFile?.mkdirs()
                val tmp = File(f.parentFile, f.name + ".tmp")
                tmp.writeText(txt)
                if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
                return txt
            } catch (e: Exception) {
                errors.add(URL(ep).host + ": " + (e.message ?: e.javaClass.simpleName))
            }
        }
        throw IOException(errors.joinToString("\n"))
    }

    private fun fmt(d: Double, dec: Int) = String.format(Locale.US, "%.${dec}f", d)

    private fun request(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", UA)
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        c.outputStream.use { it.write(("data=" + URLEncoder.encode(body, "UTF-8")).toByteArray()) }
        if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }
}
