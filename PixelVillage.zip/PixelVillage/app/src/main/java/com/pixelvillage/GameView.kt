package com.pixelvillage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private const val LOW_H = 180            // altura lógica del "pixel art"
private const val SPEED = 12f * PPM      // 12 m/s en px/s (sobre camino)
private const val MAXH = 64f             // altura máxima de un objeto (para el culling)
private const val GROUND_LUM = 0.62f
private const val WIND_PX = 75f          // velocidad base del viento (px/s)
private const val PN = 70                // partículas de viento
private const val ATK_DUR = 0.28f        // duración del golpe (s)
private const val REACH = 14f            // alcance para interactuar (px)
private const val CHOP_HITS = 4          // golpes de hacha para talar un árbol
private val BLACK = 0xFF000000.toInt()
private val CREAM = Color.rgb(234, 233, 219)
private val MIDGRAY = 0xFF6F656B.toInt()
private val LIGHTGRAY = 0xFFB4AEB2.toInt()

// Paleta de 4 tonos: gris-morado oscuro -> crema
private val PAL = intArrayOf(
    0xFF2A2428.toInt(), 0xFF6F656B.toInt(), 0xFFB4AEB2.toInt(), 0xFFEAE9DB.toInt()
)
// Matriz Bayer 4x4 (umbrales para el dithering ordenado)
private val BAYER = FloatArray(16).also {
    val m = intArrayOf(0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5)
    for (i in 0 until 16) it[i] = (m[i] + 0.5f) / 16f
}

private fun gray(l: Float): Int {
    val v = (l.coerceIn(0f, 1f) * 255f).toInt()
    return Color.rgb(v, v, v)
}

private fun hash2(a: Int, b: Int): Int {
    var h = a * 374761393 + b * 668265263 + 1013904223
    h = (h xor (h ushr 13)) * 1274126177
    return h xor (h ushr 16)
}

class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {

    @Volatile var world: World? = null
    @Volatile var message: String? = "Cargando…"
    @Volatile private var canRetry = false
    var onRetry: (() -> Unit)? = null

    private var thread: Thread? = null
    @Volatile private var running = false

    // buffer de baja resolución
    private var W = 0
    private var H = 0
    private var scale = 1
    private var lo: Bitmap? = null
    private var loCanvas: Canvas? = null
    private var pix = IntArray(0)
    private var vig = FloatArray(0)
    private val dst = Rect()

    private val fill = Paint().apply { isAntiAlias = false; isDither = false; style = Paint.Style.FILL }
    private val stroke = Paint().apply {
        isAntiAlias = false; isDither = false; style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val bmpPaint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
    private val ui = Paint(Paint.ANTI_ALIAS_FLAG)

    // jugador
    @Volatile private var px = 0f
    @Volatile private var py = 0f
    private var moving = false
    private var walkT = 0f
    private var swimming = false
    private var faceA = 0f               // hacia dónde mira (rad, 0 = este)
    private var atkT = 0f                // >0 mientras dura el golpe
    @Volatile private var actCd = 0f     // enfriamiento de acciones

    // inventario e interacción
    private val inv = Inventory(ctx.getSharedPreferences("pv", Context.MODE_PRIVATE))
    @Volatile private var nearTree: Obj? = null
    @Volatile private var nearStone: Obj? = null
    private val chop = HashMap<Long, Int>()          // golpes recibidos por árbol (no se guarda)
    private val lootRnd = java.util.Random()
    private var shakeObj: Obj? = null
    private var shakeT = 0f
    @Volatile private var toast: String? = null
    @Volatile private var toastT = 0f
    @Volatile private var panelOpen = false
    @Volatile private var panelTab = 0           // 0 = Bolsa, 1 = Crear
    @Volatile private var sel = 0

    // viento y partículas
    private var windT = 0f
    private var windS = 0.5f        // intensidad 0..1
    private var windA = 0f          // ángulo en radianes (0 = hacia el este)
    private val pX = FloatArray(PN)
    private val pY = FloatArray(PN)
    private val pPh = FloatArray(PN)
    private val pSp = FloatArray(PN)
    private var pInit = false
    private val rnd = java.util.Random(7)

    // joystick
    private val density = resources.displayMetrics.density
    private val joyR = 56f * density
    @Volatile private var jx = 0f
    @Volatile private var jy = 0f
    private var joyId = -1
    private var defX = 0f
    private var defY = 0f
    private var joyOx = 0f
    private var joyOy = 0f
    private var joyKx = 0f
    private var joyKy = 0f

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    // ---------- API pública ----------
    fun showMessage(msg: String) { message = msg; canRetry = false }
    fun showError(msg: String) { message = msg + "\n\nToca la pantalla para reintentar"; canRetry = true }
    fun loadWorld(w: World) {
        px = w.startX; py = w.startY
        val old = world
        world = w
        old?.close()
        message = null
    }

    // ---------- ciclo de vida de la superficie ----------
    override fun surfaceCreated(h: SurfaceHolder) {}

    override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) {
        stopLoop()
        scale = max(1, (hh / LOW_H.toFloat()).roundToInt())
        W = ceil(w / scale.toFloat()).toInt()
        H = ceil(hh / scale.toFloat()).toInt()
        lo?.recycle()
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        lo = bmp
        loCanvas = Canvas(bmp)
        pix = IntArray(W * H)
        vig = buildVignette(W, H)
        dst.set(0, 0, W * scale, H * scale)
        defX = joyR * 1.7f; defY = hh - joyR * 1.7f
        joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
        pInit = false
        startLoop()
    }

    override fun surfaceDestroyed(h: SurfaceHolder) { stopLoop() }

    private fun startLoop() {
        running = true
        thread = Thread(this, "game").also { it.start() }
    }

    private fun stopLoop() {
        running = false
        try { thread?.join(500) } catch (e: InterruptedException) { }
        thread = null
    }

    // ---------- bucle principal (~30 FPS) ----------
    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val t0 = System.nanoTime()
            val dt = min(0.1f, (t0 - last) / 1e9f)
            last = t0
            update(dt)
            val sh = holder
            if (sh.surface.isValid) {
                val c = try { sh.lockCanvas() } catch (e: Exception) { null }
                if (c != null) {
                    try { render(c) } finally { sh.unlockCanvasAndPost(c) }
                }
            }
            val spent = (System.nanoTime() - t0) / 1_000_000
            if (spent < 33) try { Thread.sleep(33 - spent) } catch (e: InterruptedException) { }
        }
    }

    private fun stonesLeft(o: Obj): Int {
        val k = Inventory.keyOf(o)
        return Inventory.stonesIn(k) - (inv.stoneTaken[k] ?: 0)
    }

    private fun update(dt: Float) {
        val w = world ?: return
        w.focus(px, py)          // el mundo descarga las zonas vecinas a medida que exploras

        // viento: intensidad y dirección que cambian suavemente
        windT += dt
        windS = (0.5f + 0.32f * sin(windT * 0.7f) + 0.18f * sin(windT * 1.9f + 1.3f)).coerceIn(0.05f, 1f)
        windA = 0.4f * sin(windT * 0.11f)
        val wvx = cos(windA) * WIND_PX * windS
        val wvy = sin(windA) * WIND_PX * windS * 0.5f

        // temporizadores
        if (actCd > 0f) actCd -= dt
        if (atkT > 0f) atkT -= dt
        if (shakeT > 0f) shakeT -= dt
        if (toastT > 0f) { toastT -= dt; if (toastT <= 0f) toast = null }

        // jugador
        val mx = jx; val my = jy
        val mag = if (panelOpen) 0f else hypot(mx, my)
        moving = mag > 0.12f
        swimming = w.inWater(px, py)
        if (moving) {
            faceA = atan2(my, mx)
            // camino: 100 %, campo: 80 %, agua: 50 %
            val sp = SPEED * w.speedFactorAt(px, py) * dt * min(1f, mag)
            val dx = mx / mag * sp
            val dy = my / mag * sp
            if (!w.blocked(px + dx, py)) px += dx
            if (!w.blocked(px, py + dy)) py += dy
            walkT += dt
            // al borde de lo descargado: avisa por qué no se puede seguir
            if (toast == null) w.edgeNote(px + dx * 3f, py + dy * 3f)?.let { showToast(it) }
        }
        nearTree = w.nearest(px, py, REACH) { it.kind == KIND_TREE && !inv.felled.contains(Inventory.keyOf(it)) }
        nearStone = w.nearest(px, py, REACH) { it.kind == KIND_STONE && stonesLeft(it) > 0 }

        // partículas: se envuelven alrededor de la cámara
        if (W > 0) {
            val vx0 = floor(px - W / 2f)
            val vy0 = floor(py - H / 2f)
            if (!pInit) {
                for (i in 0 until PN) {
                    pX[i] = vx0 + rnd.nextFloat() * W
                    pY[i] = vy0 + rnd.nextFloat() * H
                    pPh[i] = rnd.nextFloat() * 6.28f
                    pSp[i] = 0.7f + rnd.nextFloat() * 0.8f
                }
                pInit = true
            }
            val m = 10f
            val spanX = W + 2 * m
            val spanY = H + 2 * m
            for (i in 0 until PN) {
                pX[i] += wvx * pSp[i] * dt
                pY[i] += (wvy * pSp[i] + sin(windT * 2.3f + pPh[i]) * 9f) * dt
                if (pX[i] < vx0 - m) pX[i] += spanX else if (pX[i] > vx0 + W + m) pX[i] -= spanX
                if (pY[i] < vy0 - m) pY[i] += spanY else if (pY[i] > vy0 + H + m) pY[i] -= spanY
            }
        }
    }

    // ---------- acciones del jugador ----------
    private fun showToast(msg: String) { toast = msg; toastT = 2.0f }

    /** Golpe con lo que lleves en la mano. Con hacha, junto a un árbol, lo talas. */
    private fun onAttack() {
        if (actCd > 0f || panelOpen) return
        atkT = ATK_DUR
        actCd = 0.45f
        val t = nearTree ?: return
        shakeObj = t; shakeT = 0.5f
        if (inv.hand != Items.AXE) {
            showToast("Necesitas un hacha para talar")
            return
        }
        val key = Inventory.keyOf(t)
        val hits = (chop[key] ?: 0) + 1
        if (hits >= CHOP_HITS) {
            chop.remove(key)
            inv.felled.add(key)
            val leaves = 1 + lootRnd.nextInt(3)
            inv.counts[Items.LOG] += 2
            inv.counts[Items.LEAF] += leaves
            inv.save()
            showToast("¡Talado!  +2 Troncos  +$leaves Hojas")
        } else {
            chop[key] = hits
        }
    }

    /** Rebuscar palos en el árbol que tienes al lado (1 o 2 por árbol). */
    private fun onSearch() {
        if (actCd > 0f || panelOpen) return
        val t = nearTree ?: return
        actCd = 0.5f
        shakeObj = t; shakeT = 0.5f
        val key = Inventory.keyOf(t)
        val total = Inventory.sticksIn(key)
        val got = inv.taken[key] ?: 0
        if (got < total) {
            inv.taken[key] = got + 1
            inv.counts[Items.STICK]++
            inv.save()
            showToast("+1 Palo")
        } else {
            showToast("Este árbol ya no tiene palos")
        }
    }

    /** Rebuscar piedras en el suelo, junto a las que se ven. */
    private fun onStone() {
        if (actCd > 0f || panelOpen) return
        val s = nearStone ?: return
        actCd = 0.5f
        val key = Inventory.keyOf(s)
        val got = inv.stoneTaken[key] ?: 0
        if (got < Inventory.stonesIn(key)) {
            inv.stoneTaken[key] = got + 1
            inv.counts[Items.STONE]++
            inv.save()
            showToast("+1 Piedra")
        }
    }

    private fun craft(r: Recipe) {
        if (!inv.canCraft(r)) { showToast("Te faltan materiales"); return }
        if (r.id == Recipe.FIRE) {
            val w = world ?: return
            // la fogata se pone delante de ti si se puede, y si no, a tus pies
            var fx = px + cos(faceA) * 10f
            var fy = py + sin(faceA) * 7f
            if (w.blocked(fx, fy) || w.inWater(fx, fy)) { fx = px; fy = py }
            if (w.inWater(fx, fy)) { showToast("No se puede hacer fuego en el agua"); return }
            inv.craft(r)
            inv.addFire(fx, fy)
            showToast("Has encendido una fogata")
        } else {
            inv.craft(r)
            showToast("Has creado: ${r.name}")
        }
        fixSel()
    }

    private fun openPanel() {
        panelOpen = true
        joyId = -1; jx = 0f; jy = 0f
        joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
        fixSel()
    }

    private fun fixSel() {
        val n = inv.slots().size
        if (sel >= n) sel = max(0, n - 1)
    }

    // ---------- render ----------
    private fun render(c: Canvas) {
        val lc = loCanvas ?: return
        val bmp = lo ?: return
        val w = world
        var cx = 0
        var cy = 0
        if (w != null) {
            cx = floor(px - W / 2f).toInt()
            cy = floor(py - H / 2f).toInt()
            drawWorld(lc, w, cx, cy)
        } else {
            lc.drawColor(gray(0.35f))
        }
        post(bmp, cx, cy)
        c.drawColor(BLACK)
        c.drawBitmap(bmp, null, dst, bmpPaint)
        drawUi(c)
    }

    private fun drawWorld(c: Canvas, w: World, cx: Int, cy: Int) {
        c.drawColor(gray(GROUND_LUM))
        val snap = w.snap
        c.save()
        c.translate(-cx.toFloat(), -cy.toFloat())
        val vx0 = cx.toFloat(); val vx1 = (cx + W).toFloat()
        val vy0 = cy.toFloat(); val vy1 = (cy + H).toFloat()

        // terreno
        fill.style = Paint.Style.FILL
        for (a in snap.areas) {
            if (a.maxX < vx0 || a.minX > vx1 || a.maxY < vy0 || a.minY > vy1) continue
            fill.color = gray(K.LUM[a.kind])
            c.drawPath(a.path, fill)
            if (a.kind == K.WATER && !a.clipped) {
                stroke.strokeWidth = 1.5f; stroke.color = gray(0.58f)
                c.drawPath(a.path, stroke)
            }
        }
        // ríos y arroyos
        for (r in snap.waterLines) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width; stroke.color = gray(0.14f)
            c.drawPath(r.path, stroke)
        }
        // caminos: borde oscuro + interior claro
        for (r in snap.roads) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width + 2f; stroke.color = gray(0.42f)
            c.drawPath(r.path, stroke)
        }
        for (r in snap.roads) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width; stroke.color = gray(0.96f)
            c.drawPath(r.path, stroke)
        }

        // hierba natural (a ras de suelo)
        drawGrass(c, w, vx0, vy0, vx1, vy1)

        // si el jugador está dentro de un edificio: vista de interior (sin tejado)
        val inB = w.buildingAt(px, py)
        if (inB != null) drawInterior(c, inB)

        val objs = snap.objs
        val first = snap.firstIndexAtY(vy0 - 6f)
        val maxY = vy1 + MAXH
        val dirX = cos(windA)

        // sombras (semitransparentes, oscurecen lo que hay debajo)
        fill.color = Color.argb(95, 0, 0, 0)
        var i = first
        while (i < objs.size && objs[i].y <= maxY) {
            val o = objs[i]
            val b = o.b
            if (b != null) {
                if (b !== inB && !(b.minX > vx1 || b.maxX + b.h < vx0)) c.drawPath(b.shadow, fill)
            } else if (o.x > vx0 - 30f && o.x < vx1 + 30f) {
                when (o.kind) {
                    KIND_TREE -> if (!inv.felled.contains(Inventory.keyOf(o))) {
                        c.save(); c.translate(o.x, o.y); c.drawPath(Sprites.treeShadow, fill); c.restore()
                    }
                    KIND_BUSH -> {
                        c.save(); c.translate(o.x, o.y); c.drawPath(Sprites.bushShadow, fill); c.restore()
                    }
                }
            }
            i++
        }

        // objetos, fogatas y jugador ordenados por profundidad
        val fires = inv.fires
        var fi = 0
        while (fi < fires.size && fires[fi][1] < vy0 - 6f) fi++
        var playerDone = false
        i = first
        while (i < objs.size && objs[i].y <= maxY) {
            val o = objs[i]
            while (fi < fires.size && fires[fi][1] <= o.y) {
                val f = fires[fi]
                if (!playerDone && py < f[1]) { drawPlayer(c); playerDone = true }
                drawFire(c, f[0], f[1])
                fi++
            }
            if (!playerDone && o.y > py) { drawPlayer(c); playerDone = true }
            val b = o.b
            if (b != null) {
                if (b === inB) drawFront(c, b)
                else if (!(b.maxX < vx0 || b.minX > vx1 || b.maxY < vy0 || b.minY - b.h > vy1)) drawBuilding(c, b)
            } else if (o.x > vx0 - 8f && o.x < vx1 + 8f) {
                val ph = (o.variant and 0xFF) * 0.049f
                when (o.kind) {
                    KIND_TREE -> {
                        c.save()
                        c.translate(o.x, o.y)
                        if (inv.felled.contains(Inventory.keyOf(o))) {
                            fill.color = gray(0.15f); c.drawPath(Sprites.stump, fill)       // tocón
                            fill.color = gray(0.60f); c.drawPath(Sprites.stumpTop, fill)
                        } else {
                            // los árboles se inclinan con el viento (la copa se mueve más que la base)
                            var sway = dirX * windS * 3.2f * (0.75f + 0.25f * sin(windT * 3.1f + ph)) +
                                0.45f * sin(windT * 1.2f + ph)
                            if (o === shakeObj && shakeT > 0f) sway += sin(shakeT * 45f) * shakeT * 10f
                            c.skew(-sway / 19f, 0f)
                            fill.color = gray(0.05f)
                            c.drawPath(if (o.variant % 3 == 0) Sprites.treeSmall else Sprites.treeBig, fill)
                        }
                        c.restore()
                    }
                    KIND_BUSH -> {
                        val sway = dirX * windS * 1.3f * (0.8f + 0.2f * sin(windT * 2.6f + ph)) + 0.3f * sin(windT * 1.1f + ph)
                        c.save()
                        c.translate(o.x, o.y)
                        c.skew(-sway / 9f, 0f)
                        fill.color = gray(0.10f); c.drawPath(Sprites.bush, fill)
                        fill.color = gray(0.32f); c.drawPath(Sprites.bushHi, fill)
                        c.restore()
                    }
                    KIND_STONE -> {
                        val left = stonesLeft(o)
                        if (left > 0) drawStones(c, o.x, o.y, left)
                    }
                }
            }
            i++
        }
        while (fi < fires.size && fires[fi][1] <= vy1 + 40f) {
            val f = fires[fi]
            if (!playerDone && py < f[1]) { drawPlayer(c); playerDone = true }
            drawFire(c, f[0], f[1])
            fi++
        }
        if (!playerDone) drawPlayer(c)
        if (inB == null) drawWind(c)
        c.restore()
    }

    /** Matas de hierba repartidas por el suelo libre, en parches, que se mecen con el viento. */
    private fun drawGrass(c: Canvas, w: World, vx0: Float, vy0: Float, vx1: Float, vy1: Float) {
        val cs = 9
        val gx0 = floor(vx0 / cs).toInt() - 1
        val gx1 = floor(vx1 / cs).toInt() + 1
        val gy0 = floor(vy0 / cs).toInt() - 1
        val gy1 = floor(vy1 / cs).toInt() + 1
        val lean = cos(windA) * windS * 1.6f
        for (gy in gy0..gy1) for (gx in gx0..gx1) {
            val h = hash2(gx, gy)
            val patch = hash2(Math.floorDiv(gx, 5), Math.floorDiv(gy, 5)) and 0xFF
            if ((h and 0xFF) >= 20 + patch / 3) continue
            val x = floor((gx + ((h ushr 8) and 0xFF) / 255f) * cs)
            val y = floor((gy + ((h ushr 16) and 0xFF) / 255f) * cs)
            if (!w.groundFree(x, y)) continue
            val sw = lean + sin(windT * 2.5f + (h and 0xFF) * 0.05f) * 0.5f
            fill.color = if (((h ushr 4) and 3) == 0) gray(0.92f) else gray(0.20f)
            val tall = 2f + ((h ushr 24) and 1)
            c.drawRect(x, y - 2f, x + 1f, y, fill)                          // base
            c.drawRect(x + sw, y - 2f - tall, x + sw + 1f, y - 2f, fill)    // punta
            c.drawRect(x + 2f, y - 1f, x + 3f, y, fill)
            c.drawRect(x + 2f + sw * 0.7f, y - 1f - tall, x + 3f + sw * 0.7f, y - 1f, fill)
        }
    }

    private fun drawStones(c: Canvas, x: Float, y: Float, n: Int) {
        fill.color = Color.argb(90, 0, 0, 0)
        c.drawRect(x - 3f, y, x + 6f, y + 1f, fill)
        fill.color = gray(0.42f); c.drawRect(x - 3f, y - 3f, x + 2f, y, fill)
        fill.color = gray(0.88f); c.drawRect(x - 2f, y - 3f, x, y - 2f, fill)
        if (n >= 2) {
            fill.color = gray(0.36f); c.drawRect(x + 2f, y - 2f, x + 6f, y + 1f, fill)
            fill.color = gray(0.85f); c.drawRect(x + 3f, y - 2f, x + 4f, y - 1f, fill)
        }
    }

    private fun drawFire(c: Canvas, fx: Float, fy: Float) {
        // resplandor
        fill.color = Color.argb(60, 255, 255, 255)
        c.drawOval(RectF(fx - 18f, fy - 10f, fx + 18f, fy + 8f), fill)
        // troncos cruzados
        stroke.strokeWidth = 2f; stroke.color = gray(0.10f)
        c.drawLine(fx - 5f, fy, fx + 5f, fy - 2f, stroke)
        c.drawLine(fx - 5f, fy - 2f, fx + 5f, fy, stroke)
        // llamas que parpadean y se doblan con el viento
        val t = windT * 11f + fx
        val h1 = 6f + 2f * sin(t)
        val h2 = 4f + 2f * sin(t * 1.7f + 1f)
        val h3 = 5f + 2f * sin(t * 1.3f + 2f)
        val lean = cos(windA) * windS * 1.5f
        fill.color = gray(0.80f)
        c.drawRect(fx - 2f + lean, fy - 2f - h1, fx + 2f + lean, fy - 1f, fill)
        c.drawRect(fx - 4f, fy - 2f - h2, fx - 2f, fy - 1f, fill)
        c.drawRect(fx + 2f, fy - 2f - h3, fx + 4f, fy - 1f, fill)
        fill.color = gray(1f)
        c.drawRect(fx - 1f + lean * 0.5f, fy - 1f - h1 * 0.55f, fx + 1f + lean * 0.5f, fy - 1f, fill)
        // humo
        for (k in 0..2) {
            val ph = (windT * 0.7f + k * 0.33f) % 1f
            val sx = fx + lean * ph * 6f + sin(ph * 6f + k) * 1.5f
            val sy = fy - 8f - ph * 16f
            fill.color = gray(0.85f - ph * 0.4f)
            c.drawRect(sx, sy, sx + 1.5f, sy + 1.5f, fill)
        }
    }

    private fun drawInterior(c: Canvas, b: Building) {
        fill.color = gray(0.70f); c.drawPath(b.roof, fill)          // suelo
        fill.color = gray(0.16f); c.drawPath(b.wallBack, fill)      // paredes del fondo
        stroke.strokeWidth = 2f; stroke.color = gray(0.05f)
        c.drawPath(b.roof, stroke)                                   // base de las paredes
    }

    private fun drawFront(c: Canvas, b: Building) {
        fill.color = gray(0.12f); c.drawPath(b.wallFront, fill)     // pared baja delantera con hueco de puerta
    }

    private fun drawWind(c: Canvas) {
        val len = 1 + (windS * 3f).toInt()
        for (i in 0 until PN) {
            val x = floor(pX[i])
            val y = floor(pY[i])
            if (i % 5 == 0) {                       // hojas / ceniza
                fill.color = gray(0.04f)
                c.drawRect(x, y, x + 2f, y + 2f, fill)
            } else {                                 // nieve y polvo
                fill.color = if (i % 2 == 0) gray(1f) else gray(0.04f)
                c.drawRect(x, y, x + len, y + 1f, fill)
            }
        }
    }

    private fun drawBuilding(c: Canvas, b: Building) {
        fill.color = gray(0.10f); c.drawPath(b.wallA, fill)
        fill.color = gray(0.26f); c.drawPath(b.wallB, fill)
        fill.color = gray(1f); c.drawPath(b.windows, fill)
        if (b.enterable) { fill.color = gray(0.95f); c.drawPath(b.door, fill) }
        c.save()
        c.translate(0f, -b.h)
        fill.color = gray(0.86f); c.drawPath(b.roof, fill)
        stroke.strokeWidth = 1f; stroke.color = gray(0.15f); c.drawPath(b.roof, stroke)
        c.restore()
    }

    private fun drawPlayer(c: Canvas) {
        val x = px.toInt().toFloat()
        val y = py.toInt().toFloat()
        if (swimming) {
            // hundido hasta la mitad: solo se ve la parte de arriba + ondas en el agua
            c.save()
            c.clipRect(x - 10f, y - 16f, x + 12f, y - 4f)
            drawBody(c, x, y + 2f)
            c.restore()
            val k = ((walkT * 5f).toInt() and 1).toFloat()
            fill.color = gray(0.95f)
            c.drawRect(x - 4f - k, y - 4f, x + 4f + k, y - 3f, fill)
            fill.color = gray(0.75f)
            c.drawRect(x - 6f + k, y - 2f, x + 6f - k, y - 1f, fill)
        } else {
            fill.color = Color.argb(110, 0, 0, 0)
            c.drawRect(x - 2f, y - 1f, x + 6f, y + 1f, fill)      // sombra
            drawBody(c, x, y)
        }
    }

    private fun drawBody(c: Canvas, x: Float, y: Float) {
        fill.color = gray(0.03f)
        c.drawRect(x - 1f, y - 10f, x + 1f, y - 7f, fill)         // cabeza
        c.drawRect(x - 2f, y - 7f, x + 2f, y - 3f, fill)          // cuerpo
        val step = moving && ((walkT * 8f).toInt() and 1) == 0
        val l = if (step) y - 1f else y
        val r = if (step || !moving) y else y - 1f
        c.drawRect(x - 2f, y - 3f, x - 0.5f, l, fill)             // piernas
        c.drawRect(x + 0.5f, y - 3f, x + 2f, r, fill)

        val hx = x + 2f
        val hy = y - 5f
        val held = inv.hand
        if (atkT > 0f) {
            // golpe: el brazo (y la herramienta, si la llevas) barre un arco hacia donde miras
            val p = 1f - atkT / ATK_DUR
            val a = faceA - 1.0f + 2.0f * p
            fill.color = gray(1f)
            for (k in 0..3) {
                val aa = a - k * 0.3f
                val sx = x + cos(aa) * 10f
                val sy = y - 5f + sin(aa) * 10f
                c.drawRect(sx, sy, sx + 2f, sy + 2f, fill)
            }
            if (held == Items.STICK || held == Items.AXE) drawTool(c, hx, hy, a, held)
        } else if (held == Items.STICK || held == Items.AXE) {
            drawTool(c, hx, hy, -1.1f, held)                      // en reposo, apuntando arriba
        }
    }

    private fun drawTool(c: Canvas, x: Float, y: Float, a: Float, id: Int) {
        stroke.strokeWidth = 1.5f
        stroke.color = gray(0.38f)
        val ex = x + cos(a) * 8f
        val ey = y + sin(a) * 8f
        c.drawLine(x, y, ex, ey, stroke)
        if (id == Items.AXE) {                                    // cabeza de piedra del hacha
            fill.color = gray(0.80f)
            c.drawRect(ex - 1.5f, ey - 1.5f, ex + 1.5f, ey + 1.5f, fill)
        }
    }

    /** Posproceso: viñeta + ruido + dithering Bayer a la paleta de 4 tonos + esquinas redondeadas. */
    private fun post(bmp: Bitmap, camX: Int, camY: Int) {
        bmp.getPixels(pix, 0, W, 0, 0, W, H)
        var i = 0
        for (y in 0 until H) {
            val wy = y + camY
            val row = (wy and 3) shl 2
            for (x in 0 until W) {
                val v = vig[i]
                if (v < 0f) {
                    pix[i] = BLACK
                } else {
                    val wx = x + camX     // el patrón se ancla al mundo: no "nada" al caminar
                    val n = (((wx * 73856093) xor (wy * 19349663)) ushr 9) and 15
                    var l = (pix[i] and 0xFF) * (1f / 255f) * v + (n - 7.5f) * 0.0075f
                    if (l < 0f) l = 0f else if (l > 1f) l = 1f
                    val t = l * 3f
                    var idx = t.toInt()
                    if (t - idx > BAYER[row + (wx and 3)]) idx++
                    pix[i] = PAL[if (idx > 3) 3 else idx]
                }
                i++
            }
        }
        bmp.setPixels(pix, 0, W, 0, 0, W, H)
    }

    private fun buildVignette(w: Int, h: Int): FloatArray {
        val a = FloatArray(w * h)
        val r = min(w, h) * 0.08f
        for (y in 0 until h) for (x in 0 until w) {
            val nx = (x + 0.5f - w / 2f) / (w / 2f)
            val ny = (y + 0.5f - h / 2f) / (h / 2f)
            var v = 1f - 0.30f * (nx * nx + ny * ny)
            if (v < 0.25f) v = 0.25f
            val cx = if (x < r) r else if (x > w - r) w - r else x.toFloat()
            val cy = if (y < r) r else if (y > h - r) h - r else y.toFloat()
            if (cx != x.toFloat() || cy != y.toFloat()) {
                val dx = x - cx; val dy = y - cy
                if (dx * dx + dy * dy > r * r) v = -1f
            }
            a[y * w + x] = v
        }
        return a
    }

    // ---------- interfaz (a resolución completa) ----------
    private fun atkCx() = width - 84f * density
    private fun atkCy() = height - 84f * density
    private fun atkR() = 42f * density
    private fun srcCx() = width - 180f * density
    private fun srcCy() = height - 64f * density
    private fun srcR() = 32f * density
    private fun stoneCx() = width - 84f * density
    private fun stoneCy() = height - 168f * density
    private fun bagRect() = RectF(width - 80f * density, 12f * density, width - 12f * density, 56f * density)

    private fun panelRect(): RectF {
        val pw = min(width - 24f * density, 420f * density)
        val ph = min(height - 24f * density, 270f * density)
        val l = (width - pw) / 2f
        val t = (height - ph) / 2f
        return RectF(l, t, l + pw, t + ph)
    }

    private fun tabRect(r: RectF, k: Int): RectF {
        val l = r.left + 16f * density + k * 104f * density
        val t = r.top + 10f * density
        return RectF(l, t, l + 96f * density, t + 32f * density)
    }

    private fun slotRect(r: RectF, i: Int): RectF {
        val s = 52f * density
        val g = 8f * density
        val l = r.left + 16f * density + (i % 4) * (s + g)
        val t = r.top + 54f * density + (i / 4) * (s + g)
        return RectF(l, t, l + s, t + s)
    }

    private fun btnRect(r: RectF, k: Int): RectF {
        val x0 = r.left + 268f * density
        val t = r.top + 92f * density + k * 46f * density
        return RectF(x0, t, max(x0 + 60f * density, r.right - 16f * density), t + 40f * density)
    }

    private fun rowRect(r: RectF, k: Int): RectF {
        val t = r.top + 54f * density + k * 60f * density
        return RectF(r.left + 16f * density, t, r.right - 16f * density, t + 52f * density)
    }

    private fun label(c: Canvas, text: String, cx: Float, cy: Float, size: Float, color: Int) {
        ui.style = Paint.Style.FILL
        ui.typeface = Typeface.MONOSPACE
        ui.textAlign = Paint.Align.CENTER
        ui.textSize = size
        ui.color = color
        c.drawText(text, cx, cy + size * 0.35f, ui)
    }

    private fun roundButton(c: Canvas, cx: Float, cy: Float, r: Float, text: String, active: Boolean) {
        ui.style = Paint.Style.FILL; ui.color = Color.argb(if (active) 80 else 46, 234, 233, 219)
        c.drawCircle(cx, cy, r, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 3f * density
        ui.color = Color.argb(if (active) 200 else 130, 234, 233, 219)
        c.drawCircle(cx, cy, r, ui)
        label(c, text, cx, cy, 12f * density, CREAM)
    }

    private fun boxButton(c: Canvas, r: RectF, text: String, enabled: Boolean, selected: Boolean = false) {
        ui.style = Paint.Style.FILL
        ui.color = if (selected) Color.argb(110, 234, 233, 219) else if (enabled) Color.argb(60, 234, 233, 219) else Color.argb(20, 234, 233, 219)
        c.drawRoundRect(r, 6f * density, 6f * density, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density
        ui.color = if (enabled) CREAM else MIDGRAY
        c.drawRoundRect(r, 6f * density, 6f * density, ui)
        label(c, text, r.centerX(), r.centerY(), 13f * density, if (enabled) CREAM else MIDGRAY)
    }

    private fun drawItemIcon(c: Canvas, id: Int, s: RectF) {
        val cx = s.centerX()
        val cy = s.centerY()
        val d = density
        ui.strokeCap = Paint.Cap.ROUND
        when (id) {
            Items.STICK -> {
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 4f * d; ui.color = LIGHTGRAY
                c.drawLine(cx - 14f * d, cy + 14f * d, cx + 14f * d, cy - 14f * d, ui)
            }
            Items.STONE -> {
                ui.style = Paint.Style.FILL; ui.color = 0xFF8A8087.toInt()
                c.drawOval(RectF(cx - 13f * d, cy - 9f * d, cx + 13f * d, cy + 9f * d), ui)
                ui.color = CREAM
                c.drawOval(RectF(cx - 8f * d, cy - 6f * d, cx - 2f * d, cy - 3f * d), ui)
            }
            Items.LOG -> {
                val rr = RectF(cx - 15f * d, cy - 8f * d, cx + 15f * d, cy + 8f * d)
                ui.style = Paint.Style.FILL; ui.color = MIDGRAY
                c.drawRoundRect(rr, 4f * d, 4f * d, ui)
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 1.5f * d; ui.color = CREAM
                c.drawRoundRect(rr, 4f * d, 4f * d, ui)
                c.drawCircle(cx + 9f * d, cy, 4f * d, ui)
            }
            Items.LEAF -> {
                ui.style = Paint.Style.FILL; ui.color = LIGHTGRAY
                c.drawOval(RectF(cx - 12f * d, cy - 7f * d, cx + 12f * d, cy + 7f * d), ui)
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 1.5f * d; ui.color = 0xFF2A2428.toInt()
                c.drawLine(cx - 10f * d, cy + 5f * d, cx + 10f * d, cy - 5f * d, ui)
            }
            Items.AXE -> {
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 4f * d; ui.color = LIGHTGRAY
                c.drawLine(cx - 12f * d, cy + 13f * d, cx + 8f * d, cy - 9f * d, ui)
                ui.style = Paint.Style.FILL; ui.color = 0xFF8A8087.toInt()
                c.drawRect(cx + 2f * d, cy - 16f * d, cx + 15f * d, cy - 4f * d, ui)
            }
        }
        ui.strokeCap = Paint.Cap.BUTT
    }

    private fun drawUi(c: Canvas) {
        // joystick
        ui.style = Paint.Style.FILL; ui.color = Color.argb(46, 234, 233, 219)
        c.drawCircle(joyOx, joyOy, joyR, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 3f * density; ui.color = Color.argb(150, 234, 233, 219)
        c.drawCircle(joyOx, joyOy, joyR, ui)
        ui.style = Paint.Style.FILL; ui.color = Color.argb(170, 234, 233, 219)
        c.drawCircle(joyKx, joyKy, joyR * 0.42f, ui)

        val st = world?.status
        if (st != null) {
            // estado de la descarga del mapa (arriba a la izquierda)
            ui.textSize = 12f * density
            ui.typeface = Typeface.MONOSPACE
            ui.textAlign = Paint.Align.LEFT
            val tw = ui.measureText(st)
            ui.style = Paint.Style.FILL; ui.color = Color.argb(200, 42, 36, 40)
            c.drawRoundRect(RectF(12f * density, 12f * density, 12f * density + tw + 16f * density, 40f * density), 8f * density, 8f * density, ui)
            ui.color = CREAM
            c.drawText(st, 20f * density, 31f * density, ui)
        }

        if (world != null) {
            // botones de acción
            roundButton(c, atkCx(), atkCy(), atkR(), "Atacar", atkT > 0f)
            if (nearTree != null) roundButton(c, srcCx(), srcCy(), srcR(), "Buscar", false)
            if (nearStone != null) roundButton(c, stoneCx(), stoneCy(), srcR(), "Piedras", false)
            boxButton(c, bagRect(), "Bolsa", true)
            if (panelOpen) drawPanel(c)

            // aviso breve (arriba, por encima del panel)
            val t = toast
            if (t != null) {
                ui.textSize = 14f * density
                ui.typeface = Typeface.MONOSPACE
                val tw = ui.measureText(t)
                val cx = width / 2f
                val cy = 30f * density
                ui.style = Paint.Style.FILL; ui.color = Color.argb(225, 42, 36, 40)
                c.drawRoundRect(RectF(cx - tw / 2f - 14f * density, cy - 16f * density, cx + tw / 2f + 14f * density, cy + 16f * density), 8f * density, 8f * density, ui)
                label(c, t, cx, cy, 14f * density, CREAM)
            }
        }

        // mensajes (carga / error)
        val msg = message ?: return
        ui.style = Paint.Style.FILL
        ui.typeface = Typeface.MONOSPACE
        ui.textAlign = Paint.Align.CENTER
        ui.textSize = 15f * density
        ui.color = CREAM
        var y = height / 2f - (msg.count { it == '\n' }) * ui.textSize * 0.6f
        for (line in msg.split("\n")) {
            c.drawText(line, width / 2f, y, ui)
            y += ui.textSize * 1.3f
        }
    }

    private fun drawPanel(c: Canvas) {
        val r = panelRect()
        ui.style = Paint.Style.FILL; ui.color = Color.argb(245, 42, 36, 40)
        c.drawRoundRect(r, 10f * density, 10f * density, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density; ui.color = CREAM
        c.drawRoundRect(r, 10f * density, 10f * density, ui)

        boxButton(c, tabRect(r, 0), "Bolsa", true, panelTab == 0)
        boxButton(c, tabRect(r, 1), "Crear", true, panelTab == 1)

        if (panelTab == 0) drawBagTab(c, r) else drawCraftTab(c, r)
    }

    private fun drawBagTab(c: Canvas, r: RectF) {
        val slots = inv.slots()
        for (i in 0 until 12) {
            val s = slotRect(r, i)
            val isSel = i == sel && i < slots.size
            ui.style = Paint.Style.FILL; ui.color = Color.argb(30, 234, 233, 219)
            c.drawRoundRect(s, 4f * density, 4f * density, ui)
            ui.style = Paint.Style.STROKE
            ui.strokeWidth = (if (isSel) 3f else 1.5f) * density
            ui.color = if (isSel) CREAM else MIDGRAY
            c.drawRoundRect(s, 4f * density, 4f * density, ui)
            if (i < slots.size) {
                val id = slots[i]
                drawItemIcon(c, id, s)
                ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.RIGHT; ui.typeface = Typeface.MONOSPACE
                ui.textSize = 12f * density; ui.color = CREAM
                c.drawText("x${inv.counts[id]}", s.right - 4f * density, s.bottom - 4f * density, ui)
            }
        }

        val x0 = r.left + 268f * density
        ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.LEFT; ui.typeface = Typeface.MONOSPACE
        ui.textSize = 13f * density; ui.color = CREAM
        val handName = if (inv.hand >= 0) Items.NAMES[inv.hand] else "vacía"
        c.drawText("Mano: $handName", x0, r.top + 76f * density, ui)

        val canEquip = sel < slots.size && Items.equippable(slots[sel])
        boxButton(c, btnRect(r, 0), "Equipar", canEquip)
        boxButton(c, btnRect(r, 1), "Guardar", inv.hand >= 0)
        boxButton(c, btnRect(r, 2), "Cerrar", true)
        if (slots.isEmpty()) {
            ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.LEFT; ui.textSize = 12f * density
            ui.color = LIGHTGRAY
            c.drawText("Vacío. Rebusca en árboles y suelo.", r.left + 16f * density, r.bottom - 12f * density, ui)
        }
    }

    private fun drawCraftTab(c: Canvas, r: RectF) {
        for ((k, rec) in Inventory.RECIPES.withIndex()) {
            val row = rowRect(r, k)
            val ok = inv.canCraft(rec)
            ui.style = Paint.Style.FILL
            ui.color = if (ok) Color.argb(55, 234, 233, 219) else Color.argb(18, 234, 233, 219)
            c.drawRoundRect(row, 6f * density, 6f * density, ui)
            ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density
            ui.color = if (ok) CREAM else MIDGRAY
            c.drawRoundRect(row, 6f * density, 6f * density, ui)
            ui.style = Paint.Style.FILL; ui.typeface = Typeface.MONOSPACE; ui.textAlign = Paint.Align.LEFT
            ui.color = if (ok) CREAM else MIDGRAY
            ui.textSize = 15f * density
            c.drawText(rec.name, row.left + 12f * density, row.top + 22f * density, ui)
            ui.textSize = 11f * density
            c.drawText(rec.desc, row.left + 12f * density, row.top + 41f * density, ui)
            ui.textAlign = Paint.Align.RIGHT; ui.textSize = 13f * density
            c.drawText(if (ok) "Crear" else "Faltan", row.right - 12f * density, row.centerY() + 5f * density, ui)
        }
    }

    private fun handlePanelTouch(x: Float, y: Float) {
        val r = panelRect()
        if (bagRect().contains(x, y) || !r.contains(x, y)) { panelOpen = false; return }
        for (k in 0..1) {
            if (tabRect(r, k).contains(x, y)) { panelTab = k; return }
        }
        if (panelTab == 0) {
            val slots = inv.slots()
            for (i in 0 until 12) {
                if (slotRect(r, i).contains(x, y)) { if (i < slots.size) sel = i; return }
            }
            if (btnRect(r, 0).contains(x, y)) {
                if (sel < slots.size) { inv.equip(slots[sel]); fixSel() }
                return
            }
            if (btnRect(r, 1).contains(x, y)) { inv.unequip(); return }
            if (btnRect(r, 2).contains(x, y)) { panelOpen = false }
        } else {
            for ((k, rec) in Inventory.RECIPES.withIndex()) {
                if (rowRect(r, k).contains(x, y)) { craft(rec); return }
            }
        }
    }

    // ---------- entrada táctil ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (canRetry && message != null) {
                    canRetry = false; message = "Cargando…"; onRetry?.invoke()
                    return true
                }
                val idx = e.actionIndex
                val x = e.getX(idx); val y = e.getY(idx)
                if (world != null) {
                    if (panelOpen) { handlePanelTouch(x, y); return true }
                    if (bagRect().contains(x, y)) { openPanel(); return true }
                    if (hypot(x - atkCx(), y - atkCy()) <= atkR() * 1.15f) { onAttack(); return true }
                    if (nearTree != null && hypot(x - srcCx(), y - srcCy()) <= srcR() * 1.2f) { onSearch(); return true }
                    if (nearStone != null && hypot(x - stoneCx(), y - stoneCy()) <= srcR() * 1.2f) { onStone(); return true }
                }
                if (joyId == -1 && x < width * 0.5f && !panelOpen) {
                    joyId = e.getPointerId(idx)
                    joyOx = x; joyOy = y; joyKx = x; joyKy = y
                    jx = 0f; jy = 0f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (joyId != -1) {
                    val i = e.findPointerIndex(joyId)
                    if (i >= 0) {
                        var dx = e.getX(i) - joyOx
                        var dy = e.getY(i) - joyOy
                        val d = hypot(dx, dy)
                        if (d > joyR) { dx = dx / d * joyR; dy = dy / d * joyR }
                        joyKx = joyOx + dx; joyKy = joyOy + dy
                        jx = dx / joyR; jy = dy / joyR
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (e.actionMasked == MotionEvent.ACTION_CANCEL || id == joyId) {
                    joyId = -1; jx = 0f; jy = 0f
                    joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
                }
            }
        }
        return true
    }
}
