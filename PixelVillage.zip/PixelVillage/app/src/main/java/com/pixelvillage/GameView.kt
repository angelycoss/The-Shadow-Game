package com.pixelvillage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Path
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

private const val LOW_H = 180            // altura lógica del "pixel art"
private const val SPEED = 12f * PPM      // 12 m/s en px/s (sobre camino)
private const val MAXH = 64f             // altura máxima de un objeto (para el culling)
private const val GROUND_LUM = 0.62f
private const val WIND_PX = 75f          // velocidad base del viento (px/s)
private const val PN = 70                // partículas de viento
private const val ATK_DUR = 0.28f        // duración del golpe (s)
private const val REACH = 14f            // alcance para interactuar (px)
private const val CHOP_HITS = 4          // golpes de hacha para talar un árbol
private const val ROOM_TOP = 26f       // alto de la pared del fondo en los interiores
private const val JUMP_DUR = 0.55f       // duración del salto (s)
private const val SWIM_LIMIT = 180f      // segundos seguidos en el agua antes de ahogarte (3 min)
private const val ROW = 5f               // separación entre surcos de cultivo (px)
private const val PLANT = 3f             // separación entre matas de trigo (px)
private const val TN = 16                // puntos del rastro del jugador (el trigo se dobla al pasar)
private val BLACK = 0xFF000000.toInt()
private val CREAM = Color.rgb(234, 233, 219)
private val MIDGRAY = 0xFF6F656B.toInt()
private val LIGHTGRAY = 0xFFB4AEB2.toInt()

// Paleta de 4 tonos: gris-morado oscuro -> crema
private val PAL = intArrayOf(
    0xFF2A2428.toInt(), 0xFF6F656B.toInt(), 0xFFB4AEB2.toInt(), 0xFFEAE9DB.toInt()
)
// Matriz Bayer 4x4 (umbrales para el dithering ordenado)
private val BAYER = FloatArray(16).also {
    val m = intArrayOf(0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5)
    for (i in 0 until 16) it[i] = (m[i] + 0.5f) / 16f
}

private fun gray(l: Float): Int {
    val v = (l.coerceIn(0f, 1f) * 255f).toInt()
    return Color.rgb(v, v, v)
}

private fun hash2(a: Int, b: Int): Int {
    var h = a * 374761393 + b * 668265263 + 1013904223
    h = (h xor (h ushr 13)) * 1274126177
    return h xor (h ushr 16)
}

class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {

    @Volatile var world: World? = null
    @Volatile var message: String? = "Cargando…"
    @Volatile private var canRetry = false
    var onRetry: (() -> Unit)? = null

    private var thread: Thread? = null
    @Volatile private var running = false

    // buffer de baja resolución
    private var W = 0
    private var H = 0
    private var scale = 1
    private var lo: Bitmap? = null
    private var loCanvas: Canvas? = null
    private var pix = IntArray(0)
    private var vig = FloatArray(0)
    private val verText: String = try { "v" + ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "" }
    private val dst = Rect()

    private val fill = Paint().apply { isAntiAlias = false; isDither = false; style = Paint.Style.FILL }
    private val stroke = Paint().apply {
        isAntiAlias = false; isDither = false; style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val bmpPaint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
    private val ui = Paint(Paint.ANTI_ALIAS_FLAG)

    // jugador
    @Volatile private var px = 0f
    @Volatile private var py = 0f
    private var moving = false
    private var walkT = 0f
    private var swimming = false
    private var faceA = 0f               // hacia dónde mira (rad, 0 = este)
    private var atkT = 0f                // >0 mientras dura el golpe
    @Volatile private var actCd = 0f     // enfriamiento de acciones
    @Volatile private var jumpT = 0f     // >0 mientras dura el salto
    private var jumpDx = 0f
    private var jumpDy = 0f
    @Volatile private var nearFence = false
    private var mud = false              // piernas hundidas en el fango
    // interior de una casa (espacio propio, mucho más grande que el edificio visto desde fuera)
    private var room: Building? = null
    private var rW = 0f; private var rH = 0f      // tamaño de la sala
    private var rx = 0f; private var ry = 0f      // posición del jugador dentro de la sala
    private var retX = 0f; private var retY = 0f  // dónde reaparece fuera al salir
    private var swimT = 0f               // segundos seguidos en el agua
    private var swimWarn = 0
    @Volatile private var deadT = 0f     // >0 mientras se muestra "te ahogaste"
    private var gameT = 0f
    // rastro del jugador: el trigo se dobla donde has pasado hace poco
    private val trailX = FloatArray(TN)
    private val trailY = FloatArray(TN)
    private val trailTm = FloatArray(TN) { -100f }
    private var trailI = 0
    private var trailAcc = 0f
    private var tbx0 = 1e9f; private var tby0 = 1e9f; private var tbx1 = -1e9f; private var tby1 = -1e9f
    private var bendLean = 0f
    private var bendSq = 0f
    private val spire = Path()
    private val tie = Paint().apply {
        isAntiAlias = false; style = Paint.Style.STROKE; strokeWidth = 6f
        pathEffect = DashPathEffect(floatArrayOf(1.3f, 3.2f), 0f)
    }

    // inventario e interacción
    private val inv = Inventory(ctx.getSharedPreferences("pv", Context.MODE_PRIVATE))
    @Volatile private var nearTree: Obj? = null
    @Volatile private var nearStone: Obj? = null
    private val chop = HashMap<Long, Int>()          // golpes recibidos por árbol (no se guarda)
    private val lootRnd = java.util.Random()
    private var shakeObj: Obj? = null
    private var shakeT = 0f
    @Volatile private var toast: String? = null
    @Volatile private var toastT = 0f
    @Volatile private var panelOpen = false
    @Volatile private var mapOpen = false             // pantalla del mapa del mundo
    private val worldMap = WorldMap(ctx)
    @Volatile private var panelTab = 0           // 0 = Bolsa, 1 = Crear
    @Volatile private var sel = 0

    // viento y partículas
    private var windT = 0f
    private var windS = 0.5f        // intensidad 0..1
    private var windA = 0f          // ángulo en radianes (0 = hacia el este)
    private val pX = FloatArray(PN)
    private val pY = FloatArray(PN)
    private val pPh = FloatArray(PN)
    private val pSp = FloatArray(PN)
    private var pInit = false
    private val rnd = java.util.Random(7)

    // joystick
    private val density = resources.displayMetrics.density
    private val joyR = 56f * density
    @Volatile private var jx = 0f
    @Volatile private var jy = 0f
    private var joyId = -1
    private var defX = 0f
    private var defY = 0f
    private var joyOx = 0f
    private var joyOy = 0f
    private var joyKx = 0f
    private var joyKy = 0f

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    // ---------- API pública ----------
    fun showMessage(msg: String) { message = msg; canRetry = false }
    fun showError(msg: String) { message = msg + "\n\nToca la pantalla para reintentar"; canRetry = true }
    fun loadWorld(w: World) {
        px = w.startX; py = w.startY
        val old = world
        world = w
        old?.close()
        message = null
    }

    // ---------- ciclo de vida de la superficie ----------
    override fun surfaceCreated(h: SurfaceHolder) {}

    override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) {
        stopLoop()
        scale = max(1, (hh / LOW_H.toFloat()).roundToInt())
        W = ceil(w / scale.toFloat()).toInt()
        H = ceil(hh / scale.toFloat()).toInt()
        lo?.recycle()
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        lo = bmp
        loCanvas = Canvas(bmp)
        pix = IntArray(W * H)
        vig = buildVignette(W, H)
        dst.set(0, 0, W * scale, H * scale)
        defX = joyR * 1.7f; defY = hh - joyR * 1.7f
        joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
        pInit = false
        startLoop()
    }

    override fun surfaceDestroyed(h: SurfaceHolder) { stopLoop() }

    private fun startLoop() {
        running = true
        thread = Thread(this, "game").also { it.start() }
    }

    private fun stopLoop() {
        running = false
        try { thread?.join(500) } catch (e: InterruptedException) { }
        thread = null
    }

    // ---------- bucle principal (~30 FPS) ----------
    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val t0 = System.nanoTime()
            val dt = min(0.1f, (t0 - last) / 1e9f)
            last = t0
            update(dt)
            val sh = holder
            if (sh.surface.isValid) {
                val c = try { sh.lockCanvas() } catch (e: Exception) { null }
                if (c != null) {
                    try { render(c) } finally { sh.unlockCanvasAndPost(c) }
                }
            }
            val spent = (System.nanoTime() - t0) / 1_000_000
            if (spent < 33) try { Thread.sleep(33 - spent) } catch (e: InterruptedException) { }
        }
    }

    private fun stonesLeft(o: Obj): Int {
        val k = Inventory.keyOf(o)
        return Inventory.stonesIn(k) - (inv.stoneTaken[k] ?: 0)
    }

    private fun update(dt: Float) {
        val w = world ?: return
        if (mapOpen) return          // el juego se pausa mientras miras el mapa
        w.focus(px, py)          // el mundo descarga las zonas vecinas a medida que exploras

        // viento: intensidad y dirección que cambian suavemente
        windT += dt
        windS = (0.5f + 0.32f * sin(windT * 0.7f) + 0.18f * sin(windT * 1.9f + 1.3f)).coerceIn(0.05f, 1f)
        windA = 0.4f * sin(windT * 0.11f)
        val wvx = cos(windA) * WIND_PX * windS
        val wvy = sin(windA) * WIND_PX * windS * 0.5f

        // temporizadores
        if (actCd > 0f) actCd -= dt
        if (atkT > 0f) atkT -= dt
        if (shakeT > 0f) shakeT -= dt
        if (toastT > 0f) { toastT -= dt; if (toastT <= 0f) toast = null }
        gameT += dt
        if (jumpT > 0f) jumpT -= dt

        // te ahogaste: pausa breve y reapareces en el punto de inicio
        if (deadT > 0f) {
            deadT -= dt
            if (deadT <= 0f) { px = w.startX; py = w.startY; swimT = 0f; swimWarn = 0; jumpT = 0f }
            return
        }

        if (room != null) { updateRoom(dt); return }

        // jugador
        val mx = jx; val my = jy
        val mag = if (panelOpen) 0f else hypot(mx, my)
        moving = mag > 0.12f
        swimming = w.inWater(px, py)
        mud = !swimming && w.inMud(px, py)
        nearFence = w.nearFence(px, py, 10f)
        if (jumpT > 0f) {
            // salto: avanzas en la dirección en que saltaste, por encima de las cercas
            val sp = SPEED * dt
            val sx = jumpDx * sp; val sy = jumpDy * sp
            if (!w.blockedMove(px, py, px + sx, py, true)) px += sx
            if (!w.blockedMove(px, py, px, py + sy, true)) py += sy
            walkT += dt
        } else if (moving) {
            faceA = atan2(my, mx)
            // camino: 100 %, campo: 80 %, agua: 50 %, fango: 20 %
            val sp = SPEED * w.speedFactorAt(px, py) * dt * min(1f, mag)
            val dx = mx / mag * sp
            val dy = my / mag * sp
            if (!w.blockedMove(px, py, px + dx, py, false)) px += dx
            if (!w.blockedMove(px, py, px, py + dy, false)) py += dy
            walkT += dt
            // al borde de lo descargado: avisa por qué no se puede seguir
            if (toast == null) w.edgeNote(px + dx * 3f, py + dy * 3f)?.let { showToast(it) }
        }
        // nadar cansa: a los 3 minutos seguidos en el agua te ahogas
        if (swimming) {
            swimT += dt
            if (swimT >= SWIM_LIMIT) { deadT = 3.5f; jx = 0f; jy = 0f; moving = false }
            else if (swimT >= 165f && swimWarn < 2) { swimWarn = 2; showToast("¡No puedes más! Sal del agua") }
            else if (swimT >= 120f && swimWarn < 1) { swimWarn = 1; showToast("Te estás cansando de nadar…") }
        } else { swimT = 0f; swimWarn = 0 }

        // rastro para que el trigo se doble al pasar
        trailAcc += dt
        if ((moving || jumpT > 0f) && trailAcc >= 0.06f) {
            trailAcc = 0f
            trailI = (trailI + 1) % TN
            trailX[trailI] = px; trailY[trailI] = py; trailTm[trailI] = gameT
        }
        var bx0 = 1e9f; var by0 = 1e9f; var bx1 = -1e9f; var by1 = -1e9f
        for (k in 0 until TN) if (gameT - trailTm[k] < 1.2f) {
            bx0 = min(bx0, trailX[k]); bx1 = max(bx1, trailX[k]); by0 = min(by0, trailY[k]); by1 = max(by1, trailY[k])
        }
        tbx0 = bx0 - 10f; tby0 = by0 - 10f; tbx1 = bx1 + 10f; tby1 = by1 + 10f

        if (jumpT <= 0f && !swimming) w.buildingAt(px, py)?.let { enterRoom(it); return }

        nearTree = w.nearest(px, py, REACH) { it.kind == KIND_TREE && !inv.felled.contains(Inventory.keyOf(it)) }
        nearStone = w.nearest(px, py, REACH) { it.kind == KIND_STONE && stonesLeft(it) > 0 }

        // partículas: se envuelven alrededor de la cámara
        if (W > 0) {
            val vx0 = floor(px - W / 2f)
            val vy0 = floor(py - H / 2f)
            if (!pInit) {
                for (i in 0 until PN) {
                    pX[i] = vx0 + rnd.nextFloat() * W
                    pY[i] = vy0 + rnd.nextFloat() * H
                    pPh[i] = rnd.nextFloat() * 6.28f
                    pSp[i] = 0.7f + rnd.nextFloat() * 0.8f
                }
                pInit = true
            }
            val m = 10f
            val spanX = W + 2 * m
            val spanY = H + 2 * m
            for (i in 0 until PN) {
                pX[i] += wvx * pSp[i] * dt
                pY[i] += (wvy * pSp[i] + sin(windT * 2.3f + pPh[i]) * 9f) * dt
                if (pX[i] < vx0 - m) pX[i] += spanX else if (pX[i] > vx0 + W + m) pX[i] -= spanX
                if (pY[i] < vy0 - m) pY[i] += spanY else if (pY[i] > vy0 + H + m) pY[i] -= spanY
            }
        }
    }


    // ---------- interiores ----------
    private fun enterRoom(b: Building) {
        room = b
        rW = ((b.maxX - b.minX) * 3f).coerceIn(150f, 340f)
        rH = ((b.maxY - b.minY) * 3f).coerceIn(120f, 260f)
        rx = 0f; ry = rH / 2f - 8f
        retX = b.doorMx + b.doorNx * 8f; retY = b.doorMy + b.doorNy * 8f
        faceA = -Math.PI.toFloat() / 2f
        swimming = false; mud = false; nearFence = false; nearTree = null; nearStone = null
        jx = 0f; jy = 0f
    }

    private fun roomOk(x: Float, y: Float): Boolean {
        if (x < -rW / 2f + 5f || x > rW / 2f - 5f) return false
        if (y < -rH / 2f + ROOM_TOP) return false
        val maxY = if (abs(x) < 7f) rH / 2f + 2f else rH / 2f - 4f
        return y <= maxY
    }

    private fun updateRoom(dt: Float) {
        val b = room ?: return
        swimming = false; mud = false; nearFence = false; nearTree = null; nearStone = null
        val mag = if (panelOpen) 0f else hypot(jx, jy)
        moving = mag > 0.12f
        if (moving) {
            faceA = atan2(jy, jx)
            val sp = SPEED * dt * min(1f, mag)
            val nx = rx + jx / mag * sp
            val ny = ry + jy / mag * sp
            if (roomOk(nx, ry)) rx = nx
            if (roomOk(rx, ny)) ry = ny
            walkT += dt
        }
        if (ry >= rH / 2f - 1f && abs(rx) < 8f) {          // cruzó la puerta: sale a la calle
            px = retX; py = retY
            faceA = atan2(b.doorNy, b.doorNx)
            room = null
            jx = 0f; jy = 0f
        }
    }

    /** Vista de interior: todo lo de fuera en negro, solo se ve la sala. */
    private fun drawRoom(c: Canvas, cx: Int, cy: Int) {
        c.drawColor(BLACK)
        c.save()
        c.translate(-cx.toFloat(), -cy.toFloat())
        fill.style = Paint.Style.FILL
        val l = -rW / 2f; val r = rW / 2f; val t = -rH / 2f; val bt = rH / 2f
        // suelo de tablas
        fill.color = gray(0.60f); c.drawRect(l, t + ROOM_TOP, r, bt, fill)
        var row = 0
        var y = t + ROOM_TOP
        while (y < bt) {
            fill.color = gray(0.46f); c.drawRect(l, y, r, y + 1f, fill)
            var x = l + ((row * 17) % 26)
            while (x < r) { fill.color = gray(0.50f); c.drawRect(x, y, x + 1f, y + 8f, fill); x += 26f }
            y += 8f; row++
        }
        // pared del fondo con ventanas
        fill.color = gray(0.22f); c.drawRect(l - 5f, t - 5f, r + 5f, t + ROOM_TOP, fill)
        fill.color = gray(0.10f); c.drawRect(l - 5f, t + ROOM_TOP - 3f, r + 5f, t + ROOM_TOP, fill)
        var wx = l + 22f
        while (wx < r - 12f) {
            fill.color = gray(0.05f); c.drawRect(wx - 7f, t + 5f, wx + 7f, t + 17f, fill)
            fill.color = gray(0.92f); c.drawRect(wx - 6f, t + 6f, wx + 6f, t + 16f, fill)
            fill.color = gray(0.05f); c.drawRect(wx - 0.5f, t + 6f, wx + 0.5f, t + 16f, fill)
            wx += 46f
        }
        // paredes laterales y pared delantera con hueco de puerta
        fill.color = gray(0.16f)
        c.drawRect(l - 5f, t, l, bt + 5f, fill)
        c.drawRect(r, t, r + 5f, bt + 5f, fill)
        c.drawRect(l - 5f, bt, -8f, bt + 5f, fill)
        c.drawRect(8f, bt, r + 5f, bt + 5f, fill)
        fill.color = gray(0.95f); c.drawRect(-8f, bt, 8f, bt + 2f, fill)   // umbral de la puerta
        c.restore()
        val sx = px; val sy = py
        c.save(); c.translate(-cx.toFloat(), -cy.toFloat())
        px = rx; py = ry
        drawPlayer(c)
        px = sx; py = sy
        c.restore()
    }

    // ---------- acciones del jugador ----------
    private fun showToast(msg: String) { toast = msg; toastT = 2.0f }

    /** Saltar una cerca: avanzas por encima en la dirección que empujas (o hacia donde miras). */
    private fun onJump() {
        if (jumpT > 0f || panelOpen || deadT > 0f || !nearFence) return
        val m = hypot(jx, jy)
        if (m > 0.12f) { jumpDx = jx / m; jumpDy = jy / m } else { jumpDx = cos(faceA); jumpDy = sin(faceA) }
        faceA = atan2(jumpDy, jumpDx)
        jumpT = JUMP_DUR
    }

    /** Golpe con lo que lleves en la mano. Con hacha, junto a un árbol, lo talas. */
    private fun onAttack() {
        if (actCd > 0f || panelOpen) return
        atkT = ATK_DUR
        actCd = 0.45f
        val t = nearTree ?: return
        shakeObj = t; shakeT = 0.5f
        if (inv.hand != Items.AXE) {
            showToast("Necesitas un hacha para talar")
            return
        }
        val key = Inventory.keyOf(t)
        val hits = (chop[key] ?: 0) + 1
        if (hits >= CHOP_HITS) {
            chop.remove(key)
            inv.felled.add(key)
            val leaves = 1 + lootRnd.nextInt(3)
            inv.counts[Items.LOG] += 2
            inv.counts[Items.LEAF] += leaves
            inv.save()
            showToast("¡Talado!  +2 Troncos  +$leaves Hojas")
        } else {
            chop[key] = hits
        }
    }

    /** Rebuscar palos en el árbol que tienes al lado (1 o 2 por árbol). */
    private fun onSearch() {
        if (actCd > 0f || panelOpen) return
        val t = nearTree ?: return
        actCd = 0.5f
        shakeObj = t; shakeT = 0.5f
        val key = Inventory.keyOf(t)
        val total = Inventory.sticksIn(key)
        val got = inv.taken[key] ?: 0
        if (got < total) {
            inv.taken[key] = got + 1
            inv.counts[Items.STICK]++
            inv.save()
            showToast("+1 Palo")
        } else {
            showToast("Este árbol ya no tiene palos")
        }
    }

    /** Rebuscar piedras en el suelo, junto a las que se ven. */
    private fun onStone() {
        if (actCd > 0f || panelOpen) return
        val s = nearStone ?: return
        actCd = 0.5f
        val key = Inventory.keyOf(s)
        val got = inv.stoneTaken[key] ?: 0
        if (got < Inventory.stonesIn(key)) {
            inv.stoneTaken[key] = got + 1
            inv.counts[Items.STONE]++
            inv.save()
            showToast("+1 Piedra")
        }
    }

    private fun craft(r: Recipe) {
        if (!inv.canCraft(r)) { showToast("Te faltan materiales"); return }
        if (r.id == Recipe.FIRE) {
            val w = world ?: return
            if (room != null) { showToast("No se puede hacer fuego dentro de una casa"); return }
            // la fogata se pone delante de ti si se puede, y si no, a tus pies
            var fx = px + cos(faceA) * 10f
            var fy = py + sin(faceA) * 7f
            if (w.blocked(fx, fy) || w.inWater(fx, fy)) { fx = px; fy = py }
            if (w.inWater(fx, fy)) { showToast("No se puede hacer fuego en el agua"); return }
            inv.craft(r)
            inv.addFire(fx, fy)
            showToast("Has encendido una fogata")
        } else {
            inv.craft(r)
            showToast("Has creado: ${r.name}")
        }
        fixSel()
    }

    private fun openPanel() {
        panelOpen = true
        joyId = -1; jx = 0f; jy = 0f
        joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
        fixSel()
    }

    private fun fixSel() {
        val n = inv.slots().size
        if (sel >= n) sel = max(0, n - 1)
    }

    // ---------- render ----------
    private fun render(c: Canvas) {
        if (mapOpen) { worldMap.draw(c, width, height, density, px, py); return }
        val lc = loCanvas ?: return
        val bmp = lo ?: return
        val w = world
        var cx = 0
        var cy = 0
        if (room != null) {
            cx = floor(rx - W / 2f).toInt()
            cy = floor(ry - H / 2f).toInt()
            drawRoom(lc, cx, cy)
        } else if (w != null) {
            cx = floor(px - W / 2f).toInt()
            cy = floor(py - H / 2f).toInt()
            drawWorld(lc, w, cx, cy)
        } else {
            lc.drawColor(gray(0.35f))
        }
        post(bmp, cx, cy)
        c.drawColor(BLACK)
        c.drawBitmap(bmp, null, dst, bmpPaint)
        drawUi(c)
    }

    private fun drawWorld(c: Canvas, w: World, cx: Int, cy: Int) {
        c.drawColor(gray(GROUND_LUM))
        val snap = w.snap
        c.save()
        c.translate(-cx.toFloat(), -cy.toFloat())
        val vx0 = cx.toFloat(); val vx1 = (cx + W).toFloat()
        val vy0 = cy.toFloat(); val vy1 = (cy + H).toFloat()

        // terreno
        fill.style = Paint.Style.FILL
        for (a in snap.areas) {
            if (a.maxX < vx0 || a.minX > vx1 || a.maxY < vy0 || a.minY > vy1) continue
            fill.color = gray(K.LUM[a.kind])
            c.drawPath(a.path, fill)
            if (a.kind == K.WATER && !a.clipped) {
                stroke.strokeWidth = 1.5f; stroke.color = gray(0.58f)
                c.drawPath(a.path, stroke)
            }
            when {
                                a.kind == K.WATER -> { c.save(); c.clipPath(a.path); drawWaves(c, vx0, vy0, vx1, vy1); c.restore() }
                a.kind == K.WET -> { c.save(); c.clipPath(a.path); drawMarsh(c, vx0, vy0, vx1, vy1); c.restore() }
            }
        }
        // ríos y arroyos
        for (r in snap.waterLines) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width; stroke.color = gray(0.14f)
            c.drawPath(r.path, stroke)
        }
        // caminos: borde oscuro + interior claro
        for (r in snap.roads) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width + 2f; stroke.color = gray(0.42f)
            c.drawPath(r.path, stroke)
        }
        for (r in snap.roads) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width; stroke.color = gray(0.96f)
            c.drawPath(r.path, stroke)
        }
        // vías de tren (activas y abandonadas): balasto, traviesas y dos rieles
        for (r in snap.rails) {
            if (r.maxX + 4f < vx0 || r.minX - 4f > vx1 || r.maxY + 4f < vy0 || r.minY - 4f > vy1) continue
            stroke.strokeWidth = 6f; stroke.color = gray(0.56f)
            c.drawPath(r.path, stroke)
            tie.color = gray(0.20f)
            c.drawPath(r.path, tie)
            stroke.strokeWidth = 1f; stroke.color = gray(0.95f)
            c.drawPath(r.left, stroke); c.drawPath(r.right, stroke)
        }

        // hierba natural (a ras de suelo)
        drawGrass(c, w, vx0, vy0, vx1, vy1)
        // trigo: lo que queda detrás del jugador (y lejos de él) va antes que el jugador
        drawCrops(c, w, snap, vx0, vy0, vx1, vy1, false)

        // si el jugador está dentro de un edificio: vista de interior (sin tejado)
        val inB = w.buildingAt(px, py)
        if (inB != null) drawInterior(c, inB)

        val objs = snap.objs
        val first = snap.firstIndexAtY(vy0 - 6f)
        val maxY = vy1 + MAXH
        val dirX = cos(windA)

        // sombras (semitransparentes, oscurecen lo que hay debajo)
        fill.color = Color.argb(95, 0, 0, 0)
        var i = first
        while (i < objs.size && objs[i].y <= maxY) {
            val o = objs[i]
            val b = o.b
            if (b != null) {
                if (b !== inB && !(b.minX > vx1 || b.maxX + b.h < vx0)) c.drawPath(b.shadow, fill)
            } else if (o.x > vx0 - 30f && o.x < vx1 + 30f) {
                when (o.kind) {
                    KIND_TREE -> if (!inv.felled.contains(Inventory.keyOf(o))) {
                        c.save(); c.translate(o.x, o.y); c.drawPath(Sprites.treeShadow, fill); c.restore()
                    }
                    KIND_BUSH -> {
                        c.save(); c.translate(o.x, o.y); c.drawPath(Sprites.bushShadow, fill); c.restore()
                    }
                }
            }
            i++
        }

        // objetos, fogatas y jugador ordenados por profundidad
        val fires = inv.fires
        var fi = 0
        while (fi < fires.size && fires[fi][1] < vy0 - 6f) fi++
        var playerDone = false
        i = first
        while (i < objs.size && objs[i].y <= maxY) {
            val o = objs[i]
            while (fi < fires.size && fires[fi][1] <= o.y) {
                val f = fires[fi]
                if (!playerDone && py < f[1]) { drawPlayer(c); playerDone = true }
                drawFire(c, f[0], f[1])
                fi++
            }
            if (!playerDone && o.y > py) { drawPlayer(c); playerDone = true }
            val b = o.b
            if (b != null) {
                if (b === inB) drawFront(c, b)
                else if (!(b.maxX < vx0 || b.minX > vx1 || b.maxY < vy0 || b.minY - b.h > vy1)) drawBuilding(c, b)
            } else if (o.x > vx0 - 8f && o.x < vx1 + 8f) {
                val ph = (o.variant and 0xFF) * 0.049f
                when (o.kind) {
                    KIND_TREE -> {
                        c.save()
                        c.translate(o.x, o.y)
                        if (inv.felled.contains(Inventory.keyOf(o))) {
                            fill.color = gray(0.15f); c.drawPath(Sprites.stump, fill)       // tocón
                            fill.color = gray(0.60f); c.drawPath(Sprites.stumpTop, fill)
                        } else {
                            // los árboles se inclinan con el viento (la copa se mueve más que la base)
                            var sway = dirX * windS * 3.2f * (0.75f + 0.25f * sin(windT * 3.1f + ph)) +
                                0.45f * sin(windT * 1.2f + ph)
                            if (o === shakeObj && shakeT > 0f) sway += sin(shakeT * 45f) * shakeT * 10f
                            c.skew(-sway / 19f, 0f)
                            fill.color = gray(0.05f)
                            c.drawPath(if (o.variant % 3 == 0) Sprites.treeSmall else Sprites.treeBig, fill)
                        }
                        c.restore()
                    }
                    KIND_BUSH -> {
                        val sway = dirX * windS * 1.3f * (0.8f + 0.2f * sin(windT * 2.6f + ph)) + 0.3f * sin(windT * 1.1f + ph)
                        c.save()
                        c.translate(o.x, o.y)
                        c.skew(-sway / 9f, 0f)
                        fill.color = gray(0.10f); c.drawPath(Sprites.bush, fill)
                        fill.color = gray(0.32f); c.drawPath(Sprites.bushHi, fill)
                        c.restore()
                    }
                    KIND_STONE -> {
                        val left = stonesLeft(o)
                        if (left > 0) drawStones(c, o.x, o.y, left)
                    }
                    KIND_FENCE -> drawFence(c, o as FencePiece)
                    KIND_TRASH -> drawTrash(c, o.x, o.y, o.variant)
                }
            }
            i++
        }
        while (fi < fires.size && fires[fi][1] <= vy1 + 40f) {
            val f = fires[fi]
            if (!playerDone && py < f[1]) { drawPlayer(c); playerDone = true }
            drawFire(c, f[0], f[1])
            fi++
        }
        if (!playerDone) drawPlayer(c)
        // trigo que queda delante del jugador: le tapa las piernas y medio cuerpo
        drawCrops(c, w, snap, vx0, vy0, vx1, vy1, true)
        if (inB == null) drawWind(c)
        c.restore()
    }

    /** Matas de hierba repartidas por el suelo libre, en parches, que se mecen con el viento. */
    private fun drawGrass(c: Canvas, w: World, vx0: Float, vy0: Float, vx1: Float, vy1: Float) {
        val cs = 9
        val gx0 = floor(vx0 / cs).toInt() - 1
        val gx1 = floor(vx1 / cs).toInt() + 1
        val gy0 = floor(vy0 / cs).toInt() - 1
        val gy1 = floor(vy1 / cs).toInt() + 1
        val lean = cos(windA) * windS * 1.6f
        for (gy in gy0..gy1) for (gx in gx0..gx1) {
            val h = hash2(gx, gy)
            val patch = hash2(Math.floorDiv(gx, 5), Math.floorDiv(gy, 5)) and 0xFF
            if ((h and 0xFF) >= 20 + patch / 3) continue
            val x = floor((gx + ((h ushr 8) and 0xFF) / 255f) * cs)
            val y = floor((gy + ((h ushr 16) and 0xFF) / 255f) * cs)
            if (!w.groundFree(x, y)) continue
            val sw = lean + sin(windT * 2.5f + (h and 0xFF) * 0.05f) * 0.5f
            fill.color = if (((h ushr 4) and 3) == 0) gray(0.92f) else gray(0.20f)
            val tall = 2f + ((h ushr 24) and 1)
            c.drawRect(x, y - 2f, x + 1f, y, fill)                          // base
            c.drawRect(x + sw, y - 2f - tall, x + sw + 1f, y - 2f, fill)    // punta
            c.drawRect(x + 2f, y - 1f, x + 3f, y, fill)
            c.drawRect(x + 2f + sw * 0.7f, y - 1f - tall, x + 3f + sw * 0.7f, y - 1f, fill)
        }
    }

    // ---------- cultivos de trigo ----------
    /** Cuánto se dobla (bendLean) y se aplasta (bendSq) una mata en (x, y) por el paso reciente del jugador. */
    private fun bend(x: Float, y: Float) {
        bendLean = 0f; bendSq = 0f
        if (x < tbx0 || x > tbx1 || y < tby0 || y > tby1) return
        for (k in 0 until TN) {
            val age = gameT - trailTm[k]
            if (age > 1.2f || age < 0f) continue
            val dx = x - trailX[k]
            val dy = (y - trailY[k]) * 1.5f
            val d2 = dx * dx + dy * dy
            if (d2 >= 100f) continue
            val wgt = (1f - sqrt(d2) / 10f) * (1f - age / 1.2f)
            bendLean += (if (dx >= 0f) 1f else -1f) * wgt * 3.2f
            bendSq += wgt
        }
        if (bendSq > 1f) bendSq = 1f
        bendLean = bendLean.coerceIn(-4f, 4f)
    }

    /**
     * Matas de trigo en filas dentro de los campos de cultivo. Miden ~6 px (la mitad del personaje).
     * front=false: todas menos la franja que está justo delante del jugador (se dibujan antes que él).
     * front=true: solo esa franja (se dibuja después, así tapa al personaje).
     */
    private fun drawCrops(c: Canvas, w: World, snap: Snapshot, vx0: Float, vy0: Float, vx1: Float, vy1: Float, front: Boolean) {
        val lean0 = cos(windA) * windS * 1.4f
        for (a in snap.areas) {
            if (!a.crop) continue
            if (a.maxX < vx0 || a.minX > vx1 || a.maxY < vy0 || a.minY > vy1 + 8f) continue
            var yA = max(a.minY, vy0 - 2f)
            var yB = min(a.maxY, vy1 + 8f)
            if (front) {
                if (px < a.minX - 8f || px > a.maxX + 8f) continue
                yA = max(yA, py); yB = min(yB, py + 9f)
                if (yA >= yB) continue
            }
            val xA = max(a.minX, vx0 - 4f); val xB = min(a.maxX, vx1 + 4f)
            c.save()
            c.clipPath(a.path)
            val j0 = floor(xA / PLANT).toInt(); val j1 = floor(xB / PLANT).toInt()
            for (k in floor(yA / ROW).toInt()..floor(yB / ROW).toInt()) {
                val y = k * ROW + 1f
                val inStrip = y > py && y <= py + 8f
                if (front != inStrip) continue
                for (j in j0..j1) {
                    val h = hash2(j, k)
                    val x = j * PLANT + ((h ushr 4) and 1)
                    if (!w.groundFree(x, y)) continue
                    bend(x, y)
                    val sway = lean0 * (0.7f + 0.3f * sin(windT * 2.2f + (h and 0xFF) * 0.07f)) + bendLean
                    val ht = 5.5f + ((h ushr 8) and 3) * 0.5f - bendSq * 2.2f
                    fill.color = gray(0.26f)
                    c.drawRect(x, y - 3f, x + 1f, y, fill)                                           // tallo
                    c.drawRect(x + sway * 0.5f, y - ht, x + sway * 0.5f + 1f, y - 3f, fill)
                    fill.color = gray(0.95f)
                    c.drawRect(x + sway - 0.5f, y - ht - 2f, x + sway + 1.5f, y - ht + 0.5f, fill)  // espiga
                }
            }
            c.restore()
        }
    }

    // ---------- agua, humedal, cercas, basura, iglesias ----------
    /** Olas pequeñas que suben y bajan: marcan que ahí hay agua. */
    private fun drawWaves(c: Canvas, vx0: Float, vy0: Float, vx1: Float, vy1: Float) {
        val cs = 12
        fill.color = gray(0.64f)
        for (gy in floor(vy0 / cs).toInt() - 1..floor(vy1 / cs).toInt() + 1) {
            for (gx in floor(vx0 / cs).toInt() - 1..floor(vx1 / cs).toInt() + 1) {
                val h = hash2(gx, gy)
                if ((h and 3) != 0) continue
                val x = (gx * cs + ((h ushr 8) and 7)).toFloat()
                val y = (gy * cs + ((h ushr 16) and 7)).toFloat()
                val ph = windT * 1.5f + (h and 0xFF) * 0.12f
                val xo = sin(ph) * 1.6f
                val up = if (sin(ph + 1.2f) > 0.3f) 1f else 0f
                c.drawRect(x + xo - 2f, y, x + xo - 1f, y + 1f, fill)
                c.drawRect(x + xo - 1f, y - 1f - up, x + xo + 1f, y - up, fill)
                c.drawRect(x + xo + 1f, y, x + xo + 2f, y + 1f, fill)
            }
        }
    }

    /** Juncos y charcos del humedal. */
    private fun drawMarsh(c: Canvas, vx0: Float, vy0: Float, vx1: Float, vy1: Float) {
        val cs = 9
        val lean = cos(windA) * windS * 1.2f
        for (gy in floor(vy0 / cs).toInt() - 1..floor(vy1 / cs).toInt() + 1) {
            for (gx in floor(vx0 / cs).toInt() - 1..floor(vx1 / cs).toInt() + 1) {
                val h = hash2(gx + 500, gy)
                if ((h and 3) >= 2) continue
                val x = (gx * cs + ((h ushr 8) and 7)).toFloat()
                val y = (gy * cs + ((h ushr 16) and 7)).toFloat()
                fill.color = gray(0.68f); c.drawRect(x - 2f, y + 1f, x + 3f, y + 2f, fill)                // reflejo del charco
                val sw = lean * 0.6f
                fill.color = gray(0.12f)
                c.drawRect(x, y - 2f, x + 1f, y + 1f, fill)
                c.drawRect(x + sw, y - 5f, x + sw + 1f, y - 2f, fill)
                c.drawRect(x + 2f, y - 1f, x + 3f, y + 1f, fill)
                c.drawRect(x + 2f + sw, y - 3f, x + 3f + sw, y - 1f, fill)
            }
        }
    }

    /** Trocito de cerca (postes y dos tablas), seto o muro: mide ~5 px, la mitad del personaje. */
    private fun drawFence(c: Canvas, f: FencePiece) {
        when (f.style) {
            1 -> {                                                          // seto
                stroke.strokeWidth = 4f; stroke.color = gray(0.10f)
                c.drawLine(f.x1, f.y1 - 2f, f.x2, f.y2 - 2f, stroke)
                stroke.strokeWidth = 1f; stroke.color = gray(0.36f)
                c.drawLine(f.x1, f.y1 - 4f, f.x2, f.y2 - 4f, stroke)
            }
            2 -> {                                                          // muro
                stroke.strokeWidth = 4f; stroke.color = gray(0.58f)
                c.drawLine(f.x1, f.y1 - 2f, f.x2, f.y2 - 2f, stroke)
                stroke.strokeWidth = 1f; stroke.color = gray(0.95f)
                c.drawLine(f.x1, f.y1 - 4.5f, f.x2, f.y2 - 4.5f, stroke)
                stroke.color = gray(0.18f)
                c.drawLine(f.x1, f.y1, f.x2, f.y2, stroke)
            }
            else -> {                                                       // cerca
                stroke.strokeWidth = 1f; stroke.color = gray(0.12f)
                c.drawLine(f.x1, f.y1 - 2f, f.x2, f.y2 - 2f, stroke)
                c.drawLine(f.x1, f.y1 - 4f, f.x2, f.y2 - 4f, stroke)
                fill.color = gray(0.08f)
                c.drawRect(f.x1 - 0.5f, f.y1 - 5f, f.x1 + 0.5f, f.y1 + 0.5f, fill)
                c.drawRect(f.x2 - 0.5f, f.y2 - 5f, f.x2 + 0.5f, f.y2 + 0.5f, fill)
            }
        }
    }

    /** Montón de basura decorativo (vertederos). */
    private fun drawTrash(c: Canvas, x: Float, y: Float, v: Int) {
        fill.color = Color.argb(90, 0, 0, 0); c.drawRect(x - 5f, y - 1f, x + 7f, y + 1f, fill)
        fill.color = gray(0.30f); c.drawRect(x - 5f, y - 3f, x + 5f, y, fill)
        fill.color = gray(0.38f); c.drawRect(x - 3f, y - 5f, x + 3f, y - 3f, fill)
        for (k in 0..5) {
            val h = hash2(v, k)
            val sx = x - 5f + (h and 7)
            val sy = y - 5f + ((h ushr 4) and 3)
            fill.color = if (((h ushr 8) and 1) == 0) gray(0.92f) else gray(0.08f)
            c.drawRect(sx, sy, sx + 2f, sy + 1f, fill)
        }
    }

    /** Torre con aguja y cruz de las iglesias (se dibuja a la altura del tejado). */
    private fun drawTower(c: Canvas, b: Building) {
        val tx = (b.minX + b.maxX) / 2f
        val ty = b.maxY - 3f
        val hw = min(4.5f, (b.maxX - b.minX) * 0.3f)
        fill.color = gray(0.34f); c.drawRect(tx - hw, ty - 15f, tx + hw, ty, fill)
        fill.color = gray(0.14f); c.drawRect(tx + hw * 0.3f, ty - 15f, tx + hw, ty, fill)
        fill.color = gray(0.98f); c.drawRect(tx - hw * 0.45f, ty - 11f, tx + hw * 0.1f, ty - 6f, fill)     // campanario
        spire.rewind()
        spire.moveTo(tx - hw - 1f, ty - 15f); spire.lineTo(tx + hw + 1f, ty - 15f); spire.lineTo(tx, ty - 24f); spire.close()
        fill.color = gray(0.08f); c.drawPath(spire, fill)
        stroke.strokeWidth = 1f; stroke.color = gray(0.97f)
        c.drawLine(tx, ty - 24f, tx, ty - 31f, stroke)                                                       // cruz
        c.drawLine(tx - 2f, ty - 28f, tx + 2f, ty - 28f, stroke)
    }

    private fun drawStones(c: Canvas, x: Float, y: Float, n: Int) {
        fill.color = Color.argb(90, 0, 0, 0)
        c.drawRect(x - 3f, y, x + 6f, y + 1f, fill)
        fill.color = gray(0.42f); c.drawRect(x - 3f, y - 3f, x + 2f, y, fill)
        fill.color = gray(0.88f); c.drawRect(x - 2f, y - 3f, x, y - 2f, fill)
        if (n >= 2) {
            fill.color = gray(0.36f); c.drawRect(x + 2f, y - 2f, x + 6f, y + 1f, fill)
            fill.color = gray(0.85f); c.drawRect(x + 3f, y - 2f, x + 4f, y - 1f, fill)
        }
    }

    private fun drawFire(c: Canvas, fx: Float, fy: Float) {
        // resplandor
        fill.color = Color.argb(60, 255, 255, 255)
        c.drawOval(RectF(fx - 18f, fy - 10f, fx + 18f, fy + 8f), fill)
        // troncos cruzados
        stroke.strokeWidth = 2f; stroke.color = gray(0.10f)
        c.drawLine(fx - 5f, fy, fx + 5f, fy - 2f, stroke)
        c.drawLine(fx - 5f, fy - 2f, fx + 5f, fy, stroke)
        // llamas que parpadean y se doblan con el viento
        val t = windT * 11f + fx
        val h1 = 6f + 2f * sin(t)
        val h2 = 4f + 2f * sin(t * 1.7f + 1f)
        val h3 = 5f + 2f * sin(t * 1.3f + 2f)
        val lean = cos(windA) * windS * 1.5f
        fill.color = gray(0.80f)
        c.drawRect(fx - 2f + lean, fy - 2f - h1, fx + 2f + lean, fy - 1f, fill)
        c.drawRect(fx - 4f, fy - 2f - h2, fx - 2f, fy - 1f, fill)
        c.drawRect(fx + 2f, fy - 2f - h3, fx + 4f, fy - 1f, fill)
        fill.color = gray(1f)
        c.drawRect(fx - 1f + lean * 0.5f, fy - 1f - h1 * 0.55f, fx + 1f + lean * 0.5f, fy - 1f, fill)
        // humo
        for (k in 0..2) {
            val ph = (windT * 0.7f + k * 0.33f) % 1f
            val sx = fx + lean * ph * 6f + sin(ph * 6f + k) * 1.5f
            val sy = fy - 8f - ph * 16f
            fill.color = gray(0.85f - ph * 0.4f)
            c.drawRect(sx, sy, sx + 1.5f, sy + 1.5f, fill)
        }
    }

    private fun drawInterior(c: Canvas, b: Building) {
        fill.color = gray(0.70f); c.drawPath(b.roof, fill)          // suelo
        fill.color = gray(0.16f); c.drawPath(b.wallBack, fill)      // paredes del fondo
        stroke.strokeWidth = 2f; stroke.color = gray(0.05f)
        c.drawPath(b.roof, stroke)                                   // base de las paredes
    }

    private fun drawFront(c: Canvas, b: Building) {
        fill.color = gray(0.12f); c.drawPath(b.wallFront, fill)     // pared baja delantera con hueco de puerta
    }

    private fun drawWind(c: Canvas) {
        val len = 1 + (windS * 3f).toInt()
        for (i in 0 until PN) {
            val x = floor(pX[i])
            val y = floor(pY[i])
            if (i % 5 == 0) {                       // hojas / ceniza
                fill.color = gray(0.04f)
                c.drawRect(x, y, x + 2f, y + 2f, fill)
            } else {                                 // nieve y polvo
                fill.color = if (i % 2 == 0) gray(1f) else gray(0.04f)
                c.drawRect(x, y, x + len, y + 1f, fill)
            }
        }
    }

    private fun drawBuilding(c: Canvas, b: Building) {
        fill.color = gray(0.10f); c.drawPath(b.wallA, fill)
        fill.color = gray(0.26f); c.drawPath(b.wallB, fill)
        fill.color = gray(1f); c.drawPath(b.windows, fill)
        if (b.enterable) { fill.color = gray(0.95f); c.drawPath(b.door, fill) }
        c.save()
        c.translate(0f, -b.h)
        fill.color = gray(0.86f); c.drawPath(b.roof, fill)
        stroke.strokeWidth = 1f; stroke.color = gray(0.15f); c.drawPath(b.roof, stroke)
        if (b.church) drawTower(c, b)
        c.restore()
        if (b.enterable) { fill.color = gray(0.40f); c.drawPath(b.mat, fill) }
    }

    private fun drawPlayer(c: Canvas) {
        val x = px.toInt().toFloat()
        val y = py.toInt().toFloat()
        if (swimming) {
            // hundido hasta la mitad: solo se ve la parte de arriba + ondas en el agua
            c.save()
            c.clipRect(x - 10f, y - 16f, x + 12f, y - 4f)
            drawBody(c, x, y + 2f)
            c.restore()
            val k = ((walkT * 5f).toInt() and 1).toFloat()
            fill.color = gray(0.95f)
            c.drawRect(x - 4f - k, y - 4f, x + 4f + k, y - 3f, fill)
            fill.color = gray(0.75f)
            c.drawRect(x - 6f + k, y - 2f, x + 6f - k, y - 1f, fill)
        } else if (mud && jumpT <= 0f) {
            // fango: se hunden las piernas
            c.save()
            c.clipRect(x - 10f, y - 16f, x + 12f, y - 3f)
            drawBody(c, x, y)
            c.restore()
            fill.color = gray(0.22f); c.drawRect(x - 4f, y - 3f, x + 4f, y - 2f, fill)
            fill.color = gray(0.34f); c.drawRect(x - 6f, y - 2f, x + 6f, y - 1f, fill)
        } else {
            val lift = if (jumpT > 0f) sin(Math.PI.toFloat() * (1f - jumpT / JUMP_DUR)) * 9f else 0f
            fill.color = Color.argb(110, 0, 0, 0)
            c.drawRect(x - 2f, y - 1f, x + 6f, y + 1f, fill)      // sombra
            drawBody(c, x, y - lift)
        }
    }

    private fun drawBody(c: Canvas, x: Float, y: Float) {
        fill.color = gray(0.03f)
        c.drawRect(x - 1f, y - 10f, x + 1f, y - 7f, fill)         // cabeza
        c.drawRect(x - 2f, y - 7f, x + 2f, y - 3f, fill)          // cuerpo
        val step = moving && ((walkT * 8f).toInt() and 1) == 0
        val l = if (step) y - 1f else y
        val r = if (step || !moving) y else y - 1f
        c.drawRect(x - 2f, y - 3f, x - 0.5f, l, fill)             // piernas
        c.drawRect(x + 0.5f, y - 3f, x + 2f, r, fill)

        val hx = x + 2f
        val hy = y - 5f
        val held = inv.hand
        if (atkT > 0f) {
            // golpe: el brazo (y la herramienta, si la llevas) barre un arco hacia donde miras
            val p = 1f - atkT / ATK_DUR
            val a = faceA - 1.0f + 2.0f * p
            fill.color = gray(1f)
            for (k in 0..3) {
                val aa = a - k * 0.3f
                val sx = x + cos(aa) * 10f
                val sy = y - 5f + sin(aa) * 10f
                c.drawRect(sx, sy, sx + 2f, sy + 2f, fill)
            }
            if (held == Items.STICK || held == Items.AXE) drawTool(c, hx, hy, a, held)
        } else if (held == Items.STICK || held == Items.AXE) {
            drawTool(c, hx, hy, -1.1f, held)                      // en reposo, apuntando arriba
        }
    }

    private fun drawTool(c: Canvas, x: Float, y: Float, a: Float, id: Int) {
        stroke.strokeWidth = 1.5f
        stroke.color = gray(0.38f)
        val ex = x + cos(a) * 8f
        val ey = y + sin(a) * 8f
        c.drawLine(x, y, ex, ey, stroke)
        if (id == Items.AXE) {                                    // cabeza de piedra del hacha
            fill.color = gray(0.80f)
            c.drawRect(ex - 1.5f, ey - 1.5f, ex + 1.5f, ey + 1.5f, fill)
        }
    }

    /** Posproceso: viñeta + ruido + dithering Bayer a la paleta de 4 tonos + esquinas redondeadas. */
    private fun post(bmp: Bitmap, camX: Int, camY: Int) {
        bmp.getPixels(pix, 0, W, 0, 0, W, H)
        var i = 0
        for (y in 0 until H) {
            val wy = y + camY
            val row = (wy and 3) shl 2
            for (x in 0 until W) {
                val v = vig[i]
                if (v < 0f) {
                    pix[i] = BLACK
                } else {
                    val wx = x + camX     // el patrón se ancla al mundo: no "nada" al caminar
                    val n = (((wx * 73856093) xor (wy * 19349663)) ushr 9) and 15
                    var l = (pix[i] and 0xFF) * (1f / 255f) * v + (n - 7.5f) * 0.0075f
                    if (l < 0f) l = 0f else if (l > 1f) l = 1f
                    val t = l * 3f
                    var idx = t.toInt()
                    if (t - idx > BAYER[row + (wx and 3)]) idx++
                    pix[i] = PAL[if (idx > 3) 3 else idx]
                }
                i++
            }
        }
        bmp.setPixels(pix, 0, W, 0, 0, W, H)
    }

    private fun buildVignette(w: Int, h: Int): FloatArray {
        val a = FloatArray(w * h)
        val r = min(w, h) * 0.08f
        for (y in 0 until h) for (x in 0 until w) {
            val nx = (x + 0.5f - w / 2f) / (w / 2f)
            val ny = (y + 0.5f - h / 2f) / (h / 2f)
            var v = 1f - 0.30f * (nx * nx + ny * ny)
            if (v < 0.25f) v = 0.25f
            val cx = if (x < r) r else if (x > w - r) w - r else x.toFloat()
            val cy = if (y < r) r else if (y > h - r) h - r else y.toFloat()
            if (cx != x.toFloat() || cy != y.toFloat()) {
                val dx = x - cx; val dy = y - cy
                if (dx * dx + dy * dy > r * r) v = -1f
            }
            a[y * w + x] = v
        }
        return a
    }

    // ---------- interfaz (a resolución completa) ----------
    private fun atkCx() = width - 84f * density
    private fun atkCy() = height - 84f * density
    private fun atkR() = 42f * density
    private fun srcCx() = width - 180f * density
    private fun srcCy() = height - 64f * density
    private fun srcR() = 32f * density
    private fun stoneCx() = width - 84f * density
    private fun stoneCy() = height - 168f * density
    private fun jumpCx() = width - 180f * density
    private fun jumpCy() = height - 150f * density
    private fun mapBtnRect() = RectF(width - 160f * density, 12f * density, width - 88f * density, 56f * density)

    private fun openMap() {
        if (world == null) return
        panelOpen = false
        joyId = -1; jx = 0f; jy = 0f
        joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
        worldMap.open()
        mapOpen = true
    }

    /** Botón atrás: cierra el mapa o la bolsa. Devuelve true si lo usó. */
    fun handleBack(): Boolean {
        if (mapOpen) { mapOpen = false; return true }
        if (panelOpen) { panelOpen = false; return true }
        return false
    }

    private fun bagRect() = RectF(width - 80f * density, 12f * density, width - 12f * density, 56f * density)

    private fun panelRect(): RectF {
        val pw = min(width - 24f * density, 420f * density)
        val ph = min(height - 24f * density, 270f * density)
        val l = (width - pw) / 2f
        val t = (height - ph) / 2f
        return RectF(l, t, l + pw, t + ph)
    }

    private fun tabRect(r: RectF, k: Int): RectF {
        val l = r.left + 16f * density + k * 104f * density
        val t = r.top + 10f * density
        return RectF(l, t, l + 96f * density, t + 32f * density)
    }

    private fun slotRect(r: RectF, i: Int): RectF {
        val s = 52f * density
        val g = 8f * density
        val l = r.left + 16f * density + (i % 4) * (s + g)
        val t = r.top + 54f * density + (i / 4) * (s + g)
        return RectF(l, t, l + s, t + s)
    }

    private fun btnRect(r: RectF, k: Int): RectF {
        val x0 = r.left + 268f * density
        val t = r.top + 92f * density + k * 46f * density
        return RectF(x0, t, max(x0 + 60f * density, r.right - 16f * density), t + 40f * density)
    }

    private fun rowRect(r: RectF, k: Int): RectF {
        val t = r.top + 54f * density + k * 60f * density
        return RectF(r.left + 16f * density, t, r.right - 16f * density, t + 52f * density)
    }

    private fun label(c: Canvas, text: String, cx: Float, cy: Float, size: Float, color: Int) {
        ui.style = Paint.Style.FILL
        ui.typeface = Typeface.MONOSPACE
        ui.textAlign = Paint.Align.CENTER
        ui.textSize = size
        ui.color = color
        c.drawText(text, cx, cy + size * 0.35f, ui)
    }

    private fun roundButton(c: Canvas, cx: Float, cy: Float, r: Float, text: String, active: Boolean) {
        ui.style = Paint.Style.FILL; ui.color = Color.argb(if (active) 80 else 46, 234, 233, 219)
        c.drawCircle(cx, cy, r, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 3f * density
        ui.color = Color.argb(if (active) 200 else 130, 234, 233, 219)
        c.drawCircle(cx, cy, r, ui)
        label(c, text, cx, cy, 12f * density, CREAM)
    }

    private fun boxButton(c: Canvas, r: RectF, text: String, enabled: Boolean, selected: Boolean = false) {
        ui.style = Paint.Style.FILL
        ui.color = if (selected) Color.argb(110, 234, 233, 219) else if (enabled) Color.argb(60, 234, 233, 219) else Color.argb(20, 234, 233, 219)
        c.drawRoundRect(r, 6f * density, 6f * density, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density
        ui.color = if (enabled) CREAM else MIDGRAY
        c.drawRoundRect(r, 6f * density, 6f * density, ui)
        label(c, text, r.centerX(), r.centerY(), 13f * density, if (enabled) CREAM else MIDGRAY)
    }

    private fun drawItemIcon(c: Canvas, id: Int, s: RectF) {
        val cx = s.centerX()
        val cy = s.centerY()
        val d = density
        ui.strokeCap = Paint.Cap.ROUND
        when (id) {
            Items.STICK -> {
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 4f * d; ui.color = LIGHTGRAY
                c.drawLine(cx - 14f * d, cy + 14f * d, cx + 14f * d, cy - 14f * d, ui)
            }
            Items.STONE -> {
                ui.style = Paint.Style.FILL; ui.color = 0xFF8A8087.toInt()
                c.drawOval(RectF(cx - 13f * d, cy - 9f * d, cx + 13f * d, cy + 9f * d), ui)
                ui.color = CREAM
                c.drawOval(RectF(cx - 8f * d, cy - 6f * d, cx - 2f * d, cy - 3f * d), ui)
            }
            Items.LOG -> {
                val rr = RectF(cx - 15f * d, cy - 8f * d, cx + 15f * d, cy + 8f * d)
                ui.style = Paint.Style.FILL; ui.color = MIDGRAY
                c.drawRoundRect(rr, 4f * d, 4f * d, ui)
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 1.5f * d; ui.color = CREAM
                c.drawRoundRect(rr, 4f * d, 4f * d, ui)
                c.drawCircle(cx + 9f * d, cy, 4f * d, ui)
            }
            Items.LEAF -> {
                ui.style = Paint.Style.FILL; ui.color = LIGHTGRAY
                c.drawOval(RectF(cx - 12f * d, cy - 7f * d, cx + 12f * d, cy + 7f * d), ui)
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 1.5f * d; ui.color = 0xFF2A2428.toInt()
                c.drawLine(cx - 10f * d, cy + 5f * d, cx + 10f * d, cy - 5f * d, ui)
            }
            Items.AXE -> {
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 4f * d; ui.color = LIGHTGRAY
                c.drawLine(cx - 12f * d, cy + 13f * d, cx + 8f * d, cy - 9f * d, ui)
                ui.style = Paint.Style.FILL; ui.color = 0xFF8A8087.toInt()
                c.drawRect(cx + 2f * d, cy - 16f * d, cx + 15f * d, cy - 4f * d, ui)
            }
        }
        ui.strokeCap = Paint.Cap.BUTT
    }

    private fun drawUi(c: Canvas) {
        // joystick
        ui.style = Paint.Style.FILL; ui.color = Color.argb(46, 234, 233, 219)
        c.drawCircle(joyOx, joyOy, joyR, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 3f * density; ui.color = Color.argb(150, 234, 233, 219)
        c.drawCircle(joyOx, joyOy, joyR, ui)
        ui.style = Paint.Style.FILL; ui.color = Color.argb(170, 234, 233, 219)
        c.drawCircle(joyKx, joyKy, joyR * 0.42f, ui)

        // versión del juego (arriba, centro)
        if (verText.isNotEmpty()) {
            ui.style = Paint.Style.FILL; ui.textSize = 10f * density; ui.typeface = Typeface.MONOSPACE
            ui.textAlign = Paint.Align.CENTER; ui.color = Color.argb(150, 234, 233, 219)
            c.drawText(verText, width / 2f, 22f * density, ui)
            ui.textAlign = Paint.Align.LEFT
        }

        val st = world?.status
        if (st != null) {
            // estado de la descarga del mapa (arriba a la izquierda)
            ui.textSize = 12f * density
            ui.typeface = Typeface.MONOSPACE
            ui.textAlign = Paint.Align.LEFT
            val tw = ui.measureText(st)
            ui.style = Paint.Style.FILL; ui.color = Color.argb(200, 42, 36, 40)
            c.drawRoundRect(RectF(12f * density, 12f * density, 12f * density + tw + 16f * density, 40f * density), 8f * density, 8f * density, ui)
            ui.color = CREAM
            c.drawText(st, 20f * density, 31f * density, ui)
        }

        if (world != null) {
            // botones de acción
            roundButton(c, atkCx(), atkCy(), atkR(), "Atacar", atkT > 0f)
            if (nearTree != null) roundButton(c, srcCx(), srcCy(), srcR(), "Buscar", false)
            if (nearStone != null) roundButton(c, stoneCx(), stoneCy(), srcR(), "Piedras", false)
            if (nearFence) roundButton(c, jumpCx(), jumpCy(), srcR(), "Saltar", jumpT > 0f)
            boxButton(c, bagRect(), "Bolsa", true)
            boxButton(c, mapBtnRect(), "Mapa", true)
            if (panelOpen) drawPanel(c)

            // cansancio de nadar (se llena hasta los 3 minutos)
            if (swimT > 5f) {
                val bw = 150f * density; val bh = 7f * density
                val l = width / 2f - bw / 2f; val t = 54f * density
                ui.style = Paint.Style.FILL; ui.color = Color.argb(150, 42, 36, 40)
                c.drawRoundRect(RectF(l, t, l + bw, t + bh), 4f * density, 4f * density, ui)
                ui.color = if (swimT > 120f) CREAM else LIGHTGRAY
                c.drawRoundRect(RectF(l, t, l + bw * min(1f, swimT / SWIM_LIMIT), t + bh), 4f * density, 4f * density, ui)
                label(c, "Cansancio", width / 2f, t + bh + 10f * density, 10f * density, CREAM)
            }

            // aviso breve (arriba, por encima del panel)
            val t = toast
            if (t != null) {
                ui.textSize = 14f * density
                ui.typeface = Typeface.MONOSPACE
                val tw = ui.measureText(t)
                val cx = width / 2f
                val cy = 30f * density
                ui.style = Paint.Style.FILL; ui.color = Color.argb(225, 42, 36, 40)
                c.drawRoundRect(RectF(cx - tw / 2f - 14f * density, cy - 16f * density, cx + tw / 2f + 14f * density, cy + 16f * density), 8f * density, 8f * density, ui)
                label(c, t, cx, cy, 14f * density, CREAM)
            }
        }

        if (deadT > 0f) {
            ui.style = Paint.Style.FILL; ui.color = Color.argb(205, 20, 16, 18)
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), ui)
            label(c, "Te ahogaste", width / 2f, height / 2f - 26f * density, 24f * density, CREAM)
            label(c, "El cansancio de nadar te venció", width / 2f, height / 2f + 4f * density, 14f * density, LIGHTGRAY)
            label(c, "Reapareces en el punto de inicio…", width / 2f, height / 2f + 28f * density, 13f * density, LIGHTGRAY)
        }

        // mensajes (carga / error)
        val msg = message ?: return
        ui.style = Paint.Style.FILL
        ui.typeface = Typeface.MONOSPACE
        ui.textAlign = Paint.Align.CENTER
        ui.textSize = 15f * density
        ui.color = CREAM
        var y = height / 2f - (msg.count { it == '\n' }) * ui.textSize * 0.6f
        for (line in msg.split("\n")) {
            c.drawText(line, width / 2f, y, ui)
            y += ui.textSize * 1.3f
        }
    }

    private fun drawPanel(c: Canvas) {
        val r = panelRect()
        ui.style = Paint.Style.FILL; ui.color = Color.argb(245, 42, 36, 40)
        c.drawRoundRect(r, 10f * density, 10f * density, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density; ui.color = CREAM
        c.drawRoundRect(r, 10f * density, 10f * density, ui)

        boxButton(c, tabRect(r, 0), "Bolsa", true, panelTab == 0)
        boxButton(c, tabRect(r, 1), "Crear", true, panelTab == 1)

        if (panelTab == 0) drawBagTab(c, r) else drawCraftTab(c, r)
    }

    private fun drawBagTab(c: Canvas, r: RectF) {
        val slots = inv.slots()
        for (i in 0 until 12) {
            val s = slotRect(r, i)
            val isSel = i == sel && i < slots.size
            ui.style = Paint.Style.FILL; ui.color = Color.argb(30, 234, 233, 219)
            c.drawRoundRect(s, 4f * density, 4f * density, ui)
            ui.style = Paint.Style.STROKE
            ui.strokeWidth = (if (isSel) 3f else 1.5f) * density
            ui.color = if (isSel) CREAM else MIDGRAY
            c.drawRoundRect(s, 4f * density, 4f * density, ui)
            if (i < slots.size) {
                val id = slots[i]
                drawItemIcon(c, id, s)
                ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.RIGHT; ui.typeface = Typeface.MONOSPACE
                ui.textSize = 12f * density; ui.color = CREAM
                c.drawText("x${inv.counts[id]}", s.right - 4f * density, s.bottom - 4f * density, ui)
            }
        }

        val x0 = r.left + 268f * density
        ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.LEFT; ui.typeface = Typeface.MONOSPACE
        ui.textSize = 13f * density; ui.color = CREAM
        val handName = if (inv.hand >= 0) Items.NAMES[inv.hand] else "vacía"
        c.drawText("Mano: $handName", x0, r.top + 76f * density, ui)

        val canEquip = sel < slots.size && Items.equippable(slots[sel])
        boxButton(c, btnRect(r, 0), "Equipar", canEquip)
        boxButton(c, btnRect(r, 1), "Guardar", inv.hand >= 0)
        boxButton(c, btnRect(r, 2), "Cerrar", true)
        if (slots.isEmpty()) {
            ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.LEFT; ui.textSize = 12f * density
            ui.color = LIGHTGRAY
            c.drawText("Vacío. Rebusca en árboles y suelo.", r.left + 16f * density, r.bottom - 12f * density, ui)
        }
    }

    private fun drawCraftTab(c: Canvas, r: RectF) {
        for ((k, rec) in Inventory.RECIPES.withIndex()) {
            val row = rowRect(r, k)
            val ok = inv.canCraft(rec)
            ui.style = Paint.Style.FILL
            ui.color = if (ok) Color.argb(55, 234, 233, 219) else Color.argb(18, 234, 233, 219)
            c.drawRoundRect(row, 6f * density, 6f * density, ui)
            ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density
            ui.color = if (ok) CREAM else MIDGRAY
            c.drawRoundRect(row, 6f * density, 6f * density, ui)
            ui.style = Paint.Style.FILL; ui.typeface = Typeface.MONOSPACE; ui.textAlign = Paint.Align.LEFT
            ui.color = if (ok) CREAM else MIDGRAY
            ui.textSize = 15f * density
            c.drawText(rec.name, row.left + 12f * density, row.top + 22f * density, ui)
            ui.textSize = 11f * density
            c.drawText(rec.desc, row.left + 12f * density, row.top + 41f * density, ui)
            ui.textAlign = Paint.Align.RIGHT; ui.textSize = 13f * density
            c.drawText(if (ok) "Crear" else "Faltan", row.right - 12f * density, row.centerY() + 5f * density, ui)
        }
    }

    private fun handlePanelTouch(x: Float, y: Float) {
        val r = panelRect()
        if (bagRect().contains(x, y) || !r.contains(x, y)) { panelOpen = false; return }
        for (k in 0..1) {
            if (tabRect(r, k).contains(x, y)) { panelTab = k; return }
        }
        if (panelTab == 0) {
            val slots = inv.slots()
            for (i in 0 until 12) {
                if (slotRect(r, i).contains(x, y)) { if (i < slots.size) sel = i; return }
            }
            if (btnRect(r, 0).contains(x, y)) {
                if (sel < slots.size) { inv.equip(slots[sel]); fixSel() }
                return
            }
            if (btnRect(r, 1).contains(x, y)) { inv.unequip(); return }
            if (btnRect(r, 2).contains(x, y)) { panelOpen = false }
        } else {
            for ((k, rec) in Inventory.RECIPES.withIndex()) {
                if (rowRect(r, k).contains(x, y)) { craft(rec); return }
            }
        }
    }

    // ---------- entrada táctil ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mapOpen) return worldMap.onTouch(e) { mapOpen = false }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (canRetry && message != null) {
                    canRetry = false; message = "Cargando…"; onRetry?.invoke()
                    return true
                }
                val idx = e.actionIndex
                val x = e.getX(idx); val y = e.getY(idx)
                if (world != null) {
                    if (deadT > 0f) return true
                    if (panelOpen) { handlePanelTouch(x, y); return true }
                    if (bagRect().contains(x, y)) { openPanel(); return true }
                    if (mapBtnRect().contains(x, y)) { openMap(); return true }
                    if (hypot(x - atkCx(), y - atkCy()) <= atkR() * 1.15f) { onAttack(); return true }
                    if (nearTree != null && hypot(x - srcCx(), y - srcCy()) <= srcR() * 1.2f) { onSearch(); return true }
                    if (nearStone != null && hypot(x - stoneCx(), y - stoneCy()) <= srcR() * 1.2f) { onStone(); return true }
                    if (nearFence && hypot(x - jumpCx(), y - jumpCy()) <= srcR() * 1.2f) { onJump(); return true }
                }
                if (joyId == -1 && x < width * 0.5f && !panelOpen) {
                    joyId = e.getPointerId(idx)
                    joyOx = x; joyOy = y; joyKx = x; joyKy = y
                    jx = 0f; jy = 0f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (joyId != -1) {
                    val i = e.findPointerIndex(joyId)
                    if (i >= 0) {
                        var dx = e.getX(i) - joyOx
                        var dy = e.getY(i) - joyOy
                        val d = hypot(dx, dy)
                        if (d > joyR) { dx = dx / d * joyR; dy = dy / d * joyR }
                        joyKx = joyOx + dx; joyKy = joyOy + dy
                        jx = dx / joyR; jy = dy / joyR
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (e.actionMasked == MotionEvent.ACTION_CANCEL || id == joyId) {
                    joyId = -1; jx = 0f; jy = 0f
                    joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
                }
            }
        }
        return true
    }
}
