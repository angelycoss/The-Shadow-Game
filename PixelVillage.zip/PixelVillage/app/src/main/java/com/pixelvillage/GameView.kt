package com.pixelvillage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val LOW_H = 180            // altura lógica del "pixel art"
private const val SPEED = 12f * PPM      // 12 m/s en px/s
private const val MAXH = 64f             // altura máxima de un objeto (para el culling)
private const val GROUND_LUM = 0.62f
private val BLACK = 0xFF000000.toInt()

// Paleta de 4 tonos: gris-morado oscuro -> crema
private val PAL = intArrayOf(
    0xFF2A2428.toInt(), 0xFF6F656B.toInt(), 0xFFB4AEB2.toInt(), 0xFFEAE9DB.toInt()
)
// Matriz Bayer 4x4 (umbrales para el dithering ordenado)
private val BAYER = FloatArray(16).also {
    val m = intArrayOf(0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5)
    for (i in 0 until 16) it[i] = (m[i] + 0.5f) / 16f
}

private fun gray(l: Float): Int {
    val v = (l.coerceIn(0f, 1f) * 255f).toInt()
    return Color.rgb(v, v, v)
}

class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {

    @Volatile var world: World? = null
    @Volatile var message: String? = "Cargando…"
    @Volatile private var canRetry = false
    var onRetry: (() -> Unit)? = null

    private var thread: Thread? = null
    @Volatile private var running = false

    // buffer de baja resolución
    private var W = 0
    private var H = 0
    private var scale = 1
    private var lo: Bitmap? = null
    private var loCanvas: Canvas? = null
    private var pix = IntArray(0)
    private var vig = FloatArray(0)
    private val dst = Rect()

    private val fill = Paint().apply { isAntiAlias = false; isDither = false; style = Paint.Style.FILL }
    private val stroke = Paint().apply {
        isAntiAlias = false; isDither = false; style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val bmpPaint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
    private val ui = Paint(Paint.ANTI_ALIAS_FLAG)

    // jugador
    @Volatile private var px = 0f
    @Volatile private var py = 0f
    private var moving = false
    private var walkT = 0f

    // joystick
    private val density = resources.displayMetrics.density
    private val joyR = 56f * density
    @Volatile private var jx = 0f
    @Volatile private var jy = 0f
    private var joyId = -1
    private var defX = 0f
    private var defY = 0f
    private var joyOx = 0f
    private var joyOy = 0f
    private var joyKx = 0f
    private var joyKy = 0f

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    // ---------- API pública ----------
    fun showMessage(msg: String) { message = msg; canRetry = false }
    fun showError(msg: String) { message = msg + "\n\nToca la pantalla para reintentar"; canRetry = true }
    fun loadWorld(w: World) {
        px = w.startX; py = w.startY
        world = w
        message = null
    }

    // ---------- ciclo de vida de la superficie ----------
    override fun surfaceCreated(h: SurfaceHolder) {}

    override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) {
        stopLoop()
        scale = max(1, (hh / LOW_H.toFloat()).roundToInt())
        W = ceil(w / scale.toFloat()).toInt()
        H = ceil(hh / scale.toFloat()).toInt()
        lo?.recycle()
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        lo = bmp
        loCanvas = Canvas(bmp)
        pix = IntArray(W * H)
        vig = buildVignette(W, H)
        dst.set(0, 0, W * scale, H * scale)
        defX = joyR * 1.7f; defY = hh - joyR * 1.7f
        joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
        startLoop()
    }

    override fun surfaceDestroyed(h: SurfaceHolder) { stopLoop() }

    private fun startLoop() {
        running = true
        thread = Thread(this, "game").also { it.start() }
    }

    private fun stopLoop() {
        running = false
        try { thread?.join(500) } catch (e: InterruptedException) { }
        thread = null
    }

    // ---------- bucle principal (~30 FPS) ----------
    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val t0 = System.nanoTime()
            val dt = min(0.1f, (t0 - last) / 1e9f)
            last = t0
            update(dt)
            val sh = holder
            if (sh.surface.isValid) {
                val c = try { sh.lockCanvas() } catch (e: Exception) { null }
                if (c != null) {
                    try { render(c) } finally { sh.unlockCanvasAndPost(c) }
                }
            }
            val spent = (System.nanoTime() - t0) / 1_000_000
            if (spent < 33) try { Thread.sleep(33 - spent) } catch (e: InterruptedException) { }
        }
    }

    private fun update(dt: Float) {
        val w = world ?: return
        val mx = jx; val my = jy
        val mag = hypot(mx, my)
        moving = mag > 0.12f
        if (!moving) return
        val sp = SPEED * dt * min(1f, mag)
        val dx = mx / mag * sp
        val dy = my / mag * sp
        if (!w.blocked(px + dx, py)) px += dx
        if (!w.blocked(px, py + dy)) py += dy
        walkT += dt
    }

    // ---------- render ----------
    private fun render(c: Canvas) {
        val lc = loCanvas ?: return
        val bmp = lo ?: return
        val w = world
        var cx = 0
        var cy = 0
        if (w != null) {
            cx = floor(px - W / 2f).toInt()
            cy = floor(py - H / 2f).toInt()
            drawWorld(lc, w, cx, cy)
        } else {
            lc.drawColor(gray(0.35f))
        }
        post(bmp, cx, cy)
        c.drawColor(BLACK)
        c.drawBitmap(bmp, null, dst, bmpPaint)
        drawUi(c)
    }

    private fun drawWorld(c: Canvas, w: World, cx: Int, cy: Int) {
        c.drawColor(gray(GROUND_LUM))
        c.save()
        c.translate(-cx.toFloat(), -cy.toFloat())
        val vx0 = cx.toFloat(); val vx1 = (cx + W).toFloat()
        val vy0 = cy.toFloat(); val vy1 = (cy + H).toFloat()

        // terreno
        fill.style = Paint.Style.FILL
        for (a in w.areas) {
            if (a.maxX < vx0 || a.minX > vx1 || a.maxY < vy0 || a.minY > vy1) continue
            fill.color = gray(K.LUM[a.kind])
            c.drawPath(a.path, fill)
            if (a.kind == K.WATER) {
                stroke.strokeWidth = 1.5f; stroke.color = gray(0.58f)
                c.drawPath(a.path, stroke)
            }
        }
        // ríos y arroyos
        for (r in w.waterLines) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width; stroke.color = gray(0.14f)
            c.drawPath(r.path, stroke)
        }
        // caminos: borde oscuro + interior claro
        for (r in w.roads) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width + 2f; stroke.color = gray(0.42f)
            c.drawPath(r.path, stroke)
        }
        for (r in w.roads) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width; stroke.color = gray(0.96f)
            c.drawPath(r.path, stroke)
        }

        val objs = w.objs
        val first = w.firstIndexAtY(vy0 - 6f)
        val maxY = vy1 + MAXH

        // sombras (semitransparentes, oscurecen lo que hay debajo)
        fill.color = Color.argb(95, 0, 0, 0)
        var i = first
        while (i < objs.size && objs[i].y <= maxY) {
            val o = objs[i]
            val b = o.b
            if (b != null) {
                if (!(b.minX > vx1 || b.maxX + b.h < vx0)) c.drawPath(b.shadow, fill)
            } else if (o.x > vx0 - 30f && o.x < vx1 + 30f) {
                c.save(); c.translate(o.x, o.y); c.drawPath(Sprites.treeShadow, fill); c.restore()
            }
            i++
        }

        // objetos ordenados por profundidad, con el jugador intercalado
        var playerDone = false
        i = first
        while (i < objs.size && objs[i].y <= maxY) {
            val o = objs[i]
            if (!playerDone && o.y > py) { drawPlayer(c); playerDone = true }
            val b = o.b
            if (b != null) {
                if (!(b.maxX < vx0 || b.minX > vx1 || b.maxY < vy0 || b.minY - b.h > vy1)) drawBuilding(c, b)
            } else if (o.x > vx0 - 8f && o.x < vx1 + 8f) {
                c.save(); c.translate(o.x, o.y)
                fill.color = gray(0.05f)
                c.drawPath(if (o.variant % 3 == 0) Sprites.treeSmall else Sprites.treeBig, fill)
                c.restore()
            }
            i++
        }
        if (!playerDone) drawPlayer(c)
        c.restore()
    }

    private fun drawBuilding(c: Canvas, b: Building) {
        fill.color = gray(0.10f); c.drawPath(b.wallA, fill)
        fill.color = gray(0.26f); c.drawPath(b.wallB, fill)
        fill.color = gray(1f); c.drawPath(b.windows, fill)
        c.save()
        c.translate(0f, -b.h)
        fill.color = gray(0.86f); c.drawPath(b.roof, fill)
        stroke.strokeWidth = 1f; stroke.color = gray(0.15f); c.drawPath(b.roof, stroke)
        c.restore()
    }

    private fun drawPlayer(c: Canvas) {
        val x = px.toInt().toFloat()
        val y = py.toInt().toFloat()
        fill.color = Color.argb(110, 0, 0, 0)
        c.drawRect(x - 2f, y - 1f, x + 6f, y + 1f, fill)          // sombra
        fill.color = gray(1f)
        c.drawRect(x - 3f, y - 11f, x + 3f, y + 1f, fill)         // contorno claro (legibilidad)
        fill.color = gray(0.03f)
        c.drawRect(x - 1f, y - 10f, x + 1f, y - 7f, fill)         // cabeza
        c.drawRect(x - 2f, y - 7f, x + 2f, y - 3f, fill)          // cuerpo
        val step = moving && ((walkT * 8f).toInt() and 1) == 0
        val l = if (step) y - 1f else y
        val r = if (step || !moving) y else y - 1f
        c.drawRect(x - 2f, y - 3f, x - 0.5f, l, fill)             // piernas
        c.drawRect(x + 0.5f, y - 3f, x + 2f, r, fill)
    }

    /** Posproceso: viñeta + ruido + dithering Bayer a la paleta de 4 tonos + esquinas redondeadas. */
    private fun post(bmp: Bitmap, camX: Int, camY: Int) {
        bmp.getPixels(pix, 0, W, 0, 0, W, H)
        var i = 0
        for (y in 0 until H) {
            val wy = y + camY
            val row = (wy and 3) shl 2
            for (x in 0 until W) {
                val v = vig[i]
                if (v < 0f) {
                    pix[i] = BLACK
                } else {
                    val wx = x + camX     // el patrón se ancla al mundo: no "nada" al caminar
                    val n = (((wx * 73856093) xor (wy * 19349663)) ushr 9) and 15
                    var l = (pix[i] and 0xFF) * (1f / 255f) * v + (n - 7.5f) * 0.0075f
                    if (l < 0f) l = 0f else if (l > 1f) l = 1f
                    val t = l * 3f
                    var idx = t.toInt()
                    if (t - idx > BAYER[row + (wx and 3)]) idx++
                    pix[i] = PAL[if (idx > 3) 3 else idx]
                }
                i++
            }
        }
        bmp.setPixels(pix, 0, W, 0, 0, W, H)
    }

    private fun buildVignette(w: Int, h: Int): FloatArray {
        val a = FloatArray(w * h)
        val r = min(w, h) * 0.08f
        for (y in 0 until h) for (x in 0 until w) {
            val nx = (x + 0.5f - w / 2f) / (w / 2f)
            val ny = (y + 0.5f - h / 2f) / (h / 2f)
            var v = 1f - 0.30f * (nx * nx + ny * ny)
            if (v < 0.25f) v = 0.25f
            val cx = if (x < r) r else if (x > w - r) w - r else x.toFloat()
            val cy = if (y < r) r else if (y > h - r) h - r else y.toFloat()
            if (cx != x.toFloat() || cy != y.toFloat()) {
                val dx = x - cx; val dy = y - cy
                if (dx * dx + dy * dy > r * r) v = -1f
            }
            a[y * w + x] = v
        }
        return a
    }

    private fun drawUi(c: Canvas) {
        // joystick
        ui.style = Paint.Style.FILL; ui.color = Color.argb(46, 234, 233, 219)
        c.drawCircle(joyOx, joyOy, joyR, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 3f * density; ui.color = Color.argb(150, 234, 233, 219)
        c.drawCircle(joyOx, joyOy, joyR, ui)
        ui.style = Paint.Style.FILL; ui.color = Color.argb(170, 234, 233, 219)
        c.drawCircle(joyKx, joyKy, joyR * 0.42f, ui)

        // mensajes (carga / error)
        val msg = message ?: return
        ui.style = Paint.Style.FILL
        ui.typeface = Typeface.MONOSPACE
        ui.textAlign = Paint.Align.CENTER
        ui.textSize = 15f * density
        ui.color = Color.rgb(234, 233, 219)
        var y = height / 2f - (msg.count { it == '\n' }) * ui.textSize * 0.6f
        for (line in msg.split("\n")) {
            c.drawText(line, width / 2f, y, ui)
            y += ui.textSize * 1.3f
        }
    }

    // ---------- entrada táctil ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (canRetry && message != null) {
                    canRetry = false; message = "Cargando…"; onRetry?.invoke()
                    return true
                }
                val idx = e.actionIndex
                val x = e.getX(idx); val y = e.getY(idx)
                if (joyId == -1 && x < width * 0.5f) {
                    joyId = e.getPointerId(idx)
                    joyOx = x; joyOy = y; joyKx = x; joyKy = y
                    jx = 0f; jy = 0f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (joyId != -1) {
                    val i = e.findPointerIndex(joyId)
                    if (i >= 0) {
                        var dx = e.getX(i) - joyOx
                        var dy = e.getY(i) - joyOy
                        val d = hypot(dx, dy)
                        if (d > joyR) { dx = dx / d * joyR; dy = dy / d * joyR }
                        joyKx = joyOx + dx; joyKy = joyOy + dy
                        jx = dx / joyR; jy = dy / joyR
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (e.actionMasked == MotionEvent.ACTION_CANCEL || id == joyId) {
                    joyId = -1; jx = 0f; jy = 0f
                    joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
                }
            }
        }
        return true
    }
}
