package com.pixelvillage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Path
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

private const val LOW_H = 180            // altura lógica del "pixel art"
private const val SPEED = 12f * PPM      // 12 m/s en px/s (sobre camino)
private const val MAXH = 64f             // altura máxima de un objeto (para el culling)
private const val GROUND_LUM = 0.62f
private const val WIND_PX = 75f          // velocidad base del viento (px/s)
private const val PN = 70                // partículas de viento
private const val ATK_DUR = 0.28f        // duración del golpe (s)
private const val REACH = 14f            // alcance para interactuar (px)
private const val CHOP_HITS = 4          // golpes de hacha para talar un árbol
private const val ROOM_TOP = 26f       // alto de la pared del fondo en los interiores
private const val JUMP_DUR = 0.55f       // duración del salto (s)
private const val BOIL_TIME = 6f          // segundos que tarda en hervir el agua
private const val A_PILE = 0
private const val A_GATHER = 1
private const val A_HARVEST = 2
private const val A_FILL = 3
private const val A_BOIL = 4
private const val A_SOW = 5
private const val SWIM_LIMIT = 180f      // segundos seguidos en el agua antes de ahogarte (3 min)
private const val ROW = 5f               // separación entre surcos de cultivo (px)
private const val PLANT = 3f             // separación entre matas de trigo (px)
private const val TN = 16                // puntos del rastro del jugador (el trigo se dobla al pasar)
private val BLACK = 0xFF000000.toInt()
private val CREAM = Color.rgb(234, 233, 219)
private val MIDGRAY = 0xFF6F656B.toInt()
private val LIGHTGRAY = 0xFFB4AEB2.toInt()

// Paleta de 4 tonos: gris-morado oscuro -> crema
private val PAL = intArrayOf(
    0xFF2A2428.toInt(), 0xFF6F656B.toInt(), 0xFFB4AEB2.toInt(), 0xFFEAE9DB.toInt()
)
// Matriz Bayer 4x4 (umbrales para el dithering ordenado)
private val BAYER = FloatArray(16).also {
    val m = intArrayOf(0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5)
    for (i in 0 until 16) it[i] = (m[i] + 0.5f) / 16f
}

private fun gray(l: Float): Int {
    val v = (l.coerceIn(0f, 1f) * 255f).toInt()
    return Color.rgb(v, v, v)
}

private fun hash2(a: Int, b: Int): Int {
    var h = a * 374761393 + b * 668265263 + 1013904223
    h = (h xor (h ushr 13)) * 1274126177
    return h xor (h ushr 16)
}

class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {

    @Volatile var world: World? = null
    @Volatile var message: String? = "Cargando…"
    @Volatile private var canRetry = false
    var onRetry: (() -> Unit)? = null
    var onChoose: ((Int) -> Unit)? = null
    private val prefs = ctx.getSharedPreferences("pv", Context.MODE_PRIVATE)
    @Volatile private var menuOpen = true                // pantalla de inicio: elegir pueblo
    @Volatile var chosenTown = prefs.getInt("spawn_town", 0)

    private var thread: Thread? = null
    @Volatile private var running = false

    // buffer de baja resolución
    private var W = 0
    private var H = 0
    private var scale = 1
    private var lo: Bitmap? = null
    private var loCanvas: Canvas? = null
    private var pix = IntArray(0)
    private var vig = FloatArray(0)
    private val verText: String = try { "v" + ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "" }
    private val dst = Rect()

    private val fill = Paint().apply { isAntiAlias = false; isDither = false; style = Paint.Style.FILL }
    private val stroke = Paint().apply {
        isAntiAlias = false; isDither = false; style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val bmpPaint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
    private val ui = Paint(Paint.ANTI_ALIAS_FLAG)

    // jugador
    @Volatile private var px = 0f
    @Volatile private var py = 0f
    private var moving = false
    private var walkT = 0f
    private var swimming = false
    private var faceA = 0f               // hacia dónde mira (rad, 0 = este)
    private var atkT = 0f                // >0 mientras dura el golpe
    @Volatile private var actCd = 0f     // enfriamiento de acciones
    @Volatile private var jumpT = 0f     // >0 mientras dura el salto
    private var jumpDx = 0f
    private var jumpDy = 0f
    @Volatile private var nearFence = false
    private var mud = false              // piernas hundidas en el fango
    // interior de una casa (espacio propio, mucho más grande que el edificio visto desde fuera)
    private var room: Building? = null
    private var rW = 0f; private var rH = 0f      // tamaño de la sala
    private var rx = 0f; private var ry = 0f      // posición del jugador dentro de la sala
    private var retX = 0f; private var retY = 0f  // dónde reaparece fuera al salir
    // supervivencia
    private var sickT = 0f               // enfermo por agua sin hervir (gasta el doble de agua)
    private var boilT = 0f               // >0 mientras hierve agua
    private var saveAcc = 0f
    private var thirstWarn = 0
    private var deathTitle = "Te ahogaste"
    private var deathSub = "El cansancio de nadar te venció"
    private var bagScroll = 0
    private var craftScroll = 0
    private class Ctx(val label: String, val act: Int)
    @Volatile private var ctxList: List<Ctx> = emptyList()
    @Volatile private var nearPlant: Obj? = null
    @Volatile private var nearCrop: Planted? = null
    @Volatile private var nearPile: Pile? = null
    private var nearWater = false
    private var nearFire = false
    private var swimT = 0f               // segundos seguidos en el agua
    private var swimWarn = 0
    @Volatile private var deadT = 0f     // >0 mientras se muestra "te ahogaste"
    private var gameT = 0f
    // rastro del jugador: el trigo se dobla donde has pasado hace poco
    private val trailX = FloatArray(TN)
    private val trailY = FloatArray(TN)
    private val trailTm = FloatArray(TN) { -100f }
    private var trailI = 0
    private var trailAcc = 0f
    private var tbx0 = 1e9f; private var tby0 = 1e9f; private var tbx1 = -1e9f; private var tby1 = -1e9f
    private var bendLean = 0f
    private var bendSq = 0f
    private val spire = Path()
    private val tie = Paint().apply {
        isAntiAlias = false; style = Paint.Style.STROKE; strokeWidth = 6f
        pathEffect = DashPathEffect(floatArrayOf(1.3f, 3.2f), 0f)
    }

    // inventario e interacción
    private val inv = Inventory(ctx.getSharedPreferences("pv", Context.MODE_PRIVATE))
    @Volatile private var nearTree: Obj? = null
    @Volatile private var nearStone: Obj? = null
    private val chop = HashMap<Long, Int>()          // golpes recibidos por árbol (no se guarda)
    private val lootRnd = java.util.Random()
    private var shakeObj: Obj? = null
    private var shakeT = 0f
    @Volatile private var toast: String? = null
    @Volatile private var toastT = 0f
    @Volatile private var panelOpen = false
    @Volatile private var mapOpen = false             // pantalla del mapa del mundo
    private val worldMap = WorldMap(ctx)
    @Volatile private var panelTab = 0           // 0 = Bolsa, 1 = Crear
    @Volatile private var sel = 0

    // viento y partículas
    private var windT = 0f
    private var windS = 0.5f        // intensidad 0..1
    private var windA = 0f          // ángulo en radianes (0 = hacia el este)
    private val pX = FloatArray(PN)
    private val pY = FloatArray(PN)
    private val pPh = FloatArray(PN)
    private val pSp = FloatArray(PN)
    private var pInit = false
    private val rnd = java.util.Random(7)

    // joystick
    private val density = resources.displayMetrics.density
    private val joyR = 56f * density
    @Volatile private var jx = 0f
    @Volatile private var jy = 0f
    private var joyId = -1
    private var defX = 0f
    private var defY = 0f
    private var joyOx = 0f
    private var joyOy = 0f
    private var joyKx = 0f
    private var joyKy = 0f

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    // ---------- API pública ----------
    fun showMessage(msg: String) { message = msg; canRetry = false }
    fun showError(msg: String) { message = msg + "\n\nToca la pantalla para reintentar"; canRetry = true }
    fun loadWorld(w: World) {
        px = w.startX; py = w.startY
        val old = world
        world = w
        old?.close()
        message = null
    }

    // ---------- ciclo de vida de la superficie ----------
    override fun surfaceCreated(h: SurfaceHolder) {}

    override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) {
        stopLoop()
        scale = max(1, (hh / LOW_H.toFloat()).roundToInt())
        W = ceil(w / scale.toFloat()).toInt()
        H = ceil(hh / scale.toFloat()).toInt()
        lo?.recycle()
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        lo = bmp
        loCanvas = Canvas(bmp)
        pix = IntArray(W * H)
        vig = buildVignette(W, H)
        dst.set(0, 0, W * scale, H * scale)
        defX = joyR * 1.7f; defY = hh - joyR * 1.7f
        joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
        pInit = false
        startLoop()
    }

    override fun surfaceDestroyed(h: SurfaceHolder) { stopLoop() }

    private fun startLoop() {
        running = true
        thread = Thread(this, "game").also { it.start() }
    }

    private fun stopLoop() {
        running = false
        try { thread?.join(500) } catch (e: InterruptedException) { }
        thread = null
    }

    // ---------- bucle principal (~30 FPS) ----------
    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val t0 = System.nanoTime()
            val dt = min(0.1f, (t0 - last) / 1e9f)
            last = t0
            update(dt)
            val sh = holder
            if (sh.surface.isValid) {
                val c = try { sh.lockCanvas() } catch (e: Exception) { null }
                if (c != null) {
                    try { render(c) } finally { sh.unlockCanvasAndPost(c) }
                }
            }
            val spent = (System.nanoTime() - t0) / 1_000_000
            if (spent < 33) try { Thread.sleep(33 - spent) } catch (e: InterruptedException) { }
        }
    }

    private fun stonesLeft(o: Obj): Int {
        val k = Inventory.keyOf(o)
        return Inventory.stonesIn(k) - (inv.stoneTaken[k] ?: 0)
    }

    private fun update(dt: Float) {
        val w = world ?: return
        if (mapOpen) return          // el juego se pausa mientras miras el mapa
        w.focus(px, py)          // el mundo descarga las zonas vecinas a medida que exploras

        // viento: intensidad y dirección que cambian suavemente
        windT += dt
        windS = (0.5f + 0.32f * sin(windT * 0.7f) + 0.18f * sin(windT * 1.9f + 1.3f)).coerceIn(0.05f, 1f)
        windA = 0.4f * sin(windT * 0.11f)
        val wvx = cos(windA) * WIND_PX * windS
        val wvy = sin(windA) * WIND_PX * windS * 0.5f

        // temporizadores
        if (actCd > 0f) actCd -= dt
        if (atkT > 0f) atkT -= dt
        if (shakeT > 0f) shakeT -= dt
        if (toastT > 0f) { toastT -= dt; if (toastT <= 0f) toast = null }
        gameT += dt
        if (jumpT > 0f) jumpT -= dt

        // te ahogaste: pausa breve y reapareces en el punto de inicio
        if (deadT > 0f) {
            deadT -= dt
            if (deadT <= 0f) { px = w.startX; py = w.startY; swimT = 0f; swimWarn = 0; jumpT = 0f }
            return
        }

        updateSurvival(dt)
        if (deadT > 0f) return
        if (room != null) { updateRoom(dt); return }

        // jugador
        val mx = jx; val my = jy
        val mag = if (panelOpen) 0f else hypot(mx, my)
        moving = mag > 0.12f
        swimming = w.inWater(px, py)
        mud = !swimming && w.inMud(px, py)
        nearFence = w.nearFence(px, py, 10f)
        if (jumpT > 0f) {
            // salto: avanzas en la dirección en que saltaste, por encima de las cercas
            val sp = SPEED * dt
            val sx = jumpDx * sp; val sy = jumpDy * sp
            if (!w.blockedMove(px, py, px + sx, py, true)) px += sx
            if (!w.blockedMove(px, py, px, py + sy, true)) py += sy
            walkT += dt
        } else if (moving) {
            faceA = atan2(my, mx)
            // camino: 100 %, campo: 80 %, agua: 50 %, fango: 20 %
            val sp = SPEED * w.speedFactorAt(px, py) * inv.loadSpeed() * dt * min(1f, mag)
            val dx = mx / mag * sp
            val dy = my / mag * sp
            if (!w.blockedMove(px, py, px + dx, py, false)) px += dx
            if (!w.blockedMove(px, py, px, py + dy, false)) py += dy
            walkT += dt
            // al borde de lo descargado: avisa por qué no se puede seguir
            if (toast == null) w.edgeNote(px + dx * 3f, py + dy * 3f)?.let { showToast(it) }
        }
        // nadar cansa: a los 3 minutos seguidos en el agua te ahogas
        if (swimming) {
            swimT += dt
            if (swimT >= SWIM_LIMIT) { deadT = 3.5f; deathTitle = "Te ahogaste"; deathSub = "El cansancio de nadar te venció"; jx = 0f; jy = 0f; moving = false }
            else if (swimT >= 165f && swimWarn < 2) { swimWarn = 2; showToast("¡No puedes más! Sal del agua") }
            else if (swimT >= 120f && swimWarn < 1) { swimWarn = 1; showToast("Te estás cansando de nadar…") }
        } else { swimT = 0f; swimWarn = 0 }

        // rastro para que el trigo se doble al pasar
        trailAcc += dt
        if ((moving || jumpT > 0f) && trailAcc >= 0.06f) {
            trailAcc = 0f
            trailI = (trailI + 1) % TN
            trailX[trailI] = px; trailY[trailI] = py; trailTm[trailI] = gameT
        }
        var bx0 = 1e9f; var by0 = 1e9f; var bx1 = -1e9f; var by1 = -1e9f
        for (k in 0 until TN) if (gameT - trailTm[k] < 1.2f) {
            bx0 = min(bx0, trailX[k]); bx1 = max(bx1, trailX[k]); by0 = min(by0, trailY[k]); by1 = max(by1, trailY[k])
        }
        tbx0 = bx0 - 10f; tby0 = by0 - 10f; tbx1 = bx1 + 10f; tby1 = by1 + 10f

        if (jumpT <= 0f && !swimming) w.buildingAt(px, py)?.let { enterRoom(it); return }

        nearTree = w.nearest(px, py, REACH) { it.kind == KIND_TREE && !inv.felled.contains(Inventory.keyOf(it)) }
        nearStone = w.nearest(px, py, REACH) { it.kind == KIND_STONE && stonesLeft(it) > 0 }
        computeContext(w)

        // partículas: se envuelven alrededor de la cámara
        if (W > 0) {
            val vx0 = floor(px - W / 2f)
            val vy0 = floor(py - H / 2f)
            if (!pInit) {
                for (i in 0 until PN) {
                    pX[i] = vx0 + rnd.nextFloat() * W
                    pY[i] = vy0 + rnd.nextFloat() * H
                    pPh[i] = rnd.nextFloat() * 6.28f
                    pSp[i] = 0.7f + rnd.nextFloat() * 0.8f
                }
                pInit = true
            }
            val m = 10f
            val spanX = W + 2 * m
            val spanY = H + 2 * m
            for (i in 0 until PN) {
                pX[i] += wvx * pSp[i] * dt
                pY[i] += (wvy * pSp[i] + sin(windT * 2.3f + pPh[i]) * 9f) * dt
                if (pX[i] < vx0 - m) pX[i] += spanX else if (pX[i] > vx0 + W + m) pX[i] -= spanX
                if (pY[i] < vy0 - m) pY[i] += spanY else if (pY[i] > vy0 + H + m) pY[i] -= spanY
            }
        }
    }


    // ---------- interiores ----------
    private fun enterRoom(b: Building) {
        room = b
        rW = ((b.maxX - b.minX) * 3f).coerceIn(150f, 340f)
        rH = ((b.maxY - b.minY) * 3f).coerceIn(120f, 260f)
        rx = 0f; ry = rH / 2f - 8f
        retX = b.doorMx + b.doorNx * 8f; retY = b.doorMy + b.doorNy * 8f
        faceA = -Math.PI.toFloat() / 2f
        swimming = false; mud = false; nearFence = false; nearTree = null; nearStone = null
        jx = 0f; jy = 0f
    }

    private fun roomOk(x: Float, y: Float): Boolean {
        if (x < -rW / 2f + 5f || x > rW / 2f - 5f) return false
        if (y < -rH / 2f + ROOM_TOP) return false
        val maxY = if (abs(x) < 7f) rH / 2f + 2f else rH / 2f - 4f
        return y <= maxY
    }

    private fun updateRoom(dt: Float) {
        val b = room ?: return
        ctxList = emptyList(); nearPlant = null; nearCrop = null; nearPile = null
        swimming = false; mud = false; nearFence = false; nearTree = null; nearStone = null
        val mag = if (panelOpen) 0f else hypot(jx, jy)
        moving = mag > 0.12f
        if (moving) {
            faceA = atan2(jy, jx)
            val sp = SPEED * inv.loadSpeed() * dt * min(1f, mag)
            val nx = rx + jx / mag * sp
            val ny = ry + jy / mag * sp
            if (roomOk(nx, ry)) rx = nx
            if (roomOk(rx, ny)) ry = ny
            walkT += dt
        }
        if (ry >= rH / 2f - 1f && abs(rx) < 8f) {          // cruzó la puerta: sale a la calle
            px = retX; py = retY
            faceA = atan2(b.doorNy, b.doorNx)
            room = null
            jx = 0f; jy = 0f
        }
    }

    /** Vista de interior: todo lo de fuera en negro, solo se ve la sala. */
    private fun drawRoom(c: Canvas, cx: Int, cy: Int) {
        c.drawColor(BLACK)
        c.save()
        c.translate(-cx.toFloat(), -cy.toFloat())
        fill.style = Paint.Style.FILL
        val l = -rW / 2f; val r = rW / 2f; val t = -rH / 2f; val bt = rH / 2f
        // suelo de tablas
        fill.color = gray(0.60f); c.drawRect(l, t + ROOM_TOP, r, bt, fill)
        var row = 0
        var y = t + ROOM_TOP
        while (y < bt) {
            fill.color = gray(0.46f); c.drawRect(l, y, r, y + 1f, fill)
            var x = l + ((row * 17) % 26)
            while (x < r) { fill.color = gray(0.50f); c.drawRect(x, y, x + 1f, y + 8f, fill); x += 26f }
            y += 8f; row++
        }
        // pared del fondo con ventanas
        fill.color = gray(0.22f); c.drawRect(l - 5f, t - 5f, r + 5f, t + ROOM_TOP, fill)
        fill.color = gray(0.10f); c.drawRect(l - 5f, t + ROOM_TOP - 3f, r + 5f, t + ROOM_TOP, fill)
        var wx = l + 22f
        while (wx < r - 12f) {
            fill.color = gray(0.05f); c.drawRect(wx - 7f, t + 5f, wx + 7f, t + 17f, fill)
            fill.color = gray(0.92f); c.drawRect(wx - 6f, t + 6f, wx + 6f, t + 16f, fill)
            fill.color = gray(0.05f); c.drawRect(wx - 0.5f, t + 6f, wx + 0.5f, t + 16f, fill)
            wx += 46f
        }
        // paredes laterales y pared delantera con hueco de puerta
        fill.color = gray(0.16f)
        c.drawRect(l - 5f, t, l, bt + 5f, fill)
        c.drawRect(r, t, r + 5f, bt + 5f, fill)
        c.drawRect(l - 5f, bt, -8f, bt + 5f, fill)
        c.drawRect(8f, bt, r + 5f, bt + 5f, fill)
        fill.color = gray(0.95f); c.drawRect(-8f, bt, 8f, bt + 2f, fill)   // umbral de la puerta
        c.restore()
        val sx = px; val sy = py
        c.save(); c.translate(-cx.toFloat(), -cy.toFloat())
        px = rx; py = ry
        drawPlayer(c)
        px = sx; py = sy
        c.restore()
    }

    // ---------- acciones del jugador ----------
    private fun showToast(msg: String) { toast = msg; toastT = 2.0f }

    /** Saltar una cerca: avanzas por encima en la dirección que empujas (o hacia donde miras). */
    private fun onJump() {
        if (jumpT > 0f || panelOpen || deadT > 0f || !nearFence) return
        val m = hypot(jx, jy)
        if (m > 0.12f) { jumpDx = jx / m; jumpDy = jy / m } else { jumpDx = cos(faceA); jumpDy = sin(faceA) }
        faceA = atan2(jumpDy, jumpDx)
        jumpT = JUMP_DUR
    }

    /** Golpe con lo que lleves en la mano. Con hacha, junto a un árbol, lo talas. */
    private fun onAttack() {
        if (actCd > 0f || panelOpen) return
        atkT = ATK_DUR
        actCd = 0.45f
        val t = nearTree ?: return
        shakeObj = t; shakeT = 0.5f
        if (inv.hand != Items.AXE) {
            showToast("Necesitas un hacha para talar")
            return
        }
        val key = Inventory.keyOf(t)
        val hits = (chop[key] ?: 0) + 1
        if (hits >= CHOP_HITS) {
            chop.remove(key)
            inv.felled.add(key)
            val leaves = 1 + lootRnd.nextInt(3)
            var dropped = false
            repeat(2) { if (inv.canAdd(Items.LOG)) inv.counts[Items.LOG]++ else { inv.drop(px, py, Items.LOG, 1); dropped = true } }
            repeat(leaves) { if (inv.canAdd(Items.LEAF)) inv.counts[Items.LEAF]++ else { inv.drop(px, py, Items.LEAF, 1); dropped = true } }
            inv.save()
            showToast(if (dropped) "¡Talado! Pesa demasiado: parte quedó en el suelo" else "¡Talado!  +2 Troncos  +$leaves Hojas")
        } else {
            chop[key] = hits
        }
    }

    /** Rebuscar en el árbol: palos y, en los pinos, piñas y hojas de pino. */
    private fun onSearch() {
        if (actCd > 0f || panelOpen) return
        val t = nearTree ?: return
        actCd = 0.5f
        shakeObj = t; shakeT = 0.5f
        val key = Inventory.keyOf(t)
        val list = Inventory.treeYield(t)
        val got = inv.taken[key] ?: 0
        if (got < list.size) {
            val id = list[got]
            if (!inv.canAdd(id)) { showToast("Llevas demasiado peso"); return }
            inv.taken[key] = got + 1
            inv.counts[id]++
            inv.save()
            showToast("+1 ${Items.NAMES[id]}")
        } else {
            showToast("Este árbol ya no tiene nada")
        }
    }

    /** Rebuscar piedras en el suelo, junto a las que se ven. */
    private fun onStone() {
        if (actCd > 0f || panelOpen) return
        val s = nearStone ?: return
        actCd = 0.5f
        val key = Inventory.keyOf(s)
        val got = inv.stoneTaken[key] ?: 0
        if (got < Inventory.stonesIn(key)) {
            if (!inv.canAdd(Items.STONE)) { showToast("Llevas demasiado peso"); return }
            inv.stoneTaken[key] = got + 1
            inv.counts[Items.STONE]++
            inv.save()
            showToast("+1 Piedra")
        }
    }

    // ---------- supervivencia ----------
    private fun fmt(x: Float): String = ((x * 10f).roundToInt() / 10f).toString()

    private fun updateSurvival(dt: Float) {
        val active = moving || jumpT > 0f || swimming
        val rate = (if (active) 0.09f else 0.025f) * (if (sickT > 0f) 2f else 1f)
        if (sickT > 0f) sickT -= dt
        if (inv.water > 0f) {
            inv.water = max(0f, inv.water - rate * dt)
            if (inv.body < 100f && inv.water > 30f) inv.body = min(100f, inv.body + 0.3f * dt)
            if (inv.water <= 0f) { thirstWarn = 2; showToast("¡Sin agua! Tu cuerpo empieza a secarse") }
            else if (inv.water < 20f && thirstWarn < 1) { thirstWarn = 1; showToast("Tienes mucha sed") }
        } else {
            inv.body = max(0f, inv.body - 0.2f * dt)
            if (inv.body <= 0f) { thirstDeath(); return }
        }
        if (inv.water > 40f) thirstWarn = 0
        // el agua hervida del cuenco se bebe sola cuando hace falta
        if (inv.water <= 55f && inv.counts[Items.BOWL_CLEAN] > 0) {
            inv.counts[Items.BOWL_CLEAN]--; inv.counts[Items.BOWL]++
            inv.water = min(100f, inv.water + 35f)
            showToast("Bebes agua del cuenco")
            inv.save(); fixSel()
        }
        if (boilT > 0f) {
            if (!nearFire || inv.counts[Items.BOWL_DIRTY] <= 0 || room != null) { boilT = 0f; showToast("Te alejaste del fuego") }
            else {
                boilT -= dt
                if (boilT <= 0f) finishBoil()
            }
        }
        saveAcc += dt
        if (saveAcc >= 15f) { saveAcc = 0f; inv.save() }
    }

    private fun thirstDeath() {
        val dx = if (room != null) retX else px
        val dy = if (room != null) retY else py
        inv.dropAll(dx, dy)
        room = null
        boilT = 0f; sickT = 0f; thirstWarn = 0
        deathTitle = "Moriste de sed"
        deathSub = "Tus cosas quedaron en el suelo donde caíste"
        deadT = 3.5f; jx = 0f; jy = 0f; moving = false
    }

    private fun finishBoil() {
        inv.counts[Items.BOWL_DIRTY]--
        inv.bowlWear++
        if (inv.bowlWear >= 3) {
            inv.bowlWear = 0
            showToast("¡El cuenco se quemó y el agua se perdió!")
        } else {
            inv.counts[Items.BOWL_CLEAN]++
            showToast("Agua hervida lista (el cuenco aguanta ${3 - inv.bowlWear} más)")
        }
        inv.save(); fixSel()
    }

    private fun plantLeft(o: Obj): Int = Inventory.yieldOf(o).size - (inv.taken[Inventory.harvKey(o)] ?: 0)

    private fun seedToSow(): Int {
        val slots = inv.slots()
        if (sel < slots.size && Items.isSeed(slots[sel])) return slots[sel]
        return slots.firstOrNull { Items.isSeed(it) } ?: -1
    }

    /** Qué acciones del entorno hay disponibles ahora (botones redondos a la derecha). */
    private fun computeContext(w: World) {
        nearPlant = w.nearest(px, py, REACH) { it.kind in KIND_REED..KIND_TOBACCO && plantLeft(it) > 0 }
        var bd = 14f * 14f
        var crop: Planted? = null
        for (p in inv.planted) { val dx = p.x - px; val dy = p.y - py; val d = dx * dx + dy * dy; if (d < bd) { bd = d; crop = p } }
        nearCrop = crop
        bd = 16f * 16f
        var pile: Pile? = null
        for (p in inv.piles) { val dx = p.x - px; val dy = p.y - py; val d = dx * dx + dy * dy; if (d < bd) { bd = d; pile = p } }
        nearPile = pile
        nearWater = w.inWater(px, py)
        if (!nearWater) {
            for (k in 0 until 8) {
                val a = k * 0.785f
                if (w.inWater(px + cos(a) * 12f, py + sin(a) * 12f)) { nearWater = true; break }
            }
        }
        var fireNear = false
        for (f in inv.fires) if (hypot(f[0] - px, f[1] - py) <= 18f) { fireNear = true; break }
        nearFire = fireNear
        val l = ArrayList<Ctx>()
        if (pile != null) l.add(Ctx("Bulto", A_PILE))
        if (nearPlant != null) l.add(Ctx("Coger", A_GATHER))
        if (crop != null) l.add(Ctx("Cosechar", A_HARVEST))
        if (nearWater && inv.counts[Items.BOWL] > 0) l.add(Ctx("Llenar", A_FILL))
        if (fireNear && inv.counts[Items.BOWL_DIRTY] > 0) l.add(Ctx(if (boilT > 0f) "Hirviendo" else "Hervir", A_BOIL))
        var canSow = !swimming && !mud && seedToSow() >= 0 && w.canPlant(px, py)
        if (canSow) for (p in inv.planted) if (abs(p.x - px) < 9f && abs(p.y - py) < 9f) { canSow = false; break }
        if (canSow) l.add(Ctx("Sembrar", A_SOW))
        ctxList = if (l.size > 4) l.subList(0, 4).toList() else l
    }

    private fun onCtx(act: Int) {
        if (panelOpen || deadT > 0f || room != null) return
        when (act) {
            A_PILE -> onPile()
            A_GATHER -> onGather()
            A_HARVEST -> onHarvest()
            A_FILL -> onFill()
            A_BOIL -> if (boilT <= 0f) { boilT = BOIL_TIME; showToast("Hirviendo el agua…") }
            A_SOW -> onSow()
        }
    }

    private fun onGather() {
        if (actCd > 0f) return
        val o = nearPlant ?: return
        actCd = 0.4f
        shakeObj = o; shakeT = 0.4f
        val list = Inventory.yieldOf(o)
        val key = Inventory.harvKey(o)
        val got = inv.taken[key] ?: 0
        if (got >= list.size) { showToast("Ya no queda nada"); return }
        val id = list[got]
        if (!inv.canAdd(id)) { showToast("Llevas demasiado peso"); return }
        inv.taken[key] = got + 1
        inv.counts[id]++
        inv.save()
        showToast("+1 ${Items.NAMES[id]}")
    }

    private fun onSow() {
        if (actCd > 0f) return
        val id = seedToSow()
        if (id < 0) return
        actCd = 0.5f
        val type = Items.cropOfSeed(id)
        inv.counts[id]--
        inv.plant(px, py, type)
        showToast("Sembraste ${Items.CROP_NAMES[type]} (~${Items.CROP_SECS[type] / 60} min)")
        fixSel()
    }

    private fun onHarvest() {
        if (actCd > 0f) return
        val p = nearCrop ?: return
        actCd = 0.5f
        val need = Items.CROP_SECS[p.type]
        val secs = (System.currentTimeMillis() - p.t0) / 1000f
        if (secs < need) { showToast("Aún no está lista: faltan ~${ceil((need - secs) / 60f).toInt()} min"); return }
        val y = ArrayList<Int>()
        when (p.type) {
            in 0..6 -> { y.add(Items.VEG0 + p.type); y.add(Items.VEG0 + p.type); y.add(Items.SEED0 + p.type); if (lootRnd.nextBoolean()) y.add(Items.SEED0 + p.type) }
            7 -> repeat(4) { y.add(Items.CHERRY) }
            else -> { y.add(Items.TOBACCO_LEAF); y.add(Items.TOBACCO_LEAF); y.add(Items.TOBACCO_SEED); y.add(Items.TOBACCO_SEED) }
        }
        var wt = 0f
        for (id in y) wt += Items.WEIGHT[id]
        if (inv.weight() + wt > inv.capacity() + 0.001f) { showToast("Llevas demasiado peso para cosechar"); return }
        for (id in y) inv.counts[id]++
        inv.planted.remove(p)
        inv.save()
        showToast("Cosechaste ${Items.CROP_NAMES[p.type]}")
    }

    private fun onFill() {
        if (actCd > 0f) return
        actCd = 0.5f
        if (inv.counts[Items.BOWL] <= 0) return
        if (inv.weight() + (Items.WEIGHT[Items.BOWL_DIRTY] - Items.WEIGHT[Items.BOWL]) > inv.capacity() + 0.001f) { showToast("Llevas demasiado peso"); return }
        inv.counts[Items.BOWL]--; inv.counts[Items.BOWL_DIRTY]++
        inv.save()
        showToast("Cuenco con agua sucia: hiérvela en una fogata")
    }

    private fun onPile() {
        if (actCd > 0f) return
        val p = nearPile ?: return
        actCd = 0.5f
        var got = 0; var left = 0
        for (id in 0 until Items.COUNT) {
            val n = p.counts[id]
            if (n <= 0) continue
            val k = inv.fits(id, n)
            if (k > 0) { inv.counts[id] += k; p.counts[id] -= k; got += k }
            left += p.counts[id]
        }
        if (left == 0) inv.piles.remove(p)
        inv.save()
        showToast(if (got == 0) "Llevas demasiado peso" else if (left > 0) "Cogiste lo que pudiste" else "Recogido")
    }

    /** Usar el objeto elegido de la bolsa: beber o comer. */
    private fun onUse() {
        val slots = inv.slots()
        if (sel >= slots.size) return
        val id = slots[sel]
        when {
            id == Items.BOWL_CLEAN -> {
                inv.counts[id]--; inv.counts[Items.BOWL]++
                inv.water = min(100f, inv.water + 35f)
                showToast("Bebes agua hervida")
            }
            id == Items.BOWL_DIRTY -> {
                inv.counts[id]--; inv.counts[Items.BOWL]++
                inv.water = min(100f, inv.water + 25f); sickT = 60f
                showToast("Agua sin hervir: te sientes mal")
            }
            Items.hydro(id) > 0f -> {
                inv.counts[id]--
                inv.water = min(100f, inv.water + Items.hydro(id))
                if (id == Items.CHERRY) { inv.counts[Items.CHERRY_SEED]++; showToast("Comes una cereza y guardas su semilla") }
                else showToast("Comes: ${Items.NAMES[id]}")
            }
            else -> return
        }
        inv.save(); fixSel()
    }

    private fun onDropItem() {
        val slots = inv.slots()
        if (sel >= slots.size) return
        if (room != null) { showToast("Aquí dentro no puedes tirar cosas"); return }
        val id = slots[sel]
        inv.counts[id]--
        inv.drop(px, py, id, 1)
        showToast("Tiraste: ${Items.NAMES[id]}")
        fixSel()
    }

    private fun craft(r: Recipe) {
        if (!inv.canCraft(r)) { showToast("Te faltan materiales o herramienta"); return }
        if (inv.weight() + inv.craftWeightDelta(r) > inv.capacity() + 0.001f) { showToast("Llevas demasiado peso"); return }
        if (r.id == Recipe.FIRE) {
            val w = world ?: return
            if (room != null) { showToast("No se puede hacer fuego dentro de una casa"); return }
            // la fogata se pone delante de ti si se puede, y si no, a tus pies
            var fx = px + cos(faceA) * 10f
            var fy = py + sin(faceA) * 7f
            if (w.blocked(fx, fy) || w.inWater(fx, fy)) { fx = px; fy = py }
            if (w.inWater(fx, fy)) { showToast("No se puede hacer fuego en el agua"); return }
            inv.craft(r)
            inv.addFire(fx, fy)
            showToast("Has encendido una fogata")
        } else {
            inv.craft(r)
            showToast("Has creado: ${r.name}")
        }
        fixSel()
    }

    private fun openPanel() {
        panelOpen = true
        joyId = -1; jx = 0f; jy = 0f
        joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
        fixSel()
    }

    private fun fixSel() {
        val n = inv.slots().size
        if (sel >= n) sel = max(0, n - 1)
    }

    // ---------- render ----------
    private fun render(c: Canvas) {
        if (menuOpen) { drawMenu(c); return }
        if (mapOpen) { worldMap.draw(c, width, height, density, if (room != null) retX else px, if (room != null) retY else py); return }
        val lc = loCanvas ?: return
        val bmp = lo ?: return
        val w = world
        var cx = 0
        var cy = 0
        if (room != null) {
            cx = floor(rx - W / 2f).toInt()
            cy = floor(ry - H / 2f).toInt()
            drawRoom(lc, cx, cy)
        } else if (w != null) {
            cx = floor(px - W / 2f).toInt()
            cy = floor(py - H / 2f).toInt()
            drawWorld(lc, w, cx, cy)
        } else {
            lc.drawColor(gray(0.35f))
        }
        post(bmp, cx, cy)
        c.drawColor(BLACK)
        c.drawBitmap(bmp, null, dst, bmpPaint)
        drawUi(c)
    }

    private fun drawWorld(c: Canvas, w: World, cx: Int, cy: Int) {
        c.drawColor(gray(GROUND_LUM))
        val snap = w.snap
        c.save()
        c.translate(-cx.toFloat(), -cy.toFloat())
        val vx0 = cx.toFloat(); val vx1 = (cx + W).toFloat()
        val vy0 = cy.toFloat(); val vy1 = (cy + H).toFloat()

        // terreno
        fill.style = Paint.Style.FILL
        for (a in snap.areas) {
            if (a.maxX < vx0 || a.minX > vx1 || a.maxY < vy0 || a.minY > vy1) continue
            fill.color = gray(K.LUM[a.kind])
            c.drawPath(a.path, fill)
            if (a.kind == K.WATER && !a.clipped) {
                stroke.strokeWidth = 1.5f; stroke.color = gray(0.58f)
                c.drawPath(a.path, stroke)
            }
            when {
                                a.kind == K.WATER -> { c.save(); c.clipPath(a.path); drawWaves(c, vx0, vy0, vx1, vy1); c.restore() }
                a.kind == K.WET -> { c.save(); c.clipPath(a.path); drawMarsh(c, vx0, vy0, vx1, vy1); c.restore() }
            }
        }
        // ríos y arroyos
        for (r in snap.waterLines) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width; stroke.color = gray(0.14f)
            c.drawPath(r.path, stroke)
        }
        // caminos: borde oscuro + interior claro
        for (r in snap.roads) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width + 2f; stroke.color = gray(0.42f)
            c.drawPath(r.path, stroke)
        }
        for (r in snap.roads) {
            if (r.maxX + r.width < vx0 || r.minX - r.width > vx1 || r.maxY + r.width < vy0 || r.minY - r.width > vy1) continue
            stroke.strokeWidth = r.width; stroke.color = gray(0.96f)
            c.drawPath(r.path, stroke)
        }
        // vías de tren (activas y abandonadas): balasto, traviesas y dos rieles
        for (r in snap.rails) {
            if (r.maxX + 4f < vx0 || r.minX - 4f > vx1 || r.maxY + 4f < vy0 || r.minY - 4f > vy1) continue
            stroke.strokeWidth = 6f; stroke.color = gray(0.56f)
            c.drawPath(r.path, stroke)
            tie.color = gray(0.20f)
            c.drawPath(r.path, tie)
            stroke.strokeWidth = 1f; stroke.color = gray(0.95f)
            c.drawPath(r.left, stroke); c.drawPath(r.right, stroke)
        }

        // hierba natural (a ras de suelo)
        drawGrass(c, w, vx0, vy0, vx1, vy1)
        // trigo: lo que queda detrás del jugador (y lejos de él) va antes que el jugador
        drawCrops(c, w, snap, vx0, vy0, vx1, vy1, false)

        drawPlanted(c, vx0, vy0, vx1, vy1)

        // si el jugador está dentro de un edificio: vista de interior (sin tejado)
        val inB = w.buildingAt(px, py)
        if (inB != null) drawInterior(c, inB)

        val objs = snap.objs
        val first = snap.firstIndexAtY(vy0 - 6f)
        val maxY = vy1 + MAXH
        val dirX = cos(windA)

        // sombras (semitransparentes, oscurecen lo que hay debajo)
        fill.color = Color.argb(95, 0, 0, 0)
        var i = first
        while (i < objs.size && objs[i].y <= maxY) {
            val o = objs[i]
            val b = o.b
            if (b != null) {
                if (b !== inB && !(b.minX > vx1 || b.maxX + b.h < vx0)) c.drawPath(b.shadow, fill)
            } else if (o.x > vx0 - 30f && o.x < vx1 + 30f) {
                when (o.kind) {
                    KIND_TREE -> if (!inv.felled.contains(Inventory.keyOf(o))) {
                        c.save(); c.translate(o.x, o.y); c.drawPath(Sprites.treeShadow, fill); c.restore()
                    }
                    KIND_BUSH, KIND_MARABU, KIND_CHERRY -> {
                        c.save(); c.translate(o.x, o.y); c.drawPath(Sprites.bushShadow, fill); c.restore()
                    }
                }
            }
            i++
        }

        // objetos, fogatas y jugador ordenados por profundidad
        val fires = inv.fires
        var fi = 0
        while (fi < fires.size && fires[fi][1] < vy0 - 6f) fi++
        var playerDone = false
        i = first
        while (i < objs.size && objs[i].y <= maxY) {
            val o = objs[i]
            while (fi < fires.size && fires[fi][1] <= o.y) {
                val f = fires[fi]
                if (!playerDone && py < f[1]) { drawPlayer(c); playerDone = true }
                drawFire(c, f[0], f[1])
                fi++
            }
            if (!playerDone && o.y > py) { drawPlayer(c); playerDone = true }
            val b = o.b
            if (b != null) {
                if (b === inB) drawFront(c, b)
                else if (!(b.maxX < vx0 || b.minX > vx1 || b.maxY < vy0 || b.minY - b.h > vy1)) drawBuilding(c, b)
            } else if (o.x > vx0 - 8f && o.x < vx1 + 8f) {
                val ph = (o.variant and 0xFF) * 0.049f
                when (o.kind) {
                    KIND_TREE -> {
                        c.save()
                        c.translate(o.x, o.y)
                        if (inv.felled.contains(Inventory.keyOf(o))) {
                            fill.color = gray(0.15f); c.drawPath(Sprites.stump, fill)       // tocón
                            fill.color = gray(0.60f); c.drawPath(Sprites.stumpTop, fill)
                        } else {
                            // los árboles se inclinan con el viento (la copa se mueve más que la base)
                            var sway = dirX * windS * 3.2f * (0.75f + 0.25f * sin(windT * 3.1f + ph)) +
                                0.45f * sin(windT * 1.2f + ph)
                            if (o === shakeObj && shakeT > 0f) sway += sin(shakeT * 45f) * shakeT * 10f
                            c.skew(-sway / 19f, 0f)
                            fill.color = gray(0.05f)
                            if (Inventory.isPine(o)) c.drawPath(if (o.variant % 3 == 0) Sprites.treeSmall else Sprites.treeBig, fill)
                            else {
                                if (o.variant % 3 == 0) c.scale(0.8f, 0.8f)
                                c.drawPath(Sprites.treeRound, fill)
                                fill.color = gray(0.30f); c.drawPath(Sprites.treeRoundHi, fill)
                            }
                        }
                        c.restore()
                    }
                    KIND_BUSH -> {
                        val sway = dirX * windS * 1.3f * (0.8f + 0.2f * sin(windT * 2.6f + ph)) + 0.3f * sin(windT * 1.1f + ph)
                        c.save()
                        c.translate(o.x, o.y)
                        c.skew(-sway / 9f, 0f)
                        fill.color = gray(0.10f); c.drawPath(Sprites.bush, fill)
                        fill.color = gray(0.32f); c.drawPath(Sprites.bushHi, fill)
                        c.restore()
                    }
                    KIND_STONE -> {
                        val left = stonesLeft(o)
                        if (left > 0) drawStones(c, o.x, o.y, left)
                    }
                    KIND_REED, KIND_MARABU, KIND_SEEDS, KIND_TOBACCO, KIND_CHERRY -> {
                        val left = plantLeft(o)
                        var sway = dirX * windS * 1.6f * (0.8f + 0.2f * sin(windT * 2.6f + ph)) + 0.3f * sin(windT * 1.1f + ph)
                        if (o === shakeObj && shakeT > 0f) sway += sin(shakeT * 45f) * shakeT * 8f
                        c.save()
                        c.translate(o.x, o.y)
                        c.skew(-sway / 9f, 0f)
                        when (o.kind) {
                            KIND_REED -> if (left > 0) { fill.color = gray(0.16f); c.drawPath(Sprites.reed, fill) }
                            KIND_MARABU -> if (left > 0) { fill.color = gray(0.12f); c.drawPath(Sprites.marabu, fill) }
                            KIND_TOBACCO -> if (left > 0) { fill.color = gray(0.14f); c.drawPath(Sprites.tobacco, fill) }
                            KIND_SEEDS -> if (left > 0) {
                                fill.color = gray(0.12f); c.drawPath(Sprites.wildPlant, fill)
                                fill.color = gray(0.95f); c.drawRect(-1f, -10f, 1f, -8f, fill)
                            }
                            else -> {
                                fill.color = gray(0.10f); c.drawPath(Sprites.bush, fill)
                                fill.color = gray(0.32f); c.drawPath(Sprites.bushHi, fill)
                                if (left > 0) { fill.color = gray(0.97f); c.drawPath(Sprites.dots, fill) }
                            }
                        }
                        c.restore()
                    }
                    KIND_FENCE -> drawFence(c, o as FencePiece)
                    KIND_TRASH -> drawTrash(c, o.x, o.y, o.variant)
                }
            }
            i++
        }
        while (fi < fires.size && fires[fi][1] <= vy1 + 40f) {
            val f = fires[fi]
            if (!playerDone && py < f[1]) { drawPlayer(c); playerDone = true }
            drawFire(c, f[0], f[1])
            fi++
        }
        if (!playerDone) drawPlayer(c)
        // trigo que queda delante del jugador: le tapa las piernas y medio cuerpo
        drawCrops(c, w, snap, vx0, vy0, vx1, vy1, true)
        if (inB == null) drawWind(c)
        c.restore()
    }

    private fun drawPlanted(c: Canvas, vx0: Float, vy0: Float, vx1: Float, vy1: Float) {
        val now = System.currentTimeMillis()
        for (p in inv.planted) {
            if (p.x < vx0 - 10f || p.x > vx1 + 10f || p.y < vy0 - 14f || p.y > vy1 + 14f) continue
            val frac = ((now - p.t0) / 1000f) / Items.CROP_SECS[p.type]
            c.save(); c.translate(p.x, p.y)
            if (frac < 0.34f) { fill.color = gray(0.22f); c.drawPath(Sprites.sprout, fill) }
            else when (p.type) {
                7 -> { fill.color = gray(0.10f); c.drawPath(Sprites.bush, fill); if (frac >= 1f) { fill.color = gray(0.97f); c.drawPath(Sprites.dots, fill) } }
                8 -> { fill.color = gray(0.14f); c.drawPath(Sprites.tobacco, fill) }
                else -> {
                    fill.color = gray(0.16f); c.drawPath(Sprites.grown, fill)
                    if (frac >= 1f) { fill.color = gray(0.95f); c.drawRect(-1f, -13f, 1f, -11f, fill) }
                }
            }
            c.restore()
        }
        for (p in inv.piles) {
            if (p.x < vx0 - 10f || p.x > vx1 + 10f || p.y < vy0 - 14f || p.y > vy1 + 14f) continue
            c.save(); c.translate(p.x, p.y)
            fill.color = gray(0.30f); c.drawPath(Sprites.sack, fill)
            fill.color = gray(0.85f); c.drawRect(-2f, -11f, 2f, -10f, fill)
            c.restore()
        }
    }

    /** Matas de hierba repartidas por el suelo libre, en parches, que se mecen con el viento. */
    private fun drawGrass(c: Canvas, w: World, vx0: Float, vy0: Float, vx1: Float, vy1: Float) {
        val cs = 9
        val gx0 = floor(vx0 / cs).toInt() - 1
        val gx1 = floor(vx1 / cs).toInt() + 1
        val gy0 = floor(vy0 / cs).toInt() - 1
        val gy1 = floor(vy1 / cs).toInt() + 1
        val lean = cos(windA) * windS * 1.6f
        for (gy in gy0..gy1) for (gx in gx0..gx1) {
            val h = hash2(gx, gy)
            val patch = hash2(Math.floorDiv(gx, 5), Math.floorDiv(gy, 5)) and 0xFF
            if ((h and 0xFF) >= 20 + patch / 3) continue
            val x = floor((gx + ((h ushr 8) and 0xFF) / 255f) * cs)
            val y = floor((gy + ((h ushr 16) and 0xFF) / 255f) * cs)
            if (!w.groundFree(x, y)) continue
            val sw = lean + sin(windT * 2.5f + (h and 0xFF) * 0.05f) * 0.5f
            fill.color = if (((h ushr 4) and 3) == 0) gray(0.92f) else gray(0.20f)
            val tall = 2f + ((h ushr 24) and 1)
            c.drawRect(x, y - 2f, x + 1f, y, fill)                          // base
            c.drawRect(x + sw, y - 2f - tall, x + sw + 1f, y - 2f, fill)    // punta
            c.drawRect(x + 2f, y - 1f, x + 3f, y, fill)
            c.drawRect(x + 2f + sw * 0.7f, y - 1f - tall, x + 3f + sw * 0.7f, y - 1f, fill)
        }
    }

    // ---------- cultivos de trigo ----------
    /** Cuánto se dobla (bendLean) y se aplasta (bendSq) una mata en (x, y) por el paso reciente del jugador. */
    private fun bend(x: Float, y: Float) {
        bendLean = 0f; bendSq = 0f
        if (x < tbx0 || x > tbx1 || y < tby0 || y > tby1) return
        for (k in 0 until TN) {
            val age = gameT - trailTm[k]
            if (age > 1.2f || age < 0f) continue
            val dx = x - trailX[k]
            val dy = (y - trailY[k]) * 1.5f
            val d2 = dx * dx + dy * dy
            if (d2 >= 100f) continue
            val wgt = (1f - sqrt(d2) / 10f) * (1f - age / 1.2f)
            bendLean += (if (dx >= 0f) 1f else -1f) * wgt * 3.2f
            bendSq += wgt
        }
        if (bendSq > 1f) bendSq = 1f
        bendLean = bendLean.coerceIn(-4f, 4f)
    }

    /**
     * Matas de trigo en filas dentro de los campos de cultivo. Miden ~6 px (la mitad del personaje).
     * front=false: todas menos la franja que está justo delante del jugador (se dibujan antes que él).
     * front=true: solo esa franja (se dibuja después, así tapa al personaje).
     */
    private fun drawCrops(c: Canvas, w: World, snap: Snapshot, vx0: Float, vy0: Float, vx1: Float, vy1: Float, front: Boolean) {
        val lean0 = cos(windA) * windS * 1.4f
        for (a in snap.areas) {
            if (!a.crop) continue
            if (a.maxX < vx0 || a.minX > vx1 || a.maxY < vy0 || a.minY > vy1 + 8f) continue
            var yA = max(a.minY, vy0 - 2f)
            var yB = min(a.maxY, vy1 + 8f)
            if (front) {
                if (px < a.minX - 8f || px > a.maxX + 8f) continue
                yA = max(yA, py); yB = min(yB, py + 9f)
                if (yA >= yB) continue
            }
            val xA = max(a.minX, vx0 - 4f); val xB = min(a.maxX, vx1 + 4f)
            c.save()
            c.clipPath(a.path)
            val j0 = floor(xA / PLANT).toInt(); val j1 = floor(xB / PLANT).toInt()
            for (k in floor(yA / ROW).toInt()..floor(yB / ROW).toInt()) {
                val y = k * ROW + 1f
                val inStrip = y > py && y <= py + 8f
                if (front != inStrip) continue
                for (j in j0..j1) {
                    val h = hash2(j, k)
                    val x = j * PLANT + ((h ushr 4) and 1)
                    if (!w.groundFree(x, y)) continue
                    bend(x, y)
                    val sway = lean0 * (0.7f + 0.3f * sin(windT * 2.2f + (h and 0xFF) * 0.07f)) + bendLean
                    val ht = 5.5f + ((h ushr 8) and 3) * 0.5f - bendSq * 2.2f
                    fill.color = gray(0.26f)
                    c.drawRect(x, y - 3f, x + 1f, y, fill)                                           // tallo
                    c.drawRect(x + sway * 0.5f, y - ht, x + sway * 0.5f + 1f, y - 3f, fill)
                    fill.color = gray(0.95f)
                    c.drawRect(x + sway - 0.5f, y - ht - 2f, x + sway + 1.5f, y - ht + 0.5f, fill)  // espiga
                }
            }
            c.restore()
        }
    }

    // ---------- agua, humedal, cercas, basura, iglesias ----------
    /** Olas pequeñas que suben y bajan: marcan que ahí hay agua. */
    private fun drawWaves(c: Canvas, vx0: Float, vy0: Float, vx1: Float, vy1: Float) {
        val cs = 12
        fill.color = gray(0.64f)
        for (gy in floor(vy0 / cs).toInt() - 1..floor(vy1 / cs).toInt() + 1) {
            for (gx in floor(vx0 / cs).toInt() - 1..floor(vx1 / cs).toInt() + 1) {
                val h = hash2(gx, gy)
                if ((h and 3) != 0) continue
                val x = (gx * cs + ((h ushr 8) and 7)).toFloat()
                val y = (gy * cs + ((h ushr 16) and 7)).toFloat()
                val ph = windT * 1.5f + (h and 0xFF) * 0.12f
                val xo = sin(ph) * 1.6f
                val up = if (sin(ph + 1.2f) > 0.3f) 1f else 0f
                c.drawRect(x + xo - 2f, y, x + xo - 1f, y + 1f, fill)
                c.drawRect(x + xo - 1f, y - 1f - up, x + xo + 1f, y - up, fill)
                c.drawRect(x + xo + 1f, y, x + xo + 2f, y + 1f, fill)
            }
        }
    }

    /** Juncos y charcos del humedal. */
    private fun drawMarsh(c: Canvas, vx0: Float, vy0: Float, vx1: Float, vy1: Float) {
        val cs = 9
        val lean = cos(windA) * windS * 1.2f
        for (gy in floor(vy0 / cs).toInt() - 1..floor(vy1 / cs).toInt() + 1) {
            for (gx in floor(vx0 / cs).toInt() - 1..floor(vx1 / cs).toInt() + 1) {
                val h = hash2(gx + 500, gy)
                if ((h and 3) >= 2) continue
                val x = (gx * cs + ((h ushr 8) and 7)).toFloat()
                val y = (gy * cs + ((h ushr 16) and 7)).toFloat()
                fill.color = gray(0.68f); c.drawRect(x - 2f, y + 1f, x + 3f, y + 2f, fill)                // reflejo del charco
                val sw = lean * 0.6f
                fill.color = gray(0.12f)
                c.drawRect(x, y - 2f, x + 1f, y + 1f, fill)
                c.drawRect(x + sw, y - 5f, x + sw + 1f, y - 2f, fill)
                c.drawRect(x + 2f, y - 1f, x + 3f, y + 1f, fill)
                c.drawRect(x + 2f + sw, y - 3f, x + 3f + sw, y - 1f, fill)
            }
        }
    }

    /** Trocito de cerca (postes y dos tablas), seto o muro: mide ~5 px, la mitad del personaje. */
    private fun drawFence(c: Canvas, f: FencePiece) {
        when (f.style) {
            1 -> {                                                          // seto
                stroke.strokeWidth = 4f; stroke.color = gray(0.10f)
                c.drawLine(f.x1, f.y1 - 2f, f.x2, f.y2 - 2f, stroke)
                stroke.strokeWidth = 1f; stroke.color = gray(0.36f)
                c.drawLine(f.x1, f.y1 - 4f, f.x2, f.y2 - 4f, stroke)
            }
            2 -> {                                                          // muro
                stroke.strokeWidth = 4f; stroke.color = gray(0.58f)
                c.drawLine(f.x1, f.y1 - 2f, f.x2, f.y2 - 2f, stroke)
                stroke.strokeWidth = 1f; stroke.color = gray(0.95f)
                c.drawLine(f.x1, f.y1 - 4.5f, f.x2, f.y2 - 4.5f, stroke)
                stroke.color = gray(0.18f)
                c.drawLine(f.x1, f.y1, f.x2, f.y2, stroke)
            }
            else -> {                                                       // cerca
                stroke.strokeWidth = 1f; stroke.color = gray(0.12f)
                c.drawLine(f.x1, f.y1 - 2f, f.x2, f.y2 - 2f, stroke)
                c.drawLine(f.x1, f.y1 - 4f, f.x2, f.y2 - 4f, stroke)
                fill.color = gray(0.08f)
                c.drawRect(f.x1 - 0.5f, f.y1 - 5f, f.x1 + 0.5f, f.y1 + 0.5f, fill)
                c.drawRect(f.x2 - 0.5f, f.y2 - 5f, f.x2 + 0.5f, f.y2 + 0.5f, fill)
            }
        }
    }

    /** Montón de basura decorativo (vertederos). */
    private fun drawTrash(c: Canvas, x: Float, y: Float, v: Int) {
        fill.color = Color.argb(90, 0, 0, 0); c.drawRect(x - 5f, y - 1f, x + 7f, y + 1f, fill)
        fill.color = gray(0.30f); c.drawRect(x - 5f, y - 3f, x + 5f, y, fill)
        fill.color = gray(0.38f); c.drawRect(x - 3f, y - 5f, x + 3f, y - 3f, fill)
        for (k in 0..5) {
            val h = hash2(v, k)
            val sx = x - 5f + (h and 7)
            val sy = y - 5f + ((h ushr 4) and 3)
            fill.color = if (((h ushr 8) and 1) == 0) gray(0.92f) else gray(0.08f)
            c.drawRect(sx, sy, sx + 2f, sy + 1f, fill)
        }
    }

    /** Torre con aguja y cruz de las iglesias (se dibuja a la altura del tejado). */
    private fun drawTower(c: Canvas, b: Building) {
        val tx = (b.minX + b.maxX) / 2f
        val ty = b.maxY - 3f
        val hw = min(4.5f, (b.maxX - b.minX) * 0.3f)
        fill.color = gray(0.34f); c.drawRect(tx - hw, ty - 15f, tx + hw, ty, fill)
        fill.color = gray(0.14f); c.drawRect(tx + hw * 0.3f, ty - 15f, tx + hw, ty, fill)
        fill.color = gray(0.98f); c.drawRect(tx - hw * 0.45f, ty - 11f, tx + hw * 0.1f, ty - 6f, fill)     // campanario
        spire.rewind()
        spire.moveTo(tx - hw - 1f, ty - 15f); spire.lineTo(tx + hw + 1f, ty - 15f); spire.lineTo(tx, ty - 24f); spire.close()
        fill.color = gray(0.08f); c.drawPath(spire, fill)
        stroke.strokeWidth = 1f; stroke.color = gray(0.97f)
        c.drawLine(tx, ty - 24f, tx, ty - 31f, stroke)                                                       // cruz
        c.drawLine(tx - 2f, ty - 28f, tx + 2f, ty - 28f, stroke)
    }

    private fun drawStones(c: Canvas, x: Float, y: Float, n: Int) {
        fill.color = Color.argb(90, 0, 0, 0)
        c.drawRect(x - 3f, y, x + 6f, y + 1f, fill)
        fill.color = gray(0.42f); c.drawRect(x - 3f, y - 3f, x + 2f, y, fill)
        fill.color = gray(0.88f); c.drawRect(x - 2f, y - 3f, x, y - 2f, fill)
        if (n >= 2) {
            fill.color = gray(0.36f); c.drawRect(x + 2f, y - 2f, x + 6f, y + 1f, fill)
            fill.color = gray(0.85f); c.drawRect(x + 3f, y - 2f, x + 4f, y - 1f, fill)
        }
    }

    private fun drawFire(c: Canvas, fx: Float, fy: Float) {
        // resplandor
        fill.color = Color.argb(60, 255, 255, 255)
        c.drawOval(RectF(fx - 18f, fy - 10f, fx + 18f, fy + 8f), fill)
        // troncos cruzados
        stroke.strokeWidth = 2f; stroke.color = gray(0.10f)
        c.drawLine(fx - 5f, fy, fx + 5f, fy - 2f, stroke)
        c.drawLine(fx - 5f, fy - 2f, fx + 5f, fy, stroke)
        // llamas que parpadean y se doblan con el viento
        val t = windT * 11f + fx
        val h1 = 6f + 2f * sin(t)
        val h2 = 4f + 2f * sin(t * 1.7f + 1f)
        val h3 = 5f + 2f * sin(t * 1.3f + 2f)
        val lean = cos(windA) * windS * 1.5f
        fill.color = gray(0.80f)
        c.drawRect(fx - 2f + lean, fy - 2f - h1, fx + 2f + lean, fy - 1f, fill)
        c.drawRect(fx - 4f, fy - 2f - h2, fx - 2f, fy - 1f, fill)
        c.drawRect(fx + 2f, fy - 2f - h3, fx + 4f, fy - 1f, fill)
        fill.color = gray(1f)
        c.drawRect(fx - 1f + lean * 0.5f, fy - 1f - h1 * 0.55f, fx + 1f + lean * 0.5f, fy - 1f, fill)
        // humo
        for (k in 0..2) {
            val ph = (windT * 0.7f + k * 0.33f) % 1f
            val sx = fx + lean * ph * 6f + sin(ph * 6f + k) * 1.5f
            val sy = fy - 8f - ph * 16f
            fill.color = gray(0.85f - ph * 0.4f)
            c.drawRect(sx, sy, sx + 1.5f, sy + 1.5f, fill)
        }
    }

    private fun drawInterior(c: Canvas, b: Building) {
        fill.color = gray(0.70f); c.drawPath(b.roof, fill)          // suelo
        fill.color = gray(0.16f); c.drawPath(b.wallBack, fill)      // paredes del fondo
        stroke.strokeWidth = 2f; stroke.color = gray(0.05f)
        c.drawPath(b.roof, stroke)                                   // base de las paredes
    }

    private fun drawFront(c: Canvas, b: Building) {
        fill.color = gray(0.12f); c.drawPath(b.wallFront, fill)     // pared baja delantera con hueco de puerta
    }

    private fun drawWind(c: Canvas) {
        val len = 1 + (windS * 3f).toInt()
        for (i in 0 until PN) {
            val x = floor(pX[i])
            val y = floor(pY[i])
            if (i % 5 == 0) {                       // hojas / ceniza
                fill.color = gray(0.04f)
                c.drawRect(x, y, x + 2f, y + 2f, fill)
            } else {                                 // nieve y polvo
                fill.color = if (i % 2 == 0) gray(1f) else gray(0.04f)
                c.drawRect(x, y, x + len, y + 1f, fill)
            }
        }
    }

    private fun drawBuilding(c: Canvas, b: Building) {
        fill.color = gray(0.10f); c.drawPath(b.wallA, fill)
        fill.color = gray(0.26f); c.drawPath(b.wallB, fill)
        fill.color = gray(1f); c.drawPath(b.windows, fill)
        if (b.enterable) { fill.color = gray(0.95f); c.drawPath(b.door, fill) }
        c.save()
        c.translate(0f, -b.h)
        fill.color = gray(0.86f); c.drawPath(b.roof, fill)
        stroke.strokeWidth = 1f; stroke.color = gray(0.15f); c.drawPath(b.roof, stroke)
        if (b.church) drawTower(c, b)
        c.restore()
        if (b.enterable) { fill.color = gray(0.40f); c.drawPath(b.mat, fill) }
    }

    private fun drawPlayer(c: Canvas) {
        val x = px.toInt().toFloat()
        val y = py.toInt().toFloat()
        if (swimming) {
            // hundido hasta la mitad: solo se ve la parte de arriba + ondas en el agua
            c.save()
            c.clipRect(x - 10f, y - 16f, x + 12f, y - 4f)
            drawBody(c, x, y + 2f)
            c.restore()
            val k = ((walkT * 5f).toInt() and 1).toFloat()
            fill.color = gray(0.95f)
            c.drawRect(x - 4f - k, y - 4f, x + 4f + k, y - 3f, fill)
            fill.color = gray(0.75f)
            c.drawRect(x - 6f + k, y - 2f, x + 6f - k, y - 1f, fill)
        } else if (mud && jumpT <= 0f) {
            // fango: se hunden las piernas
            c.save()
            c.clipRect(x - 10f, y - 16f, x + 12f, y - 3f)
            drawBody(c, x, y)
            c.restore()
            fill.color = gray(0.22f); c.drawRect(x - 4f, y - 3f, x + 4f, y - 2f, fill)
            fill.color = gray(0.34f); c.drawRect(x - 6f, y - 2f, x + 6f, y - 1f, fill)
        } else {
            val lift = if (jumpT > 0f) sin(Math.PI.toFloat() * (1f - jumpT / JUMP_DUR)) * 9f else 0f
            fill.color = Color.argb(110, 0, 0, 0)
            c.drawRect(x - 2f, y - 1f, x + 6f, y + 1f, fill)      // sombra
            drawBody(c, x, y - lift)
        }
    }

    private fun drawBody(c: Canvas, x: Float, y: Float) {
        fill.color = gray(0.03f)
        c.drawRect(x - 1f, y - 10f, x + 1f, y - 7f, fill)         // cabeza
        c.drawRect(x - 2f, y - 7f, x + 2f, y - 3f, fill)          // cuerpo
        val step = moving && ((walkT * 8f).toInt() and 1) == 0
        val l = if (step) y - 1f else y
        val r = if (step || !moving) y else y - 1f
        c.drawRect(x - 2f, y - 3f, x - 0.5f, l, fill)             // piernas
        c.drawRect(x + 0.5f, y - 3f, x + 2f, r, fill)

        val hx = x + 2f
        val hy = y - 5f
        val held = inv.hand
        if (atkT > 0f) {
            // golpe: el brazo (y la herramienta, si la llevas) barre un arco hacia donde miras
            val p = 1f - atkT / ATK_DUR
            val a = faceA - 1.0f + 2.0f * p
            fill.color = gray(1f)
            for (k in 0..3) {
                val aa = a - k * 0.3f
                val sx = x + cos(aa) * 10f
                val sy = y - 5f + sin(aa) * 10f
                c.drawRect(sx, sy, sx + 2f, sy + 2f, fill)
            }
            if (Items.equippable(held)) drawTool(c, hx, hy, a, held)
        } else if (Items.equippable(held)) {
            drawTool(c, hx, hy, -1.1f, held)                      // en reposo, apuntando arriba
        }
    }

    private fun drawTool(c: Canvas, x: Float, y: Float, a: Float, id: Int) {
        stroke.strokeWidth = 1.5f
        stroke.color = gray(0.38f)
        val len = when (id) { Items.SPEAR -> 13f; Items.KNIFE -> 4f; Items.MARABU -> 9f; else -> 8f }
        val ex = x + cos(a) * len
        val ey = y + sin(a) * len
        c.drawLine(x, y, ex, ey, stroke)
        when (id) {
            Items.AXE -> { fill.color = gray(0.80f); c.drawRect(ex - 1.5f, ey - 1.5f, ex + 1.5f, ey + 1.5f, fill) }
            Items.SPEAR -> { fill.color = gray(0.92f); c.drawRect(ex - 1f, ey - 1f, ex + 1f, ey + 1f, fill) }
            Items.KNIFE -> { fill.color = gray(0.92f); c.drawRect(ex - 1f, ey - 1f, ex + 2f, ey + 1f, fill) }
            Items.MARABU -> {
                fill.color = gray(0.05f)
                for (k in 1..3) { val tx = x + cos(a) * k * 2.4f; val ty = y + sin(a) * k * 2.4f; c.drawRect(tx - 1f, ty - 1f, tx + 1f, ty + 1f, fill) }
            }
        }
    }

    /** Posproceso: viñeta + ruido + dithering Bayer a la paleta de 4 tonos + esquinas redondeadas. */
    private fun post(bmp: Bitmap, camX: Int, camY: Int) {
        bmp.getPixels(pix, 0, W, 0, 0, W, H)
        var i = 0
        for (y in 0 until H) {
            val wy = y + camY
            val row = (wy and 3) shl 2
            for (x in 0 until W) {
                val v = vig[i]
                if (v < 0f) {
                    pix[i] = BLACK
                } else {
                    val wx = x + camX     // el patrón se ancla al mundo: no "nada" al caminar
                    val n = (((wx * 73856093) xor (wy * 19349663)) ushr 9) and 15
                    var l = (pix[i] and 0xFF) * (1f / 255f) * v + (n - 7.5f) * 0.0075f
                    if (l < 0f) l = 0f else if (l > 1f) l = 1f
                    val t = l * 3f
                    var idx = t.toInt()
                    if (t - idx > BAYER[row + (wx and 3)]) idx++
                    pix[i] = PAL[if (idx > 3) 3 else idx]
                }
                i++
            }
        }
        bmp.setPixels(pix, 0, W, 0, 0, W, H)
    }

    private fun buildVignette(w: Int, h: Int): FloatArray {
        val a = FloatArray(w * h)
        val r = min(w, h) * 0.08f
        for (y in 0 until h) for (x in 0 until w) {
            val nx = (x + 0.5f - w / 2f) / (w / 2f)
            val ny = (y + 0.5f - h / 2f) / (h / 2f)
            var v = 1f - 0.30f * (nx * nx + ny * ny)
            if (v < 0.25f) v = 0.25f
            val cx = if (x < r) r else if (x > w - r) w - r else x.toFloat()
            val cy = if (y < r) r else if (y > h - r) h - r else y.toFloat()
            if (cx != x.toFloat() || cy != y.toFloat()) {
                val dx = x - cx; val dy = y - cy
                if (dx * dx + dy * dy > r * r) v = -1f
            }
            a[y * w + x] = v
        }
        return a
    }

    // ---------- interfaz (a resolución completa) ----------
    private fun atkCx() = width - 84f * density
    private fun atkCy() = height - 84f * density
    private fun atkR() = 42f * density
    private fun srcCx() = width - 180f * density
    private fun srcCy() = height - 64f * density
    private fun srcR() = 32f * density
    private fun stoneCx() = width - 84f * density
    private fun stoneCy() = height - 168f * density
    private fun jumpCx() = width - 180f * density
    private fun jumpCy() = height - 150f * density
    private fun ctxCx(i: Int) = when (i) { 0 -> width - 84f * density; 1 -> width - 180f * density; else -> width - 276f * density }
    private fun ctxCy(i: Int) = when (i) { 0 -> height - 252f * density; 1 -> height - 236f * density; 2 -> height - 64f * density; else -> height - 150f * density }
    private fun mapBtnRect() = RectF(width - 160f * density, 12f * density, width - 88f * density, 56f * density)

    private fun openMap() {
        if (world == null) return
        panelOpen = false
        joyId = -1; jx = 0f; jy = 0f
        joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
        worldMap.open()
        mapOpen = true
    }

    /** Botón atrás: cierra el mapa o la bolsa. Devuelve true si lo usó. */
    fun handleBack(): Boolean {
        if (mapOpen) { mapOpen = false; return true }
        if (panelOpen) { panelOpen = false; return true }
        return false
    }

    private fun bagRect() = RectF(width - 80f * density, 12f * density, width - 12f * density, 56f * density)

    private fun panelRect(): RectF {
        val pw = min(width - 24f * density, 420f * density)
        val ph = min(height - 24f * density, 290f * density)
        val l = (width - pw) / 2f
        val t = (height - ph) / 2f
        return RectF(l, t, l + pw, t + ph)
    }

    private fun tabRect(r: RectF, k: Int): RectF {
        val l = r.left + 16f * density + k * 104f * density
        val t = r.top + 10f * density
        return RectF(l, t, l + 96f * density, t + 32f * density)
    }

    private fun listVisible(r: RectF) = max(3, ((r.bottom - 12f * density - (r.top + 78f * density)) / (30f * density)).toInt())

    private fun bagRow(r: RectF, i: Int): RectF {
        val l = r.left + 16f * density; val t = r.top + 78f * density + i * 30f * density
        return RectF(l, t, l + 232f * density, t + 28f * density)
    }

    private fun bagScrollBtn(r: RectF, k: Int): RectF {
        val l = r.left + 16f * density + 236f * density; val t = r.top + 78f * density + k * 44f * density
        return RectF(l, t, l + 28f * density, t + 40f * density)
    }

    private fun btnRect(r: RectF, k: Int): RectF {
        val x0 = r.left + 288f * density
        val t = r.top + 90f * density + k * 36f * density
        return RectF(x0, t, max(x0 + 60f * density, r.right - 16f * density), t + 32f * density)
    }

    private fun craftVisible(r: RectF) = max(2, ((r.bottom - 8f * density - (r.top + 54f * density)) / (50f * density)).toInt())

    private fun rowRect(r: RectF, i: Int): RectF {
        val t = r.top + 54f * density + i * 50f * density
        return RectF(r.left + 16f * density, t, r.right - 56f * density, t + 46f * density)
    }

    private fun craftScrollBtn(r: RectF, k: Int): RectF {
        val l = r.right - 48f * density; val t = r.top + 54f * density + k * 50f * density
        return RectF(l, t, l + 32f * density, t + 46f * density)
    }

    private fun label(c: Canvas, text: String, cx: Float, cy: Float, size: Float, color: Int) {
        ui.style = Paint.Style.FILL
        ui.typeface = Typeface.MONOSPACE
        ui.textAlign = Paint.Align.CENTER
        ui.textSize = size
        ui.color = color
        c.drawText(text, cx, cy + size * 0.35f, ui)
    }

    private fun roundButton(c: Canvas, cx: Float, cy: Float, r: Float, text: String, active: Boolean) {
        ui.style = Paint.Style.FILL; ui.color = Color.argb(if (active) 80 else 46, 234, 233, 219)
        c.drawCircle(cx, cy, r, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 3f * density
        ui.color = Color.argb(if (active) 200 else 130, 234, 233, 219)
        c.drawCircle(cx, cy, r, ui)
        label(c, text, cx, cy, 12f * density, CREAM)
    }

    private fun boxButton(c: Canvas, r: RectF, text: String, enabled: Boolean, selected: Boolean = false) {
        ui.style = Paint.Style.FILL
        ui.color = if (selected) Color.argb(110, 234, 233, 219) else if (enabled) Color.argb(60, 234, 233, 219) else Color.argb(20, 234, 233, 219)
        c.drawRoundRect(r, 6f * density, 6f * density, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density
        ui.color = if (enabled) CREAM else MIDGRAY
        c.drawRoundRect(r, 6f * density, 6f * density, ui)
        label(c, text, r.centerX(), r.centerY(), 13f * density, if (enabled) CREAM else MIDGRAY)
    }

    private fun drawItemIcon(c: Canvas, id: Int, s: RectF) {
        val cx = s.centerX()
        val cy = s.centerY()
        val d = density
        ui.strokeCap = Paint.Cap.ROUND
        when (id) {
            Items.STICK -> {
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 4f * d; ui.color = LIGHTGRAY
                c.drawLine(cx - 14f * d, cy + 14f * d, cx + 14f * d, cy - 14f * d, ui)
            }
            Items.STONE -> {
                ui.style = Paint.Style.FILL; ui.color = 0xFF8A8087.toInt()
                c.drawOval(RectF(cx - 13f * d, cy - 9f * d, cx + 13f * d, cy + 9f * d), ui)
                ui.color = CREAM
                c.drawOval(RectF(cx - 8f * d, cy - 6f * d, cx - 2f * d, cy - 3f * d), ui)
            }
            Items.LOG -> {
                val rr = RectF(cx - 15f * d, cy - 8f * d, cx + 15f * d, cy + 8f * d)
                ui.style = Paint.Style.FILL; ui.color = MIDGRAY
                c.drawRoundRect(rr, 4f * d, 4f * d, ui)
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 1.5f * d; ui.color = CREAM
                c.drawRoundRect(rr, 4f * d, 4f * d, ui)
                c.drawCircle(cx + 9f * d, cy, 4f * d, ui)
            }
            Items.LEAF -> {
                ui.style = Paint.Style.FILL; ui.color = LIGHTGRAY
                c.drawOval(RectF(cx - 12f * d, cy - 7f * d, cx + 12f * d, cy + 7f * d), ui)
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 1.5f * d; ui.color = 0xFF2A2428.toInt()
                c.drawLine(cx - 10f * d, cy + 5f * d, cx + 10f * d, cy - 5f * d, ui)
            }
            Items.AXE -> {
                ui.style = Paint.Style.STROKE; ui.strokeWidth = 4f * d; ui.color = LIGHTGRAY
                c.drawLine(cx - 12f * d, cy + 13f * d, cx + 8f * d, cy - 9f * d, ui)
                ui.style = Paint.Style.FILL; ui.color = 0xFF8A8087.toInt()
                c.drawRect(cx + 2f * d, cy - 16f * d, cx + 15f * d, cy - 4f * d, ui)
            }
        }
        ui.strokeCap = Paint.Cap.BUTT
    }

    private fun drawUi(c: Canvas) {
        // joystick
        ui.style = Paint.Style.FILL; ui.color = Color.argb(46, 234, 233, 219)
        c.drawCircle(joyOx, joyOy, joyR, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 3f * density; ui.color = Color.argb(150, 234, 233, 219)
        c.drawCircle(joyOx, joyOy, joyR, ui)
        ui.style = Paint.Style.FILL; ui.color = Color.argb(170, 234, 233, 219)
        c.drawCircle(joyKx, joyKy, joyR * 0.42f, ui)

        // versión del juego (arriba, centro)
        if (verText.isNotEmpty()) {
            ui.style = Paint.Style.FILL; ui.textSize = 10f * density; ui.typeface = Typeface.MONOSPACE
            ui.textAlign = Paint.Align.CENTER; ui.color = Color.argb(150, 234, 233, 219)
            c.drawText(verText, width / 2f, 22f * density, ui)
            ui.textAlign = Paint.Align.LEFT
        }

        val st = world?.status
        if (st != null) {
            // estado de la descarga del mapa (arriba a la izquierda)
            ui.textSize = 12f * density
            ui.typeface = Typeface.MONOSPACE
            ui.textAlign = Paint.Align.LEFT
            val tw = ui.measureText(st)
            ui.style = Paint.Style.FILL; ui.color = Color.argb(200, 42, 36, 40)
            c.drawRoundRect(RectF(12f * density, 12f * density, 12f * density + tw + 16f * density, 40f * density), 8f * density, 8f * density, ui)
            ui.color = CREAM
            c.drawText(st, 20f * density, 31f * density, ui)
        }

        if (world != null) {
            // botones de acción
            roundButton(c, atkCx(), atkCy(), atkR(), "Atacar", atkT > 0f)
            if (nearTree != null) roundButton(c, srcCx(), srcCy(), srcR(), "Buscar", false)
            if (nearStone != null) roundButton(c, stoneCx(), stoneCy(), srcR(), "Piedras", false)
            if (nearFence) roundButton(c, jumpCx(), jumpCy(), srcR(), "Saltar", jumpT > 0f)
            for ((i, a) in ctxList.withIndex()) roundButton(c, ctxCx(i), ctxCy(i), srcR(), a.label, a.act == A_BOIL && boilT > 0f)
            drawVitals(c)
            boxButton(c, bagRect(), "Bolsa", true)
            boxButton(c, mapBtnRect(), "Mapa", true)
            if (panelOpen) drawPanel(c)

            // cansancio de nadar (se llena hasta los 3 minutos)
            if (swimT > 5f) {
                val bw = 150f * density; val bh = 7f * density
                val l = width / 2f - bw / 2f; val t = 54f * density
                ui.style = Paint.Style.FILL; ui.color = Color.argb(150, 42, 36, 40)
                c.drawRoundRect(RectF(l, t, l + bw, t + bh), 4f * density, 4f * density, ui)
                ui.color = if (swimT > 120f) CREAM else LIGHTGRAY
                c.drawRoundRect(RectF(l, t, l + bw * min(1f, swimT / SWIM_LIMIT), t + bh), 4f * density, 4f * density, ui)
                label(c, "Cansancio", width / 2f, t + bh + 10f * density, 10f * density, CREAM)
            }

            // aviso breve (arriba, por encima del panel)
            val t = toast
            if (t != null) {
                ui.textSize = 14f * density
                ui.typeface = Typeface.MONOSPACE
                val tw = ui.measureText(t)
                val cx = width / 2f
                val cy = 30f * density
                ui.style = Paint.Style.FILL; ui.color = Color.argb(225, 42, 36, 40)
                c.drawRoundRect(RectF(cx - tw / 2f - 14f * density, cy - 16f * density, cx + tw / 2f + 14f * density, cy + 16f * density), 8f * density, 8f * density, ui)
                label(c, t, cx, cy, 14f * density, CREAM)
            }
        }

        if (deadT > 0f) {
            ui.style = Paint.Style.FILL; ui.color = Color.argb(205, 20, 16, 18)
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), ui)
            label(c, deathTitle, width / 2f, height / 2f - 26f * density, 24f * density, CREAM)
            label(c, deathSub, width / 2f, height / 2f + 4f * density, 14f * density, LIGHTGRAY)
            label(c, "Reapareces en el punto de inicio…", width / 2f, height / 2f + 28f * density, 13f * density, LIGHTGRAY)
        }

        // mensajes (carga / error)
        val msg = message ?: return
        ui.style = Paint.Style.FILL
        ui.typeface = Typeface.MONOSPACE
        ui.textAlign = Paint.Align.CENTER
        ui.textSize = 15f * density
        ui.color = CREAM
        var y = height / 2f - (msg.count { it == '\n' }) * ui.textSize * 0.6f
        for (line in msg.split("\n")) {
            c.drawText(line, width / 2f, y, ui)
            y += ui.textSize * 1.3f
        }
    }

    private fun drawVitals(c: Canvas) {
        val l = 12f * density; var t = 50f * density
        val bw = 110f * density; val bh = 7f * density
        vitalBar(c, l, t, bw, bh, inv.water / 100f, "Agua", inv.water < 20f)
        t += 22f * density
        if (inv.water <= 0f) { vitalBar(c, l, t, bw, bh, inv.body / 100f, "Cuerpo", true); t += 22f * density }
        ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.LEFT; ui.typeface = Typeface.MONOSPACE
        ui.textSize = 10f * density
        ui.color = if (inv.weight() / inv.capacity() > 0.7f) LIGHTGRAY else CREAM
        c.drawText("Peso ${fmt(inv.weight())}/${fmt(inv.capacity())} kg", l, t + 6f * density, ui)
        if (boilT > 0f) {
            val bx = width / 2f - 75f * density; val by = 54f * density
            ui.style = Paint.Style.FILL; ui.color = Color.argb(150, 42, 36, 40)
            c.drawRoundRect(RectF(bx, by, bx + 150f * density, by + 7f * density), 4f * density, 4f * density, ui)
            ui.color = CREAM
            c.drawRoundRect(RectF(bx, by, bx + 150f * density * (1f - boilT / BOIL_TIME), by + 7f * density), 4f * density, 4f * density, ui)
            label(c, "Hirviendo", width / 2f, by + 17f * density, 10f * density, CREAM)
        }
    }

    private fun vitalBar(c: Canvas, l: Float, t: Float, bw: Float, bh: Float, frac: Float, name: String, warn: Boolean) {
        ui.style = Paint.Style.FILL; ui.color = Color.argb(150, 42, 36, 40)
        c.drawRoundRect(RectF(l, t, l + bw, t + bh), 4f * density, 4f * density, ui)
        ui.color = if (warn && ((gameT * 3f).toInt() and 1) == 0) LIGHTGRAY else CREAM
        c.drawRoundRect(RectF(l, t, l + bw * frac.coerceIn(0f, 1f), t + bh), 4f * density, 4f * density, ui)
        ui.textAlign = Paint.Align.LEFT; ui.typeface = Typeface.MONOSPACE; ui.textSize = 10f * density; ui.color = CREAM
        c.drawText(name, l + bw + 6f * density, t + bh, ui)
    }

    // ---------- pantalla de inicio ----------
    private fun townRect(i: Int): RectF {
        val bw = min(width / 2f - 20f * density, 210f * density)
        val bh = 40f * density; val gap = 8f * density
        val totalW = bw * 2f + gap
        val left = (width - totalW) / 2f
        val top = max(96f * density, (height - 4f * (bh + gap)) / 2f + 24f * density)
        val col = i % 2; val row = i / 2
        val l = left + col * (bw + gap)
        val t = top + row * (bh + gap)
        return RectF(l, t, l + bw, t + bh)
    }

    private fun drawMenu(c: Canvas) {
        c.drawColor(BLACK)
        label(c, "PIXEL VILLAGE", width / 2f, 40f * density, 26f * density, CREAM)
        label(c, "¿En qué pueblo quieres aparecer?", width / 2f, 68f * density, 13f * density, LIGHTGRAY)
        for ((i, t) in Region.TOWNS.withIndex()) boxButton(c, townRect(i), t.first, true, i == chosenTown)
        if (verText.isNotEmpty()) label(c, verText, width / 2f, height - 16f * density, 11f * density, MIDGRAY)
    }

    private fun drawPanel(c: Canvas) {
        val r = panelRect()
        ui.style = Paint.Style.FILL; ui.color = Color.argb(245, 42, 36, 40)
        c.drawRoundRect(r, 10f * density, 10f * density, ui)
        ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density; ui.color = CREAM
        c.drawRoundRect(r, 10f * density, 10f * density, ui)

        boxButton(c, tabRect(r, 0), "Bolsa", true, panelTab == 0)
        boxButton(c, tabRect(r, 1), "Crear", true, panelTab == 1)

        if (panelTab == 0) drawBagTab(c, r) else drawCraftTab(c, r)
    }

    private fun drawBagTab(c: Canvas, r: RectF) {
        val slots = inv.slots()
        val vis = listVisible(r)
        bagScroll = bagScroll.coerceIn(0, max(0, slots.size - vis))
        val d = density
        // peso
        ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.LEFT; ui.typeface = Typeface.MONOSPACE
        ui.textSize = 12f * d; ui.color = CREAM
        c.drawText("Peso ${fmt(inv.weight())} / ${fmt(inv.capacity())} kg", r.left + 16f * d, r.top + 62f * d, ui)
        val frac = (inv.weight() / inv.capacity()).coerceIn(0f, 1f)
        ui.color = Color.argb(50, 234, 233, 219)
        c.drawRect(r.left + 16f * d, r.top + 68f * d, r.left + 248f * d, r.top + 73f * d, ui)
        ui.color = if (frac > 0.7f) LIGHTGRAY else CREAM
        c.drawRect(r.left + 16f * d, r.top + 68f * d, r.left + (16f + 232f * frac) * d, r.top + 73f * d, ui)

        for (i in 0 until vis) {
            val idx = bagScroll + i
            if (idx >= slots.size) break
            val id = slots[idx]
            val row = bagRow(r, i)
            val isSel = idx == sel
            ui.style = Paint.Style.FILL; ui.color = Color.argb(if (isSel) 80 else 24, 234, 233, 219)
            c.drawRoundRect(row, 4f * d, 4f * d, ui)
            ui.style = Paint.Style.STROKE; ui.strokeWidth = (if (isSel) 2.5f else 1f) * d
            ui.color = if (isSel) CREAM else MIDGRAY
            c.drawRoundRect(row, 4f * d, 4f * d, ui)
            ui.style = Paint.Style.FILL; ui.typeface = Typeface.MONOSPACE; ui.color = CREAM
            ui.textAlign = Paint.Align.LEFT; ui.textSize = 11f * d
            c.drawText(Items.NAMES[id], row.left + 6f * d, row.centerY() + 4f * d, ui)
            ui.textAlign = Paint.Align.RIGHT
            c.drawText("x${inv.counts[id]}  ${fmt(inv.counts[id] * Items.WEIGHT[id])}kg", row.right - 6f * d, row.centerY() + 4f * d, ui)
        }
        if (slots.size > vis) {
            boxButton(c, bagScrollBtn(r, 0), "^", bagScroll > 0)
            boxButton(c, bagScrollBtn(r, 1), "v", bagScroll < slots.size - vis)
        }

        val x0 = r.left + 288f * d
        ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.LEFT; ui.typeface = Typeface.MONOSPACE
        ui.textSize = 10f * d; ui.color = CREAM
        val handName = if (inv.hand >= 0) Items.NAMES[inv.hand] else "vacía"
        c.drawText("Mano: $handName", x0, r.top + 82f * d, ui)

        val cur = if (sel < slots.size) slots[sel] else -1
        boxButton(c, btnRect(r, 0), "Equipar", cur >= 0 && Items.equippable(cur))
        boxButton(c, btnRect(r, 1), "Guardar", inv.hand >= 0)
        boxButton(c, btnRect(r, 2), "Usar", cur >= 0 && Items.usable(cur))
        boxButton(c, btnRect(r, 3), "Tirar", cur >= 0)
        boxButton(c, btnRect(r, 4), "Cerrar", true)
        if (slots.isEmpty()) {
            ui.style = Paint.Style.FILL; ui.textAlign = Paint.Align.LEFT; ui.textSize = 12f * d
            ui.color = LIGHTGRAY
            c.drawText("Vacío. Rebusca en árboles y plantas.", r.left + 16f * d, r.top + 100f * d, ui)
        }
    }

    private fun drawCraftTab(c: Canvas, r: RectF) {
        val vis = craftVisible(r)
        val n = Inventory.RECIPES.size
        craftScroll = craftScroll.coerceIn(0, max(0, n - vis))
        for (i in 0 until vis) {
            val k = craftScroll + i
            if (k >= n) break
            val rec = Inventory.RECIPES[k]
            val row = rowRect(r, i)
            val ok = inv.canCraft(rec)
            ui.style = Paint.Style.FILL
            ui.color = if (ok) Color.argb(55, 234, 233, 219) else Color.argb(18, 234, 233, 219)
            c.drawRoundRect(row, 6f * density, 6f * density, ui)
            ui.style = Paint.Style.STROKE; ui.strokeWidth = 2f * density
            ui.color = if (ok) CREAM else MIDGRAY
            c.drawRoundRect(row, 6f * density, 6f * density, ui)
            ui.style = Paint.Style.FILL; ui.typeface = Typeface.MONOSPACE; ui.textAlign = Paint.Align.LEFT
            ui.color = if (ok) CREAM else MIDGRAY
            ui.textSize = 14f * density
            c.drawText(rec.name, row.left + 10f * density, row.top + 19f * density, ui)
            ui.textSize = 10f * density
            c.drawText(rec.desc, row.left + 10f * density, row.top + 36f * density, ui)
            ui.textAlign = Paint.Align.RIGHT; ui.textSize = 12f * density
            c.drawText(if (ok) "Crear" else "Faltan", row.right - 10f * density, row.top + 19f * density, ui)
        }
        if (n > vis) {
            boxButton(c, craftScrollBtn(r, 0), "^", craftScroll > 0)
            boxButton(c, craftScrollBtn(r, 1), "v", craftScroll < n - vis)
        }
    }

    private fun handlePanelTouch(x: Float, y: Float) {
        val r = panelRect()
        if (bagRect().contains(x, y) || !r.contains(x, y)) { panelOpen = false; return }
        for (k in 0..1) {
            if (tabRect(r, k).contains(x, y)) { panelTab = k; return }
        }
        if (panelTab == 0) {
            val slots = inv.slots()
            val vis = listVisible(r)
            for (i in 0 until vis) {
                if (bagRow(r, i).contains(x, y)) { val idx = bagScroll + i; if (idx < slots.size) sel = idx; return }
            }
            if (slots.size > vis) {
                if (bagScrollBtn(r, 0).contains(x, y)) { bagScroll = max(0, bagScroll - 1); return }
                if (bagScrollBtn(r, 1).contains(x, y)) { bagScroll = min(slots.size - vis, bagScroll + 1); return }
            }
            if (btnRect(r, 0).contains(x, y)) {
                if (sel < slots.size) { inv.equip(slots[sel]); fixSel() }
                return
            }
            if (btnRect(r, 1).contains(x, y)) { inv.unequip(); return }
            if (btnRect(r, 2).contains(x, y)) { onUse(); return }
            if (btnRect(r, 3).contains(x, y)) { onDropItem(); return }
            if (btnRect(r, 4).contains(x, y)) { panelOpen = false }
        } else {
            val vis = craftVisible(r)
            val n = Inventory.RECIPES.size
            if (n > vis) {
                if (craftScrollBtn(r, 0).contains(x, y)) { craftScroll = max(0, craftScroll - 1); return }
                if (craftScrollBtn(r, 1).contains(x, y)) { craftScroll = min(n - vis, craftScroll + 1); return }
            }
            for (i in 0 until vis) {
                val k = craftScroll + i
                if (k < n && rowRect(r, i).contains(x, y)) { craft(Inventory.RECIPES[k]); return }
            }
        }
    }

    // ---------- entrada táctil ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (menuOpen) {
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                for (i in Region.TOWNS.indices) if (townRect(i).contains(e.x, e.y)) {
                    chosenTown = i
                    prefs.edit().putInt("spawn_town", i).apply()
                    menuOpen = false
                    message = "Cargando el mapa de ${Region.TOWNS[i].first}…"
                    onChoose?.invoke(i)
                    break
                }
            }
            return true
        }
        if (mapOpen) return worldMap.onTouch(e) { mapOpen = false }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (canRetry && message != null) {
                    canRetry = false; message = "Cargando…"; onRetry?.invoke()
                    return true
                }
                val idx = e.actionIndex
                val x = e.getX(idx); val y = e.getY(idx)
                if (world != null) {
                    if (deadT > 0f) return true
                    if (panelOpen) { handlePanelTouch(x, y); return true }
                    if (bagRect().contains(x, y)) { openPanel(); return true }
                    if (mapBtnRect().contains(x, y)) { openMap(); return true }
                    if (hypot(x - atkCx(), y - atkCy()) <= atkR() * 1.15f) { onAttack(); return true }
                    if (nearTree != null && hypot(x - srcCx(), y - srcCy()) <= srcR() * 1.2f) { onSearch(); return true }
                    if (nearStone != null && hypot(x - stoneCx(), y - stoneCy()) <= srcR() * 1.2f) { onStone(); return true }
                    if (nearFence && hypot(x - jumpCx(), y - jumpCy()) <= srcR() * 1.2f) { onJump(); return true }
                    for ((i, a) in ctxList.withIndex()) if (hypot(x - ctxCx(i), y - ctxCy(i)) <= srcR() * 1.2f) { onCtx(a.act); return true }
                }
                if (joyId == -1 && x < width * 0.5f && !panelOpen) {
                    joyId = e.getPointerId(idx)
                    joyOx = x; joyOy = y; joyKx = x; joyKy = y
                    jx = 0f; jy = 0f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (joyId != -1) {
                    val i = e.findPointerIndex(joyId)
                    if (i >= 0) {
                        var dx = e.getX(i) - joyOx
                        var dy = e.getY(i) - joyOy
                        val d = hypot(dx, dy)
                        if (d > joyR) { dx = dx / d * joyR; dy = dy / d * joyR }
                        joyKx = joyOx + dx; joyKy = joyOy + dy
                        jx = dx / joyR; jy = dy / joyR
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (e.actionMasked == MotionEvent.ACTION_CANCEL || id == joyId) {
                    joyId = -1; jx = 0f; jy = 0f
                    joyOx = defX; joyOy = defY; joyKx = defX; joyKy = defY
                }
            }
        }
        return true
    }
}
