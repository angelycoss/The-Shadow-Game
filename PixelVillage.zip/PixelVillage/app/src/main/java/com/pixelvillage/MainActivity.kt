package com.pixelvillage

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private lateinit var game: GameView
    private val loading = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        game = GameView(this)
        game.onRetry = { startWorld() }
        setContentView(game)
        hideBars()
        startWorld()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!game.handleBack()) super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        game.world?.close()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    // ---------- carga del mundo ----------
    // El personaje siempre aparece en el punto fijo de Region (20°53′32.5″N 75°49′10.14″W).
    // El mapa base viene dentro del APK; el resto se descarga a medida que se explora.
    private fun startWorld() {
        if (!loading.compareAndSet(false, true)) return
        game.showMessage("Cargando el mapa…")
        Thread {
            try {
                val w = World(applicationContext)
                w.loadStart()
                game.loadWorld(w)
            } catch (t: Throwable) {
                game.showError("No se pudo cargar el mapa.\n${t.message ?: t.javaClass.simpleName}")
            } finally {
                loading.set(false)
            }
        }.start()
    }
}
