package com.pixelvillage

import android.app.Activity
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private lateinit var game: GameView
    private val loading = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        game = GameView(this)
        game.onChoose = { startWorld(it) }
        game.onRetry = { startWorld(game.chosenTown, game.savedStart()) }
        game.onMultiplayer = { runOnUiThread { showLanDialog() } }
        setContentView(game)
        hideBars()
        // partida guardada: continúa donde la dejaste, sin volver a elegir pueblo
        game.savedStart()?.let { startWorld(game.chosenTown, it) }
    }

    // ---------- multijugador LAN ----------
    private fun showLanDialog() {
        val net = game.net
        val prefs = getSharedPreferences("pv", MODE_PRIVATE)
        val b = AlertDialog.Builder(this)
        b.setTitle("Multijugador LAN")
        if (net.mode != 0) {
            val ips = if (net.mode == 1) "\nTu IP: " + (net.localIps().joinToString(" / ").ifEmpty { "sin Wi‑Fi" }) else ""
            b.setMessage("${net.status}\nJugadores conectados: ${net.connectedCount()}$ips")
            b.setPositiveButton("Desconectar") { _, _ -> net.stop() }
            b.setNegativeButton("Cerrar", null)
        } else {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            box.setPadding(pad, pad / 2, pad, 0)
            val name = EditText(this)
            name.hint = "Tu nombre"
            name.setText(net.myName)
            val ip = EditText(this)
            ip.hint = "IP del anfitrión (ej. 192.168.1.20)"
            ip.setText(prefs.getString("last_ip", "") ?: "")
            ip.inputType = InputType.TYPE_CLASS_PHONE
            box.addView(name); box.addView(ip)
            b.setView(box)
            fun saveName() {
                val n = name.text.toString().trim().replace(Regex("\\s+"), "_").take(14).ifEmpty { "Jugador" }
                net.myName = n
                prefs.edit().putString("player_name", n).apply()
            }
            b.setPositiveButton("Unirse") { _, _ ->
                saveName()
                val addr = ip.text.toString().trim()
                if (addr.isEmpty()) Toast.makeText(this, "Escribe la IP del anfitrión", Toast.LENGTH_LONG).show()
                else { prefs.edit().putString("last_ip", addr).apply(); net.join(addr) }
            }
            b.setNeutralButton("Crear partida") { _, _ ->
                saveName()
                Thread {
                    val ok = net.startHost()
                    runOnUiThread {
                        val ips = net.localIps().joinToString(" / ")
                        AlertDialog.Builder(this).setTitle(if (ok) "Partida creada" else "Error")
                            .setMessage(if (ok) "Tus amigos deben estar en la misma Wi‑Fi (o en tu punto de acceso) y escribir esta IP:\n\n${ips.ifEmpty { "sin conexión Wi‑Fi" }}"
                            else net.status)
                            .setPositiveButton("OK", null).show()
                    }
                }.start()
            }
            b.setNegativeButton("Cancelar", null)
        }
        b.show()
    }

    override fun onPause() {
        super.onPause()
        game.saveNow()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!game.handleBack()) super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        game.net.stop()
        game.world?.close()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    // ---------- carga del mundo ----------
    // El personaje aparece en el pueblo que elige el jugador al empezar (Region.TOWNS).
    // El mapa base viene dentro del APK; el resto se descarga a medida que se explora.
    private fun startWorld(town: Int, resume: FloatArray? = null) {
        if (!loading.compareAndSet(false, true)) return
        game.showMessage("Cargando el mapa…")
        Thread {
            try {
                val w = World(applicationContext)
                val t = Region.TOWNS[town.coerceIn(0, Region.TOWNS.size - 1)]
                if (resume != null) w.loadStart(resume[0], resume[1])
                else w.loadStart(Region.px(t.second), Region.py(t.third))
                game.loadWorld(w)
            } catch (t: Throwable) {
                game.showError("No se pudo cargar el mapa.\n${t.message ?: t.javaClass.simpleName}")
            } finally {
                loading.set(false)
            }
        }.start()
    }
}
