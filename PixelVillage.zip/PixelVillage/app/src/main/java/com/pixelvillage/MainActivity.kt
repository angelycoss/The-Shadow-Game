package com.pixelvillage

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private companion object {
        const val RADIUS_M = 600          // radio del mapa que se descarga (metros)
        const val REQ_LOC = 1
    }

    private lateinit var game: GameView
    private val prefs by lazy { getSharedPreferences("pv", MODE_PRIVATE) }
    private val loading = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        game = GameView(this)
        game.onRetry = { startWorld() }
        setContentView(game)
        hideBars()
        startWorld()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    // ---------- carga del mundo ----------
    private fun startWorld() {
        val lat = prefs.getString("lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (lat == null || lon == null) { askHome(); return }
        if (!loading.compareAndSet(false, true)) return

        game.showMessage("Descargando tu barrio…")
        Thread {
            try {
                val json = Osm.fetch(applicationContext, lat, lon, RADIUS_M)
                game.showMessage("Construyendo el mundo…")
                game.setWorld(WorldBuilder.build(json, lat, lon, RADIUS_M))
            } catch (t: Throwable) {
                game.showError("No se pudo cargar el mapa.\n${t.message ?: t.javaClass.simpleName}")
            } finally {
                loading.set(false)
            }
        }.start()
    }

    // ---------- elegir "casa" ----------
    private fun askHome() {
        game.showMessage("Elige dónde vives")
        AlertDialog.Builder(this)
            .setTitle("¿Dónde vives?")
            .setItems(arrayOf("Usar mi ubicación actual", "Escribir mi dirección")) { _, which ->
                if (which == 0) useGps() else askAddress()
            }
            .setCancelable(false)
            .show()
    }

    private fun useGps() {
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
            return
        }
        game.showMessage("Buscando tu ubicación…")
        LocationHelper.once(this) { loc ->
            runOnUiThread {
                if (loc == null) {
                    Toast.makeText(this, "No pude obtener el GPS. Prueba escribiendo tu dirección.", Toast.LENGTH_LONG).show()
                    askHome()
                } else {
                    saveHome(loc.latitude, loc.longitude)
                }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOC) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) useGps() else askHome()
        }
    }

    private fun askAddress() {
        val input = EditText(this).apply { hint = "Calle, número, ciudad"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Tu dirección")
            .setView(input)
            .setPositiveButton("Buscar") { _, _ ->
                val q = input.text.toString().trim()
                if (q.isEmpty()) { askHome(); return@setPositiveButton }
                game.showMessage("Buscando dirección…")
                Thread {
                    val r = Osm.geocode(q)
                    runOnUiThread {
                        if (r == null) {
                            Toast.makeText(this, "No encontré esa dirección.", Toast.LENGTH_LONG).show()
                            askHome()
                        } else {
                            saveHome(r.first, r.second)
                        }
                    }
                }.start()
            }
            .setNegativeButton("Atrás") { _, _ -> askHome() }
            .setCancelable(false)
            .show()
    }

    private fun saveHome(lat: Double, lon: Double) {
        prefs.edit().putString("lat", lat.toString()).putString("lon", lon.toString()).apply()
        startWorld()
    }
}
