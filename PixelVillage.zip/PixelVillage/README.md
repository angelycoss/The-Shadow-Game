# Pixel Village

Juego Android ligero (Kotlin, sin dependencias) cuyo mundo se genera en tiempo real con datos de
OpenStreetMap: terreno, caminos, casas, árboles y agua de la provincia de Holguín (Cuba).
Estilo visual: 4 tonos con dithering Bayer, viñeta y esquinas redondeadas.

## Cómo se compila
1. Sube este proyecto a un repositorio de GitHub (rama `main`).
2. El workflow `.github/workflows/build.yml` compila el APK automáticamente.
3. Descárgalo en **Actions → última ejecución → Artifacts → PixelVillage-debug**.

## Cómo funciona
- El personaje siempre aparece en **20°53′32.5″N 75°49′10.14″W** (constantes en `Region.kt`). Ya no se pide "tu casa" ni el GPS.
- **Mapa base incluido en el juego**: toda la provincia de Holguín (extracto de OpenStreetMap por BBBike) viene dentro del APK
  como teselas en `app/src/main/assets/base/`. Funciona sin internet.
- El mundo se divide en teselas de ≈ 819 m. Se cargan las 3×3 alrededor del jugador y se sueltan de memoria las lejanas.
- **Fuera del mapa base** (más allá de la provincia) las teselas se **descargan de Overpass a medida que exploras** y se guardan
  en el teléfono para la próxima vez. Si no hay conexión, sale un aviso y no puedes pasar a esa zona.
- Joystick flotante: toca y arrastra en la mitad izquierda de la pantalla.
- Viento: cambia de fuerza y dirección con el tiempo; hay partículas al aire y los árboles se inclinan.
- Terreno: sobre camino vas a velocidad normal, fuera de los caminos al 80 %, y en el agua (se puede cruzar) al 50 % y hundido hasta la mitad.
- Inventario: botón **Bolsa** (arriba a la derecha). Junto a un árbol aparece **Buscar**: cada árbol esconde 1 o 2 palos. En la bolsa puedes **Equipar** un palo en la mano; el botón **Atacar** lo usa (o puños sin palo).
- Naturaleza: arbustos y matas de hierba que se mecen con el viento. Piedras sueltas por el suelo: acércate y toca **Piedras** (cada montoncito tiene 1 o 2).
- Crear (pestaña **Crear** de la Bolsa): **Hacha** = 1 Piedra + 1 Palo; **Cortar tronco** = 1 Tronco -> 2 Palos; **Fogata** = 3 Palos + 2 Piedras (las piedras hacen la chispa). Con el hacha equipada, **Atacar** junto a un árbol lo tala en 4 golpes y da 2 Troncos y 1-3 Hojas; queda el tocón.
- **Cultivos** (landuse=farmland): trigo decorativo en filas, con surcos y calles que dividen el campo en parcelas. Mide la mitad del personaje y se dobla al pasar. No se cosecha.
- **Cercas, setos y muros** (barrier de OSM): miden la mitad del personaje y no se traspasan. Junto a una aparece el botón **Saltar**.
- **Humedales y fango**: te hundes hasta las rodillas y vas muy lento (20 %).
- **Senderos** (highway=path): caminos muy estrechos.
- **Vertederos** (landuse=landfill): montones de basura decorativos.
- **Agua** (lagos, lagunas, mar): olas pequeñas. Si pasas **3 minutos seguidos** en el agua te ahogas por cansancio y reapareces en el punto de inicio (hay una barra de cansancio).
- **Vías de tren** (activas, abandonadas y en desuso): rieles con traviesas. Se pueden cruzar caminando.
- **Iglesias** (building=church/chapel/cathedral o lugar de culto cristiano): edificio con torre, aguja y cruz.
- **Mapa del mundo** (botón **Mapa**, arriba a la izquierda de Bolsa): muestra toda la provincia con caminos, lagos, bosques, cultivos, vías de tren y los nombres de los pueblos. Arrastra para moverte, pellizca (o doble toque, o botones + / −) para acercar, **Aquí** te centra y un **punto rojo** marca dónde estás. El juego se pausa mientras lo miras. El botón atrás también lo cierra.
- Edificios: camina hacia la puerta (la franja clara en la pared sur) para entrar. Dentro se quita el tejado y ves el interior vacío. Los edificios muy pequeños o con la puerta bloqueada por un vecino siguen cerrados.

## Mapa del mundo (pantalla del botón Mapa)
`python3 tools/build_overview.py archivo.gpkg` dibuja el mapa en 5 niveles de zoom (16 m/px ... 256 m/px) como teselas WebP en `assets/map/` y guarda los nombres de pueblos en `places.json`. Cada nivel se dibuja con menos detalle cuanto más lejos (casas y senderos solo de cerca). La app solo carga las teselas que se ven, con caché. Necesita Python 3, numpy y Pillow (tarda unos 8 minutos).

## Cambiar o actualizar el mapa base
`python3 tools/build_tiles.py archivo.gpkg` convierte un GeoPackage de BBBike (https://extract.bbbike.org, formato GeoPackage) en las teselas de `assets/base/`.
Si cambias el punto de aparición, actualiza `Region.kt` **y** `tools/build_tiles.py` (mismas constantes `LAT0`/`LON0`).

## Ajustes rápidos
| Dónde | Constante | Qué hace |
|---|---|---|
| `World.kt` | `LOAD_R` / `KEEP_R` | Teselas que se cargan / se conservan alrededor del jugador |
| `World.kt` | `PPM` | Píxeles por metro (zoom del mundo) |
| `GameView.kt` | `LOW_H` | Resolución interna (más baja = más pixelado y más ligero) |
| `GameView.kt` | `SPEED` | Velocidad del jugador |
| `GameView.kt` | `PAL` | Paleta de 4 colores |
| `Osm.kt` | `UA` | Pon tu contacto (política de uso de OSM) |

## Limitaciones de esta v0.1
- Proyección oblicua (cenital con altura), no isométrica 2:1 todavía.
- Los polígonos con huecos (islas dentro de un lago) se dibujan sin hueco.
- El mar solo existe dentro del mapa base (la provincia); fuera de él, las zonas descargadas no traen mar.
- Sin iconos propios, sonido ni misiones: es la base del motor.
- Los datos son © colaboradores de OpenStreetMap (ODbL).

## Versiones
La versión está en una sola línea: `gameVersion` en `app/build.gradle.kts` (0.0.1, 0.0.2, …). El `versionCode` se calcula solo.
La APK se firma siempre con `app/debug.keystore` (incluida en el proyecto), así que cada versión se instala encima de la anterior sin desinstalar.
Se muestra arriba al centro del juego.

## Interiores
Al cruzar la puerta de una casa (que está en la pared más cercana a un camino) el juego pasa a una sala propia, mucho más grande que el edificio, con todo lo demás en negro. Se sale cruzando la puerta de abajo.

## Supervivencia (v0.0.2)
- **Peso:** cada objeto pesa (ver `Items.WEIGHT`). El personaje aguanta 25 kg (+12 con una cesta de junco). Pasado el 70 % de carga camina más lento. Con "Tirar" dejas cosas en el suelo.
- **Agua:** reserva de 100 que baja poco quieto y más caminando; al llegar a 0 se gasta el agua del cuerpo y, si también llega a 0, mueres y sueltas todo lo que llevas en un bulto en el suelo. Un cuenco con agua hervida se bebe solo cuando la reserva baja del 55 %.
- **Agua potable:** cuenco (Tronco + cuchillo) → "Llenar" junto al agua → "Hervir" junto a una fogata (el cuenco se quema al 3.er hervido).
- **Recursos:** junco y semillas de arroz (humedales), palos de marabú (matorral y praderas), piñas y hojas de pino (pinos; los árboles de hoja ancha solo dan palos), cerezos / semillas de huerta / tabaco (muy raros).
- **Cultivos:** semillas de tomate, lechuga, pepino, remolacha, patata, frijol, sandía, cerezo y tabaco; se siembran con "Sembrar" y tardan entre 6 y 20 min (tiempo real, también con el juego cerrado).
- **Crafteo:** Cuchillo, Lanza, Hacha, Cuerda, Cesta, Cuenco, Fogata (ver `Inventory.RECIPES`).
- **Inicio:** al abrir el juego se elige el pueblo de aparición (`Region.TOWNS`).

## Minas y economía (v0.0.3)
`tools/build_mines.py` elige seis canteras de OpenStreetMap y escribe `assets/mines.json`: 3 de **hierro** en Moa, 2 de **cobre** muy lejos (zona de Mayarí/Sagua) y **una sola de oro** (cerca de Buenaventura). Cada mina de hierro/cobre tiene 5 hornos de fusión y la de oro solo 1.
- Los yacimientos se minan con un **pico** en la mano (2 golpes por mineral, 3-5 por yacimiento; el oro 1-2). No se renuevan.
- Un horno necesita **leña** (troncos; 1 tronco = 2 fundiciones, máx. 10). "Fundir" convierte un mineral en un lingote (6 s).
- 1 lingote de oro → 9 monedas de oro (receta "Monedas de oro").

## Caballos
Son raros (solo en pastos/campos). Se domman montándolos ("Domar", 4 s, 25 % de que te tire). Corriendo gastan energía en 18 min y sed en 30 min; agotados o sedientos solo caminan (no mueren). Comen hierba del suelo ("Pastar"), o una paca (4 hierbas cortadas con cuchillo en la mano) con "Alimentar", y beben en el agua ("Abrevar"). Se amarran a un árbol con una cuerda de junco. La montura de junco da al caballo 2 asientos (el segundo jinete se podrá usar cuando haya otros jugadores).
