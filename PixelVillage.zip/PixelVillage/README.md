# Pixel Village

Juego Android ligero (Kotlin, sin dependencias) cuyo mundo se genera en tiempo real con datos de
OpenStreetMap: terreno, caminos, casas, árboles y agua alrededor de **tu casa**.
Estilo visual: 4 tonos con dithering Bayer, viñeta y esquinas redondeadas.

## Cómo se compila
1. Sube este proyecto a un repositorio de GitHub (rama `main`).
2. El workflow `.github/workflows/build.yml` compila el APK automáticamente.
3. Descárgalo en **Actions → última ejecución → Artifacts → PixelVillage-debug**.

## Cómo funciona
- Primera vez: eliges tu casa (GPS o dirección escrita). Se guarda en el teléfono.
- Se descargan ~600 m a la redonda desde Overpass y se guardan en caché (la siguiente vez abre sin internet).
- Joystick flotante: toca y arrastra en la mitad izquierda de la pantalla.
- Viento: cambia de fuerza y dirección con el tiempo; hay partículas al aire y los árboles se inclinan.
- Terreno: sobre camino vas a velocidad normal, fuera de los caminos al 80 %, y en el agua (se puede cruzar) al 50 % y hundido hasta la mitad.
- Inventario: botón **Bolsa** (arriba a la derecha). Junto a un árbol aparece **Buscar**: cada árbol esconde 1 o 2 palos. En la bolsa puedes **Equipar** un palo en la mano; el botón **Atacar** lo usa (o puños sin palo).
- Naturaleza: arbustos y matas de hierba que se mecen con el viento. Piedras sueltas por el suelo: acércate y toca **Piedras** (cada montoncito tiene 1 o 2).
- Crear (pestaña **Crear** de la Bolsa): **Hacha** = 1 Piedra + 1 Palo; **Cortar tronco** = 1 Tronco -> 2 Palos; **Fogata** = 3 Palos + 2 Piedras (las piedras hacen la chispa). Con el hacha equipada, **Atacar** junto a un árbol lo tala en 4 golpes y da 2 Troncos y 1-3 Hojas; queda el tocón.
- Edificios: camina hacia la puerta (la franja clara en la pared sur) para entrar. Dentro se quita el tejado y ves el interior vacío. Los edificios muy pequeños o con la puerta bloqueada por un vecino siguen cerrados.
- Para cambiar de casa: Ajustes de Android → Apps → Pixel Village → Borrar datos.

## Ajustes rápidos
| Dónde | Constante | Qué hace |
|---|---|---|
| `MainActivity.kt` | `RADIUS_M` | Radio del mapa descargado |
| `World.kt` | `PPM` | Píxeles por metro (zoom del mundo) |
| `GameView.kt` | `LOW_H` | Resolución interna (más baja = más pixelado y más ligero) |
| `GameView.kt` | `SPEED` | Velocidad del jugador |
| `GameView.kt` | `PAL` | Paleta de 4 colores |
| `Osm.kt` | `UA` | Pon tu contacto (política de uso de OSM) |

## Limitaciones de esta v0.1
- Proyección oblicua (cenital con altura), no isométrica 2:1 todavía.
- Se ignoran las relaciones multipolígono de OSM (lagos o bosques muy grandes pueden faltar).
- Sin iconos propios, sonido ni misiones: es la base del motor.
- Los datos son © colaboradores de OpenStreetMap (ODbL).
