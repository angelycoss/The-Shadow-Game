# Pixel Village

Juego Android ligero (Kotlin, sin dependencias) cuyo mundo se genera en tiempo real con datos de
OpenStreetMap: terreno, caminos, casas, árboles y agua alrededor de **tu casa**.
Estilo visual: 4 tonos con dithering Bayer, viñeta y esquinas redondeadas.

## Cómo se compila
1. Sube este proyecto a un repositorio de GitHub (rama `main`).
2. El workflow `.github/workflows/build.yml` compila el APK automáticamente.
3. Descárgalo en **Actions → última ejecución → Artifacts → PixelVillage-debug**.

## Cómo funciona
- Primera vez: eliges tu casa (GPS o dirección escrita). Se guarda en el teléfono.
- Se descargan ~600 m a la redonda desde Overpass y se guardan en caché (la siguiente vez abre sin internet).
- Joystick flotante: toca y arrastra en la mitad izquierda de la pantalla.
- Para cambiar de casa: Ajustes de Android → Apps → Pixel Village → Borrar datos.

## Ajustes rápidos
| Dónde | Constante | Qué hace |
|---|---|---|
| `MainActivity.kt` | `RADIUS_M` | Radio del mapa descargado |
| `World.kt` | `PPM` | Píxeles por metro (zoom del mundo) |
| `GameView.kt` | `LOW_H` | Resolución interna (más baja = más pixelado y más ligero) |
| `GameView.kt` | `SPEED` | Velocidad del jugador |
| `GameView.kt` | `PAL` | Paleta de 4 colores |
| `Osm.kt` | `UA` | Pon tu contacto (política de uso de OSM) |

## Limitaciones de esta v0.1
- Proyección oblicua (cenital con altura), no isométrica 2:1 todavía.
- Se ignoran las relaciones multipolígono de OSM (lagos o bosques muy grandes pueden faltar).
- Sin iconos propios, sonido ni misiones: es la base del motor.
- Los datos son © colaboradores de OpenStreetMap (ODbL).
